import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Share2, Globe, Loader2, Copy, Check, ExternalLink, Users, Folder as FolderIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import EolsuLogo from '@/components/ui/EolsuLogo';
import GlassCard from '@/components/ui/GlassCard';
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

export default function SharedFolders() {
  const [user, setUser] = useState(null);
  const [copiedId, setCopiedId] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  // Fetch public folders (my shared)
  const { data: publicFolders = [], isLoading } = useQuery({
    queryKey: ['publicFolders', user?.email],
    queryFn: () => base44.entities.Folder.filter({ 
      owner_email: user?.email,
      is_public: true 
    }),
    enabled: !!user?.email,
  });

  // Fetch folders shared with me
  const { data: sharedWithMe = [], isLoading: sharedLoading } = useQuery({
    queryKey: ['sharedWithMe', user?.email],
    queryFn: () => base44.entities.SharedFolder.filter({ 
      shared_with_email: user?.email 
    }),
    enabled: !!user?.email,
  });

  // Fetch folder details for shared folders
  const { data: sharedFolderDetails = [] } = useQuery({
    queryKey: ['sharedFolderDetails', sharedWithMe],
    queryFn: async () => {
      if (sharedWithMe.length === 0) return [];
      const folderIds = sharedWithMe.map(s => s.folder_id);
      const folders = await base44.entities.Folder.list();
      return folders.filter(f => folderIds.includes(f.id));
    },
    enabled: sharedWithMe.length > 0,
  });

  // Fetch videos for each folder
  const { data: allVideos = [] } = useQuery({
    queryKey: ['videos', user?.email],
    queryFn: () => base44.entities.Video.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const getVideoCount = (folderId) => {
    return allVideos.filter(v => v.folder_id === folderId).length;
  };

  const copyShareLink = (folder) => {
    const link = `${window.location.origin}${createPageUrl(`SharedFolder?code=${folder.share_code}`)}`;
    navigator.clipboard.writeText(link);
    setCopiedId(folder.id);
    toast.success('링크가 복사되었어요!');
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  const getOwnerEmail = (folderId) => {
    const share = sharedWithMe.find(s => s.folder_id === folderId);
    return share?.owner_email || '';
  };

  return (
    <div className="min-h-screen bg-[#0D1117] pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0D1117]/80 backdrop-blur-xl border-b border-white/5">
        <div className="px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#4158F1] to-[#8B5CF6] flex items-center justify-center">
              <Share2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-white font-semibold text-lg">공유</h1>
              <p className="text-white/50 text-xs">
                폴더 공유 관리
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        <Tabs defaultValue="shared-with-me" className="w-full">
          <TabsList className="w-full bg-white/5 border border-white/10 p-1 mb-6">
            <TabsTrigger 
              value="shared-with-me" 
              className="flex-1 data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#4158F1] data-[state=active]:to-[#8B5CF6] data-[state=active]:text-white text-white/50"
            >
              <Users className="w-4 h-4 mr-2" />
              공유받은 폴더
            </TabsTrigger>
            <TabsTrigger 
              value="my-shared" 
              className="flex-1 data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#4158F1] data-[state=active]:to-[#8B5CF6] data-[state=active]:text-white text-white/50"
            >
              <Globe className="w-4 h-4 mr-2" />
              내 공개 폴더
            </TabsTrigger>
          </TabsList>

          {/* Shared With Me Tab */}
          <TabsContent value="shared-with-me">
            {sharedLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
              </div>
            ) : sharedFolderDetails.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-20"
              >
                <GlassCard className="inline-block p-8">
                  <Users className="w-16 h-16 text-white/20 mx-auto mb-4" />
                  <h3 className="text-white font-medium mb-2">공유받은 폴더가 없어요</h3>
                  <p className="text-white/50 text-sm">
                    다른 사람이 폴더를 공유하면<br />
                    여기에 표시돼요
                  </p>
                </GlassCard>
              </motion.div>
            ) : (
              <div className="space-y-4">
                <AnimatePresence>
                  {sharedFolderDetails.map((folder, index) => (
                    <motion.div
                      key={folder.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <Link to={createPageUrl(`SharedFolder?code=${folder.share_code}`)}>
                        <GlassCard hover glow className="p-4">
                          <div className="flex items-center gap-3">
                            <div 
                              className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                              style={{ 
                                background: `linear-gradient(135deg, ${folder.color || '#4158F1'}40, ${folder.color || '#4158F1'}20)` 
                              }}
                            >
                              <FolderIcon className="w-6 h-6" style={{ color: folder.color || '#4158F1' }} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="text-white font-medium truncate">{folder.name}</h3>
                              <p className="text-white/40 text-xs mt-0.5">
                                {getOwnerEmail(folder.id)}님이 공유함
                              </p>
                            </div>
                            <div className="text-xs text-white/30 bg-white/5 px-2 py-1 rounded-full">
                              읽기 전용
                            </div>
                          </div>
                        </GlassCard>
                      </Link>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </TabsContent>

          {/* My Shared Folders Tab */}
          <TabsContent value="my-shared">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
          </div>
        ) : publicFolders.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <GlassCard className="inline-block p-8">
              <Globe className="w-16 h-16 text-white/20 mx-auto mb-4" />
              <h3 className="text-white font-medium mb-2">공개 폴더가 없어요</h3>
              <p className="text-white/50 text-sm">
                폴더를 공개로 설정하면 다른 사람과<br />
                공유할 수 있어요
              </p>
            </GlassCard>
          </motion.div>
        ) : (
          <div className="space-y-4">
            <AnimatePresence>
              {publicFolders.map((folder, index) => (
                <motion.div
                  key={folder.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <GlassCard glow className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div 
                          className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{ 
                            background: `linear-gradient(135deg, ${folder.color || '#4158F1'}40, ${folder.color || '#4158F1'}20)` 
                          }}
                        >
                          <Globe className="w-6 h-6" style={{ color: folder.color || '#4158F1' }} />
                        </div>
                        <div className="min-w-0">
                          <h3 className="text-white font-medium truncate">{folder.name}</h3>
                          <p className="text-white/50 text-xs mt-0.5">
                            {getVideoCount(folder.id)}개의 영상
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyShareLink(folder)}
                          className={cn(
                            "text-white/50 hover:text-white hover:bg-white/10",
                            copiedId === folder.id && "text-green-400"
                          )}
                        >
                          {copiedId === folder.id ? (
                            <Check className="w-4 h-4" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </Button>
                        <Link to={createPageUrl(`SharedFolder?code=${folder.share_code}`)}>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-white/50 hover:text-white hover:bg-white/10"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </Link>
                      </div>
                    </div>

                    {/* Share Link Preview */}
                    <div className="mt-3 p-2 rounded-lg bg-white/5 border border-white/10">
                      <p className="text-white/40 text-xs font-mono truncate">
                        {window.location.origin}{createPageUrl(`SharedFolder?code=${folder.share_code}`)}
                      </p>
                    </div>
                  </GlassCard>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}