import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Sparkles, Loader2, RefreshCw, Play, Globe, FolderPlus } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import EolsuLogo from '@/components/ui/EolsuLogo';
import GlassCard from '@/components/ui/GlassCard';
import GradientButton from '@/components/ui/GradientButton';
import { fetchTrendingVideos, searchVideos, COUNTRIES } from '@/components/utils/youtubeApi';
import { cn } from "@/lib/utils";
import { useVideoPlayer } from '@/components/video/GlobalVideoPlayer';

const platformColors = {
  youtube: { bg: 'bg-red-500/20', text: 'text-red-400', label: 'YouTube' },
  tiktok: { bg: 'bg-pink-500/20', text: 'text-pink-400', label: 'TikTok' },
  instagram: { bg: 'bg-purple-500/20', text: 'text-purple-400', label: 'Reels' },
  other: { bg: 'bg-gray-500/20', text: 'text-gray-400', label: 'Video' }
};

export default function Home() {
  const { playVideo } = useVideoPlayer();
  const [user, setUser] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState('KR');
  const [trendingVideos, setTrendingVideos] = useState([]);
  const [loadingTrending, setLoadingTrending] = useState(true);
  const [addingVideo, setAddingVideo] = useState(null);
  const [selectedFolder, setSelectedFolder] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  useEffect(() => {
    const loadTrending = async () => {
      setLoadingTrending(true);
      const videos = await fetchTrendingVideos(selectedCountry, 12);
      setTrendingVideos(videos);
      setLoadingTrending(false);
    };
    loadTrending();
  }, [selectedCountry]);

  // Fetch user's videos
  const { data: userVideos = [], isLoading: videosLoading } = useQuery({
    queryKey: ['userVideos', user?.email],
    queryFn: () => base44.entities.Video.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  // Fetch folders for context
  const { data: folders = [] } = useQuery({
    queryKey: ['userFolders', user?.email],
    queryFn: () => base44.entities.Folder.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  // Fetch all folder views for popular ranking
  const { data: allFolderViews = [] } = useQuery({
    queryKey: ['allFolderViews'],
    queryFn: () => base44.entities.FolderView.list(),
    enabled: !!user?.email,
  });

  // Fetch all public folders
  const { data: publicFolders = [] } = useQuery({
    queryKey: ['publicFolders'],
    queryFn: () => base44.entities.Folder.filter({ is_public: true }),
    enabled: !!user?.email,
  });

  // Calculate popular folders
  const popularFolders = React.useMemo(() => {
    const folderStats = {};
    
    allFolderViews.forEach(view => {
      if (!folderStats[view.folder_id]) {
        folderStats[view.folder_id] = { total: 0, unique: 0 };
      }
      folderStats[view.folder_id].total += view.view_count;
      folderStats[view.folder_id].unique += 1;
    });
    
    return publicFolders
      .map(folder => ({
        ...folder,
        stats: folderStats[folder.id] || { total: 0, unique: 0 }
      }))
      .filter(f => f.stats.total > 0)
      .sort((a, b) => b.stats.total - a.stats.total)
      .slice(0, 10);
  }, [allFolderViews, publicFolders]);

  const generateRecommendations = async () => {
    if (userVideos.length === 0) return;
    
    setIsGenerating(true);
    
    try {
      // Prepare user's video data for analysis
      const videoSummary = userVideos.slice(0, 20).map(v => ({
        title: v.title,
        platform: v.platform,
        folder: folders.find(f => f.id === v.folder_id)?.name || '기타'
      }));

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `사용자가 저장한 영상 목록을 분석하고, 비슷한 취향의 YouTube 영상을 찾기 위한 검색 키워드 3개를 추천해주세요.

사용자의 저장된 영상:
${JSON.stringify(videoSummary, null, 2)}

각 추천에 포함할 정보:
- search_query: YouTube 검색 키워드 (한글 또는 영문)
- reason: "얼쑤~"로 시작하는 친근한 추천 이유 (한 문장)
- category: 한글 카테고리 (음악, 게임, 브이로그, 요리, 교육 등)

응답 형식은 JSON으로 해주세요.`,
        response_json_schema: {
          type: "object",
          properties: {
            recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  search_query: { type: "string" },
                  reason: { type: "string" },
                  category: { type: "string" }
                }
              }
            }
          }
        }
      });

      if (response?.recommendations) {
        // Fetch actual videos for each search query
        const videosPromises = response.recommendations.map(async rec => {
          try {
            const videos = await searchVideos(rec.search_query, 3);
            console.log('Fetched videos for', rec.search_query, videos);
            return {
              ...rec,
              videos: videos || []
            };
          } catch (err) {
            console.error('Error fetching videos for', rec.search_query, err);
            return {
              ...rec,
              videos: []
            };
          }
        });
        const recsWithVideos = await Promise.all(videosPromises);
        console.log('Final recommendations with videos:', recsWithVideos);
        setRecommendations(recsWithVideos);
      }
    } catch (error) {
      console.error('Failed to generate recommendations:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  // Auto-generate on first load when videos are available
  useEffect(() => {
    if (userVideos.length > 0 && recommendations.length === 0 && !isGenerating) {
      setTimeout(() => generateRecommendations(), 500);
    }
  }, [userVideos]);

  const handleAddToFolder = async () => {
    if (!addingVideo || !selectedFolder) return;
    
    try {
      await base44.entities.Video.create({
        title: addingVideo.title,
        url: `https://www.youtube.com/watch?v=${addingVideo.videoId}`,
        thumbnail_url: addingVideo.thumbnail,
        platform: 'youtube',
        embed_id: addingVideo.videoId,
        folder_id: selectedFolder,
        owner_email: user.email
      });
      
      setAddingVideo(null);
      setSelectedFolder(null);
    } catch (error) {
      console.error('Failed to add video:', error);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1117] pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0D1117]/80 backdrop-blur-xl border-b border-white/5">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <EolsuLogo size="sm" />
            <GradientButton 
              size="sm" 
              variant="ghost"
              onClick={generateRecommendations}
              disabled={isGenerating || userVideos.length === 0}
              icon={isGenerating ? Loader2 : RefreshCw}
              className={isGenerating ? '[&_svg]:animate-spin' : ''}
            >
              새로고침
            </GradientButton>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        {/* Popular Folders */}
        {popularFolders.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#FFD60A]/20 to-[#FFD60A]/5 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-[#FFD60A]" />
              </div>
              <div>
                <h2 className="text-white font-semibold">인기 폴더</h2>
                <p className="text-white/40 text-xs">가장 많이 조회된 공개 폴더</p>
              </div>
            </div>

            <div className="space-y-3">
              {popularFolders.map((folder, idx) => (
                <GlassCard 
                  key={folder.id}
                  hover
                  className="p-4"
                  onClick={() => window.location.href = createPageUrl(`SharedFolder?code=${folder.share_code}`)}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br from-[#4158F1] to-[#8B5CF6] flex items-center justify-center text-white font-bold text-sm">
                      #{idx + 1}
                    </div>
                    <div 
                      className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${folder.color}30` }}
                    >
                      <Globe className="w-6 h-6" style={{ color: folder.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-white font-medium line-clamp-1">{folder.name}</h3>
                      <div className="flex items-center gap-3 text-xs text-white/50 mt-1">
                        <span>👥 {folder.stats.unique}명</span>
                        <span>👀 {folder.stats.total}회</span>
                      </div>
                    </div>
                  </div>
                </GlassCard>
              ))}
            </div>
          </div>
        )}
        {/* Country Selector */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Globe className="w-5 h-5 text-white/70" />
            <h2 className="text-white font-semibold text-lg">국가별 인기 영상</h2>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {COUNTRIES.map(country => (
              <button
                key={country.code}
                onClick={() => setSelectedCountry(country.code)}
                className={cn(
                  "px-4 py-2 rounded-xl font-medium transition-all whitespace-nowrap",
                  selectedCountry === country.code
                    ? "bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white shadow-lg"
                    : "bg-white/5 text-white/70 hover:bg-white/10"
                )}
              >
                {country.flag} {country.name}
              </button>
            ))}
          </div>
        </div>

        {/* Trending Videos */}
        {loadingTrending ? (
          <div className="flex items-center justify-center py-20 mb-8">
            <Loader2 className="w-8 h-8 text-[#4158F1] animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
            <AnimatePresence mode="wait">
              {trendingVideos.map((video, index) => (
                <motion.div
                  key={video.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <GlassCard 
                    hover 
                    className="overflow-hidden"
                    onClick={() => playVideo({
                      id: video.id,
                      title: video.title,
                      url: `https://www.youtube.com/watch?v=${video.videoId}`,
                      embed_id: video.videoId,
                      platform: 'youtube',
                      thumbnail_url: video.thumbnail
                    }, trendingVideos.map(v => ({
                      id: v.id,
                      title: v.title,
                      url: `https://www.youtube.com/watch?v=${v.videoId}`,
                      embed_id: v.videoId,
                      platform: 'youtube',
                      thumbnail_url: v.thumbnail
                    })))}
                  >
                    <div className="relative aspect-video bg-white/5">
                      <img 
                        src={video.thumbnail}
                        alt={video.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                      
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <div className="w-14 h-14 rounded-full bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] flex items-center justify-center shadow-lg">
                          <Play className="w-6 h-6 text-white ml-1" fill="white" />
                        </div>
                      </div>

                      {video.duration && (
                        <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/80 text-white text-xs">
                          {video.duration}
                        </div>
                      )}
                    </div>

                    <div className="p-3">
                      <h3 className="text-white font-medium text-sm line-clamp-2 mb-1">
                        {video.title}
                      </h3>
                      <div className="flex items-center justify-between text-xs text-white/50">
                        <span className="line-clamp-1">{video.channelTitle}</span>
                        {video.viewCount && <span className="ml-2">조회수 {video.viewCount}</span>}
                      </div>
                    </div>
                  </GlassCard>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        {/* AI Recommendations Section */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#FFD60A]/20 to-[#FFD60A]/5 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-[#FFD60A]" />
            </div>
            <div>
              <h2 className="text-white font-semibold">AI 맞춤 추천</h2>
              <p className="text-white/40 text-xs">당신의 취향을 분석했어요</p>
            </div>
          </div>

          {videosLoading || isGenerating ? (
            <div className="flex flex-col items-center justify-center py-16">
              <div className="relative">
                <div className="w-16 h-16 rounded-full bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] animate-pulse" />
                <Sparkles className="w-6 h-6 text-[#FFD60A] absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
              </div>
              <p className="text-white/50 text-sm mt-4">
                {videosLoading ? '영상 분석 중...' : 'AI가 추천을 생성하고 있어요...'}
              </p>
            </div>
          ) : userVideos.length === 0 ? (
            <GlassCard className="p-8 text-center">
              <Sparkles className="w-12 h-12 text-white/20 mx-auto mb-4" />
              <h3 className="text-white font-medium mb-2">영상을 저장해보세요!</h3>
              <p className="text-white/50 text-sm">
                영상을 저장하면 AI가 취향에 맞는<br />
                영상을 추천해드려요
              </p>
            </GlassCard>
          ) : recommendations.length === 0 ? (
            <GlassCard className="p-8 text-center">
              <GradientButton onClick={generateRecommendations} icon={Sparkles}>
                추천 받기
              </GradientButton>
            </GlassCard>
          ) : (
            <div className="space-y-6">
              <AnimatePresence>
                {recommendations.map((rec, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <div className="mb-3">
                      <div className="flex items-center gap-2 mb-3">
                        {rec.category && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-500/20 text-red-400">
                            {rec.category}
                          </span>
                        )}
                        <h3 className="text-white font-medium text-sm">
                          {rec.search_query}
                        </h3>
                      </div>
                      
                      <div className="flex items-start gap-2 p-3 rounded-xl bg-gradient-to-r from-[#FFD60A]/10 to-[#FFD60A]/5 border border-[#FFD60A]/20 mb-3">
                        <Sparkles className="w-3 h-3 text-[#FFD60A] flex-shrink-0 mt-0.5" />
                        <p className="text-white/70 text-xs leading-relaxed">
                          {rec.reason}
                        </p>
                      </div>
                    </div>

                    {rec.videos && rec.videos.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        {rec.videos.map((video, vIdx) => (
                        <GlassCard 
                          key={vIdx}
                          hover 
                          className="overflow-hidden group relative"
                        >
                          <div 
                            className="cursor-pointer"
                            onClick={() => playVideo({
                              id: video.videoId,
                              title: video.title,
                              url: `https://www.youtube.com/watch?v=${video.videoId}`,
                              embed_id: video.videoId,
                              platform: 'youtube',
                              thumbnail_url: video.thumbnail
                            }, [])}
                          >
                            <div className="relative aspect-video bg-white/5">
                              <img 
                                src={video.thumbnail}
                                alt={video.title}
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                              
                              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] flex items-center justify-center shadow-lg">
                                  <Play className="w-5 h-5 text-white ml-0.5" fill="white" />
                                </div>
                              </div>
                            </div>

                            <div className="p-2">
                              <h4 className="text-white text-xs line-clamp-2 mb-1">
                                {video.title}
                              </h4>
                              <p className="text-white/50 text-[10px] line-clamp-1">
                                {video.channelTitle}
                              </p>
                            </div>
                          </div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setAddingVideo(video);
                            }}
                            className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/60 hover:bg-black/80 transition-colors opacity-0 group-hover:opacity-100"
                          >
                            <FolderPlus className="w-4 h-4 text-white" />
                          </button>
                        </GlassCard>
                        ))}
                      </div>
                    ) : (
                      <div className="p-4 text-center">
                        <p className="text-white/50 text-sm">영상을 불러오는 중...</p>
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      {/* Add to Folder Modal */}
      {addingVideo && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <GlassCard className="w-full max-w-md p-6">
            <h3 className="text-white font-semibold text-lg mb-4">폴더에 추가</h3>
            <p className="text-white/70 text-sm mb-4 line-clamp-2">{addingVideo.title}</p>
            
            <div className="space-y-2 mb-6 max-h-60 overflow-y-auto">
              {folders.map(folder => (
                <button
                  key={folder.id}
                  onClick={() => setSelectedFolder(folder.id)}
                  className={cn(
                    "w-full p-3 rounded-xl text-left transition-all",
                    selectedFolder === folder.id
                      ? "bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white"
                      : "bg-white/5 text-white hover:bg-white/10"
                  )}
                >
                  {folder.name}
                </button>
              ))}
            </div>

            <div className="flex gap-3">
              <GradientButton
                variant="ghost"
                fullWidth
                onClick={() => {
                  setAddingVideo(null);
                  setSelectedFolder(null);
                }}
              >
                취소
              </GradientButton>
              <GradientButton
                fullWidth
                onClick={handleAddToFolder}
                disabled={!selectedFolder}
              >
                추가
              </GradientButton>
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  );
}