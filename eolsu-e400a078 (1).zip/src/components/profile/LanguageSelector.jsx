import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Check } from 'lucide-react';
import { useLanguage } from '@/components/i18n/LanguageContext';
import { languageOptions } from '@/components/i18n/translations';
import { cn } from "@/lib/utils";

export default function LanguageSelector({ open, onClose }) {
  const { language, changeLanguage } = useLanguage();

  const handleSelect = (langCode) => {
    changeLanguage(langCode);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#161B22] border-white/10 text-white max-w-sm mx-4">
        <DialogHeader>
          <DialogTitle className="text-xl">Select Language</DialogTitle>
        </DialogHeader>

        <div className="space-y-2 mt-4">
          {languageOptions.map((lang) => (
            <button
              key={lang.code}
              onClick={() => handleSelect(lang.code)}
              className={cn(
                "w-full flex items-center gap-3 p-3 rounded-xl transition-all",
                language === lang.code
                  ? "bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white"
                  : "bg-white/5 hover:bg-white/10 text-white"
              )}
            >
              <span className="text-2xl">{lang.flag}</span>
              <span className="flex-1 text-left font-medium">{lang.name}</span>
              {language === lang.code && (
                <Check className="w-5 h-5" />
              )}
            </button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}