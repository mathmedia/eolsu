import React from 'react';
import { cn } from "@/lib/utils";

export default function GlassCard({ 
  children, 
  className = '', 
  hover = false,
  glow = false,
  onClick 
}) {
  return (
    <div 
      onClick={onClick}
      className={cn(
        "relative rounded-2xl overflow-hidden",
        "bg-white/5 backdrop-blur-xl",
        "border border-white/10",
        hover && "cursor-pointer transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:scale-[1.02]",
        glow && "shadow-[0_0_30px_rgba(65,88,241,0.15)]",
        className
      )}
    >
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}