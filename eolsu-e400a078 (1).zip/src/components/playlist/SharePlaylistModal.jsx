import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Globe, Lock, Copy, Check, Trash2, Mail } from 'lucide-react';
import GradientButton from '@/components/ui/GradientButton';
import GlassCard from '@/components/ui/GlassCard';
import { createPageUrl } from '@/utils';

export default function SharePlaylistModal({ 
  open, 
  onClose, 
  playlist,
  sharedUsers = [],
  onShareByEmail,
  onRemoveShare,
  loading 
}) {
  const [email, setEmail] = useState('');
  const [copied, setCopied] = useState(false);

  const shareLink = playlist?.is_public 
    ? `${window.location.origin}${createPageUrl(`SharedPlaylist?code=${playlist.share_code}`)}`
    : null;

  const copyLink = () => {
    if (shareLink) {
      navigator.clipboard.writeText(shareLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShareByEmail = () => {
    if (email.trim()) {
      onShareByEmail(email.trim());
      setEmail('');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#161B22] border-white/10 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            {playlist?.is_public ? (
              <><Globe className="w-5 h-5 text-[#8B5CF6]" /> 공개 재생목록</>
            ) : (
              <><Lock className="w-5 h-5 text-white/50" /> 비공개 재생목록</>
            )}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Public Link */}
          {playlist?.is_public && shareLink && (
            <div>
              <p className="text-white/70 text-sm mb-2">공개 링크</p>
              <div className="flex gap-2">
                <Input
                  value={shareLink}
                  readOnly
                  className="bg-white/5 border-white/10 text-white text-xs"
                />
                <GradientButton
                  size="sm"
                  variant="ghost"
                  onClick={copyLink}
                  icon={copied ? Check : Copy}
                >
                  {copied ? '복사됨' : '복사'}
                </GradientButton>
              </div>
            </div>
          )}

          {/* Share by Email */}
          <div>
            <p className="text-white/70 text-sm mb-2">이메일로 공유</p>
            <div className="flex gap-2">
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="example@email.com"
                className="bg-white/5 border-white/10 text-white"
                onKeyPress={(e) => e.key === 'Enter' && handleShareByEmail()}
              />
              <GradientButton
                size="sm"
                onClick={handleShareByEmail}
                disabled={!email.trim() || loading}
                icon={Mail}
              >
                공유
              </GradientButton>
            </div>
          </div>

          {/* Shared Users List */}
          {sharedUsers.length > 0 && (
            <div>
              <p className="text-white/70 text-sm mb-2">공유된 사용자</p>
              <GlassCard className="p-3">
                <div className="space-y-2">
                  {sharedUsers.map((share) => (
                    <div key={share.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                      <span className="text-white text-sm">{share.shared_with_email}</span>
                      <button
                        onClick={() => onRemoveShare(share.id)}
                        className="p-1 rounded-lg hover:bg-red-500/20 transition-colors"
                      >
                        <Trash2 className="w-4 h-4 text-red-400" />
                      </button>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}