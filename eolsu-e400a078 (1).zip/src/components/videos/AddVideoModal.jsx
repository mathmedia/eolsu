import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import GradientButton from '@/components/ui/GradientButton';
import { Link2, Image, FileText, Play, Loader2, Upload, Music, X, Video } from 'lucide-react';
import { getVideoIdFromUrl, fetchVideoDetails } from '@/components/utils/youtubeApi';
import { base44 } from '@/api/base44Client';

function detectPlatform(url) {
  if (!url) return 'other';
  if (url.includes('youtube.com') || url.includes('youtu.be')) return 'youtube';
  if (url.includes('tiktok.com')) return 'tiktok';
  if (url.includes('instagram.com')) return 'instagram';
  if (url.includes('facebook.com') || url.includes('fb.watch')) return 'facebook';
  return 'other';
}

function extractVideoId(url, platform) {
  if (platform === 'youtube') {
    // Support: watch?v=, youtu.be/, embed/, and shorts/
    const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([^&\s?]+)/);
    return match ? match[1] : null;
  }
  return null;
}

export default function AddVideoModal({ 
  open, 
  onClose, 
  onSubmit, 
  folderId,
  editingVideo = null,
  loading = false 
}) {
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [platform, setPlatform] = useState('youtube');
  const [notes, setNotes] = useState('');
  const [duration, setDuration] = useState('');
  const [fetchingDetails, setFetchingDetails] = useState(false);
  const [audioUrl, setAudioUrl] = useState('');
  const [videoFileUrl, setVideoFileUrl] = useState('');
  const [musicVideoPhotoUrls, setMusicVideoPhotoUrls] = useState([]);
  const [uploadingAudio, setUploadingAudio] = useState(false);
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  useEffect(() => {
    if (editingVideo) {
      setUrl(editingVideo.url || '');
      setTitle(editingVideo.title || '');
      setThumbnailUrl(editingVideo.thumbnail_url || '');
      setPlatform(editingVideo.platform || 'youtube');
      setNotes(editingVideo.notes || '');
      setDuration(editingVideo.duration || '');
      setAudioUrl(editingVideo.audio_url || '');
      setVideoFileUrl(editingVideo.video_file_url || '');
      setMusicVideoPhotoUrls(editingVideo.music_video_photo_urls || []);
    } else {
      resetForm();
    }
  }, [editingVideo, open]);

  useEffect(() => {
    if (url && !editingVideo) {
      const detected = detectPlatform(url);
      setPlatform(detected);
      
      // Auto-fetch details from YouTube API
      if (detected === 'youtube') {
        const videoId = getVideoIdFromUrl(url);
        if (videoId) {
          setFetchingDetails(true);
          fetchVideoDetails(videoId)
            .then(details => {
              if (details) {
                setTitle(details.title);
                setThumbnailUrl(details.thumbnail);
                setDuration(details.duration);
              }
            })
            .catch(err => console.error('Failed to fetch video details:', err))
            .finally(() => setFetchingDetails(false));
        }
      }
    }
  }, [url, editingVideo]);

  const resetForm = () => {
    setUrl('');
    setTitle('');
    setThumbnailUrl('');
    setPlatform('youtube');
    setNotes('');
    setDuration('');
    setAudioUrl('');
    setVideoFileUrl('');
    setMusicVideoPhotoUrls([]);
  };

  const handleSubmit = () => {
    console.log('Submit clicked - audioUrl:', audioUrl, 'videoFileUrl:', videoFileUrl, 'title:', title, 'url:', url);
    
    // Must have either audio, video file, or URL
    if (!audioUrl && !videoFileUrl && !url.trim()) {
      alert('오디오/영상을 업로드하거나 영상 URL을 입력해주세요');
      return;
    }
    if (!title.trim()) {
      alert('제목을 입력해주세요');
      return;
    }
    
    const embedId = extractVideoId(url, platform);
    
    // Determine final URL and platform
    let finalUrl = url.trim();
    let finalPlatform = platform;
    
    if (videoFileUrl && !url) {
      finalUrl = videoFileUrl;
      finalPlatform = 'uploaded_video';
    } else if (audioUrl && !url) {
      finalUrl = audioUrl;
      finalPlatform = 'audio';
    }
    
    onSubmit({
      url: finalUrl,
      title: title.trim(),
      thumbnail_url: thumbnailUrl.trim() || null,
      platform: finalPlatform,
      notes: notes.trim() || null,
      duration: duration.trim() || null,
      embed_id: embedId,
      folder_id: folderId,
      audio_url: audioUrl || null,
      video_file_url: videoFileUrl || null,
      music_video_photo_urls: musicVideoPhotoUrls.length > 0 ? musicVideoPhotoUrls : null
    });
    
    if (!editingVideo) resetForm();
  };

  const handleAudioUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file extension as fallback
    const fileName = file.name.toLowerCase();
    const isAudio = file.type.startsWith('audio/') || 
                    fileName.endsWith('.mp3') || 
                    fileName.endsWith('.wav') || 
                    fileName.endsWith('.m4a') ||
                    fileName.endsWith('.aac') ||
                    fileName.endsWith('.ogg');

    if (!isAudio) {
      alert('오디오 파일만 업로드 가능합니다 (MP3, WAV, M4A, AAC, OGG)');
      return;
    }

    setUploadingAudio(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setAudioUrl(file_url);
      
      // Auto-fill title with filename if title is empty
      if (!title.trim()) {
        const fileNameWithoutExt = file.name.replace(/\.[^/.]+$/, '');
        setTitle(fileNameWithoutExt);
      }
      
      console.log('Audio uploaded successfully:', file_url);
    } catch (error) {
      console.error('Audio upload failed:', error);
      alert('오디오 업로드 실패: ' + (error.message || '알 수 없는 오류'));
    } finally {
      setUploadingAudio(false);
    }
  };

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setUploadingPhoto(true);
    try {
      const uploadPromises = files.map(async (file) => {
        if (!file.type.startsWith('image/')) {
          return null;
        }
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        return file_url;
      });

      const uploadedUrls = await Promise.all(uploadPromises);
      const validUrls = uploadedUrls.filter(url => url !== null);
      setMusicVideoPhotoUrls(prev => [...prev, ...validUrls]);
    } catch (error) {
      console.error('Photo upload failed:', error);
    } finally {
      setUploadingPhoto(false);
      // Reset input so same files can be selected again
      e.target.value = '';
    }
  };

  const removePhoto = (indexToRemove) => {
    setMusicVideoPhotoUrls(prev => prev.filter((_, index) => index !== indexToRemove));
  };

  const handleVideoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileName = file.name.toLowerCase();
    const isVideo = file.type.startsWith('video/') || 
                    fileName.endsWith('.mp4') || 
                    fileName.endsWith('.webm') || 
                    fileName.endsWith('.mov') ||
                    fileName.endsWith('.avi') ||
                    fileName.endsWith('.mkv');

    if (!isVideo) {
      alert('비디오 파일만 업로드 가능합니다 (MP4, WEBM, MOV 등)');
      return;
    }

    setUploadingVideo(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setVideoFileUrl(file_url);
      
      // Auto-fill title with filename if title is empty
      if (!title.trim()) {
        const fileNameWithoutExt = file.name.replace(/\.[^/.]+$/, '');
        setTitle(fileNameWithoutExt);
      }
      
      console.log('Video uploaded successfully:', file_url);
    } catch (error) {
      console.error('Video upload failed:', error);
      alert('비디오 업로드 실패: ' + (error.message || '알 수 없는 오류'));
    } finally {
      setUploadingVideo(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#161B22] border-white/10 text-white max-w-md mx-4 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Play className="w-5 h-5 text-[#8B5CF6]" />
            {editingVideo ? '콘텐츠 수정' : '콘텐츠 추가'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {/* Upload Section */}
          <div className="space-y-3 p-4 rounded-xl bg-gradient-to-br from-[#4158F1]/10 to-[#8B5CF6]/10 border border-[#4158F1]/20">
            <p className="text-white font-medium flex items-center gap-2">
              <Upload className="w-4 h-4" />
              📤 파일 업로드
            </p>
            
            {/* Video Upload */}
            <div>
              <label
                htmlFor="video-upload"
                className={`flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer ${
                  videoFileUrl 
                    ? 'bg-[#8B5CF6]/10 border-[#8B5CF6]/50' 
                    : 'bg-white/5 border-white/10 hover:border-[#8B5CF6]/50'
                }`}
              >
                {uploadingVideo ? (
                  <Loader2 className="w-5 h-5 text-[#8B5CF6] animate-spin" />
                ) : videoFileUrl ? (
                  <Video className="w-5 h-5 text-[#8B5CF6]" />
                ) : (
                  <Video className="w-5 h-5 text-white/50" />
                )}
                <div className="flex-1">
                  <p className={`text-sm font-medium ${videoFileUrl ? 'text-[#8B5CF6]' : 'text-white'}`}>
                    {videoFileUrl ? '비디오 업로드 완료 ✓' : '비디오 파일 업로드 (MP4, WEBM, MOV 등)'}
                  </p>
                  {videoFileUrl && (
                    <p className="text-white/40 text-xs mt-0.5">클릭하여 변경</p>
                  )}
                </div>
                {videoFileUrl && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setVideoFileUrl('');
                    }}
                    className="p-1 rounded-full bg-red-500/20 hover:bg-red-500/30 border border-red-500/50"
                  >
                    <X className="w-4 h-4 text-red-400" />
                  </button>
                )}
              </label>
              <input
                id="video-upload"
                type="file"
                accept="video/*"
                onChange={handleVideoUpload}
                disabled={uploadingVideo}
                className="hidden"
              />
            </div>
            
            {/* Audio Upload */}
            <div>
              <label
                htmlFor="audio-upload"
                className={`flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer ${
                  audioUrl 
                    ? 'bg-[#4158F1]/10 border-[#4158F1]/50' 
                    : 'bg-white/5 border-white/10 hover:border-[#4158F1]/50'
                }`}
              >
                {uploadingAudio ? (
                  <Loader2 className="w-5 h-5 text-[#4158F1] animate-spin" />
                ) : audioUrl ? (
                  <Music className="w-5 h-5 text-[#4158F1]" />
                ) : (
                  <Upload className="w-5 h-5 text-white/50" />
                )}
                <div className="flex-1">
                  <p className={`text-sm font-medium ${audioUrl ? 'text-[#4158F1]' : 'text-white'}`}>
                    {audioUrl ? '오디오 업로드 완료 ✓' : '오디오 파일 업로드 (MP3, WAV 등)'}
                  </p>
                  {audioUrl && (
                    <p className="text-white/40 text-xs mt-0.5">클릭하여 변경</p>
                  )}
                </div>
                {audioUrl && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setAudioUrl('');
                    }}
                    className="p-1 rounded-full bg-red-500/20 hover:bg-red-500/30 border border-red-500/50"
                  >
                    <X className="w-4 h-4 text-red-400" />
                  </button>
                )}
              </label>
              <input
                id="audio-upload"
                type="file"
                accept="audio/*"
                onChange={handleAudioUpload}
                disabled={uploadingAudio}
                className="hidden"
              />
            </div>

            {/* Photo Upload */}
            <div>
              <label
                htmlFor="photo-upload"
                className={`flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer ${
                  musicVideoPhotoUrls.length > 0
                    ? 'bg-[#FFD60A]/10 border-[#FFD60A]/50'
                    : 'bg-white/5 border-white/10 hover:border-[#4158F1]/50'
                }`}
              >
                {uploadingPhoto ? (
                  <Loader2 className="w-5 h-5 text-[#4158F1] animate-spin" />
                ) : musicVideoPhotoUrls.length > 0 ? (
                  <Image className="w-5 h-5 text-[#FFD60A]" />
                ) : (
                  <Image className="w-5 h-5 text-white/50" />
                )}
                <div className="flex-1">
                  <p className={`text-sm font-medium ${musicVideoPhotoUrls.length > 0 ? 'text-[#FFD60A]' : 'text-white'}`}>
                    {musicVideoPhotoUrls.length > 0 ? `${musicVideoPhotoUrls.length}장 업로드 완료 ✓` : '배경 사진 업로드 (여러 장 가능)'}
                  </p>
                  {musicVideoPhotoUrls.length > 0 && (
                    <p className="text-white/40 text-xs mt-0.5">클릭하여 추가</p>
                  )}
                </div>
              </label>
              <input
                id="photo-upload"
                type="file"
                accept="image/*"
                multiple
                onChange={handlePhotoUpload}
                disabled={uploadingPhoto}
                className="hidden"
              />
              
              {/* Photo Grid Preview */}
              {musicVideoPhotoUrls.length > 0 && (
                <div className="mt-2 grid grid-cols-3 gap-2">
                  {musicVideoPhotoUrls.map((url, index) => (
                    <div key={index} className="relative aspect-video rounded-lg overflow-hidden bg-white/5 group">
                      <img 
                        src={url} 
                        alt={`Photo ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() => removePhoto(index)}
                        className="absolute top-1 right-1 p-1 rounded-full bg-black/70 hover:bg-black/90 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-3 h-3 text-white" />
                      </button>
                      <div className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/70 text-white text-xs">
                        {index + 1}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Divider */}
          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-white/40 text-xs">또는</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>

          {/* Video URL */}
          <div className="space-y-2">
            <Label className="text-white/70 flex items-center gap-2">
              <Link2 className="w-4 h-4" /> 영상 URL (선택사항)
              {fetchingDetails && <Loader2 className="w-3 h-3 animate-spin text-[#4158F1]" />}
            </Label>
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://youtube.com/watch?v=..."
              className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-[#4158F1]"
              disabled={fetchingDetails || audioUrl || videoFileUrl}
            />
            {fetchingDetails && (
              <p className="text-xs text-white/50">YouTube에서 정보를 가져오는 중...</p>
            )}
            {(audioUrl || videoFileUrl) && (
              <p className="text-xs text-white/40">파일을 업로드했으므로 URL은 필요하지 않아요</p>
            )}
          </div>

          {/* Platform Selection - only show if URL is provided */}
          {url && !audioUrl && !videoFileUrl && (
            <div className="space-y-2">
              <Label className="text-white/70">플랫폼</Label>
              <Select value={platform} onValueChange={setPlatform}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#1C2128] border-white/10 text-white">
                  <SelectItem value="youtube">YouTube</SelectItem>
                  <SelectItem value="tiktok">TikTok</SelectItem>
                  <SelectItem value="instagram">Instagram Reels</SelectItem>
                  <SelectItem value="facebook">Facebook</SelectItem>
                  <SelectItem value="other">기타</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Title */}
          <div className="space-y-2">
            <Label className="text-white/70 flex items-center gap-2">
              <FileText className="w-4 h-4" /> 
              제목
              <span className="text-red-400 text-sm">*</span>
            </Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={audioUrl ? "자동 입력됨 (수정 가능)" : "제목을 입력하세요"}
              className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-[#4158F1]"
            />
            {!title.trim() && (
              <p className="text-red-400/70 text-xs">제목은 필수 항목입니다</p>
            )}
          </div>

          {/* Thumbnail URL - only show if URL is provided */}
          {url && !audioUrl && !videoFileUrl && (
            <div className="space-y-2">
              <Label className="text-white/70 flex items-center gap-2">
                <Image className="w-4 h-4" /> 썸네일 URL (선택)
              </Label>
              <Input
                value={thumbnailUrl}
                onChange={(e) => setThumbnailUrl(e.target.value)}
                placeholder="https://..."
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-[#4158F1]"
              />
              {thumbnailUrl && (
                <div className="rounded-lg overflow-hidden aspect-video bg-white/5">
                  <img 
                    src={thumbnailUrl} 
                    alt="Thumbnail preview"
                    className="w-full h-full object-cover"
                    onError={(e) => e.target.style.display = 'none'}
                  />
                </div>
              )}
            </div>
          )}

          {/* Duration */}
          {(url || audioUrl || videoFileUrl) && (
            <div className="space-y-2">
              <Label className="text-white/70">길이 (선택)</Label>
              <Input
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                placeholder="예: 3:45"
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-[#4158F1]"
              />
            </div>
          )}

          {/* Notes */}
          <div className="space-y-2">
            <Label className="text-white/70">메모 (선택)</Label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={audioUrl ? "이 음악에 대한 메모..." : videoFileUrl ? "이 영상에 대한 메모..." : "이 콘텐츠에 대한 메모..."}
              rows={3}
              className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-[#4158F1] resize-none"
            />
          </div>

          {/* Submit Button */}
          <div className="space-y-2">
            <GradientButton 
              fullWidth 
              onClick={handleSubmit}
              loading={loading}
              disabled={(!audioUrl && !videoFileUrl && !url.trim()) || !title.trim()}
            >
              {editingVideo ? '수정 완료' : (audioUrl ? '음악 추가' : videoFileUrl ? '영상 추가' : '콘텐츠 추가')}
            </GradientButton>
            {(!audioUrl && !videoFileUrl && !url.trim()) && (
              <p className="text-white/40 text-xs text-center">
                파일을 업로드하거나 영상 URL을 입력하세요
              </p>
            )}
            {(audioUrl || videoFileUrl || url.trim()) && !title.trim() && (
              <p className="text-red-400/70 text-xs text-center">
                제목을 입력해주세요
              </p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}