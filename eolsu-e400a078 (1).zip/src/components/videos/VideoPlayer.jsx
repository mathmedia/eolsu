import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { X, ExternalLink, ChevronLeft, ChevronRight, Maximize2, Image, Check, Play, Pause } from 'lucide-react';
import { cn } from "@/lib/utils";
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export default function VideoPlayer({ 
  video, 
  open, 
  minimized = false,
  onClose,
  onMinimize,
  playlist = [],
  onNavigate,
  repeatMode = false
}) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showOverlay, setShowOverlay] = useState(true);
  const [iframeSrc, setIframeSrc] = useState('');
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [user, setUser] = useState(null);
  const [showPhotoSelector, setShowPhotoSelector] = useState(false);
  const [selectedPhotos, setSelectedPhotos] = useState([]);
  const playerRef = useRef(null);
  const playerIdRef = useRef(`player-${Date.now()}`);
  const autoNextTimerRef = useRef(null);
  const photoIntervalRef = useRef(null);
  const audioRef = useRef(null);
  const videoEndTimerRef = useRef(null);
  const [audioPlaying, setAudioPlaying] = useState(false);
  const savedTimeRef = useRef(0);
  
  // Store latest values to avoid stale closures
  const repeatModeRef = useRef(repeatMode);
  const playlistRef = useRef(playlist);
  const onNavigateRef = useRef(onNavigate);
  const mountedRef = useRef(true);
  
  useEffect(() => {
    repeatModeRef.current = repeatMode;
    playlistRef.current = playlist;
    onNavigateRef.current = onNavigate;
  }, [repeatMode, playlist, onNavigate]);

  // Cleanup on unmount - MUST be first to ensure cleanup happens
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      // Clear all timers to prevent state updates after unmount
      if (autoNextTimerRef.current) {
        clearTimeout(autoNextTimerRef.current);
        autoNextTimerRef.current = null;
      }
      if (photoIntervalRef.current) {
        clearInterval(photoIntervalRef.current);
        photoIntervalRef.current = null;
      }
      if (videoEndTimerRef.current) {
        clearTimeout(videoEndTimerRef.current);
        videoEndTimerRef.current = null;
      }
    };
  }, []);

  const getVideoId = () => {
    if (!video) return null;
    if (video.embed_id) return video.embed_id;
    if (video.platform === 'youtube' && video.url) {
      const match = video.url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([^&\s?]+)/);
      if (match) return match[1];
    }
    return null;
  };

  const videoId = getVideoId();
  const canEmbed = video?.platform && ['youtube', 'facebook', 'tiktok', 'instagram', 'audio', 'uploaded_video'].includes(video.platform);
  const needsOverlay = video?.platform && ['facebook', 'tiktok', 'instagram'].includes(video.platform);
  const isAudio = video?.platform === 'audio';
  const isUploadedVideo = video?.platform === 'uploaded_video';
  
  const currentIndex = video ? playlist.findIndex(v => v.id === video.id) : -1;
  const hasPrev = currentIndex > 0;
  const hasNext = currentIndex < playlist.length - 1;

  // Fetch user and memory photos
  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: memoryPhotos = [] } = useQuery({
    queryKey: ['memoryPhotos', user?.email],
    queryFn: () => base44.entities.MemoryPhoto.filter({ owner_email: user?.email }),
    enabled: !!user?.email && open,
  });

  const timeCapsuleMode = user?.timecapsule_mode || 'minimal';
  const photoOpacity = user?.photo_opacity || 0.5;
  const photoPosition = user?.photo_position || 'full';
  const displayPhotos = selectedPhotos.length > 0 
    ? memoryPhotos.filter(p => selectedPhotos.includes(p.id))
    : [];

  const togglePhotoSelection = (photoId) => {
    setSelectedPhotos(prev => 
      prev.includes(photoId) 
        ? prev.filter(id => id !== photoId)
        : [...prev, photoId]
    );
  };

  const getEmbedUrl = () => {
    if (!video) return '';
    
    if (video.platform === 'facebook') {
      return `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(video.url)}&show_text=false&autoplay=false`;
    }
    
    if (video.platform === 'tiktok') {
      const match = video.url.match(/tiktok\.com\/@[^\/]+\/video\/(\d+)/);
      if (match) {
        return `https://www.tiktok.com/embed/${match[1]}`;
      }
    }
    
    if (video.platform === 'instagram') {
      const match = video.url.match(/instagram\.com\/(?:p|reel)\/([^\/\?]+)/);
      if (match) {
        return `https://www.instagram.com/p/${match[1]}/embed`;
      }
    }
    
    return '';
  };

  const handleOverlayClick = () => {
    setShowOverlay(false);
    
    // Auto-advance for non-YouTube videos after 30 seconds
    if (needsOverlay && onNavigate) {
      autoNextTimerRef.current = setTimeout(() => {
        if (hasNext) {
          onNavigate(playlist[currentIndex + 1]);
        } else if (repeatMode && playlist.length > 0) {
          onNavigate(playlist[0]);
        }
      }, 30000);
    }
  };

  const handlePrev = () => {
    if (autoNextTimerRef.current) {
      clearTimeout(autoNextTimerRef.current);
    }
    if (hasPrev && onNavigate) {
      onNavigate(playlist[currentIndex - 1]);
    }
  };

  const handleNext = () => {
    if (autoNextTimerRef.current) {
      clearTimeout(autoNextTimerRef.current);
    }
    if (hasNext && onNavigate) {
      onNavigate(playlist[currentIndex + 1]);
    } else if (repeatMode && playlist.length > 0 && onNavigate) {
      // Loop back to first video
      onNavigate(playlist[0]);
    }
  };

  // Reset overlay when video changes
  useEffect(() => {
    setShowOverlay(needsOverlay);
    setIframeSrc(getEmbedUrl());
    setCurrentPhotoIndex(0);
    
    return () => {
      if (autoNextTimerRef.current) {
        clearTimeout(autoNextTimerRef.current);
      }
    };
  }, [video?.id]);

  // Photo slideshow - for both memory photos and music video photos
  useEffect(() => {
    const photoCount = displayPhotos.length || video?.music_video_photo_urls?.length || 0;
    const slideInterval = (user?.photo_slide_interval || 5) * 1000; // Convert seconds to milliseconds
    
    if (open && photoCount > 1) {
      photoIntervalRef.current = setInterval(() => {
        setCurrentPhotoIndex(prev => (prev + 1) % photoCount);
      }, slideInterval);
    }
    
    return () => {
      if (photoIntervalRef.current) {
        clearInterval(photoIntervalRef.current);
      }
    };
  }, [open, displayPhotos.length, video?.music_video_photo_urls?.length, user?.photo_slide_interval]);

  // Toggle audio playback
  const toggleAudioPlayback = () => {
    if (!audioRef.current) return;

    if (audioRef.current.paused) {
      audioRef.current.play();
      setAudioPlaying(true);
    } else {
      audioRef.current.pause();
      setAudioPlaying(false);
    }
  };

  // Load YouTube API once
  useEffect(() => {
    if (typeof window !== 'undefined' && !window.YT) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      const firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
    }
  }, []);

  // Initialize player when video changes
  useEffect(() => {
    if (!(open || minimized) || !canEmbed) return;
    if (video?.platform === 'youtube' && !videoId) return;

    let timeoutId;
    let mounted = true;

    const initPlayer = () => {
      if (!mounted) return;
      
      const playerId = playerIdRef.current;
      const playerElement = document.getElementById(playerId);
      
      if (!playerElement) {
        timeoutId = setTimeout(initPlayer, 100);
        return;
      }

      // Clean up previous player
      if (playerRef.current) {
        try {
          if (typeof playerRef.current.destroy === 'function') {
            playerRef.current.destroy();
          }
        } catch (e) {
          // Ignore errors
        }
        playerRef.current = null;
      }

      // Clear container safely - check if element still exists
      const currentElement = document.getElementById(playerId);
      if (currentElement && currentElement.parentNode) {
        try {
          currentElement.innerHTML = '';
        } catch (e) {
          // Ignore errors
        }
      }

      if (!mounted) return;

      try {
        if (video?.platform === 'youtube') {
          playerRef.current = new window.YT.Player(playerId, {
            videoId: videoId,
            width: '100%',
            height: '100%',
            playerVars: {
              autoplay: 1,
              rel: 0,
              modestbranding: 1,
            },
            events: {
              onReady: (event) => {
                // Restore saved time position if exists
                if (savedTimeRef.current > 0 && mounted) {
                  event.target.seekTo(savedTimeRef.current, true);
                  savedTimeRef.current = 0;
                }
              },
              onStateChange: (event) => {
                // Video ended
                if (event.data === 0) {
                  // Clear any existing timer first
                  if (videoEndTimerRef.current) {
                    clearTimeout(videoEndTimerRef.current);
                    videoEndTimerRef.current = null;
                  }

                  // Only proceed if still mounted
                  if (!mountedRef.current) return;

                  videoEndTimerRef.current = setTimeout(() => {
                    // Double check mounted state inside timeout
                    if (!mountedRef.current || !onNavigateRef.current) {
                      return;
                    }

                    const currentPlaylist = playlistRef.current;
                    const currentRepeatMode = repeatModeRef.current;
                    const currentIdx = currentPlaylist.findIndex(v => v.id === video?.id);
                    const hasNextVideo = currentIdx < currentPlaylist.length - 1;

                    if (hasNextVideo) {
                      onNavigateRef.current(currentPlaylist[currentIdx + 1]);
                    } else if (currentRepeatMode && currentPlaylist.length > 0) {
                      onNavigateRef.current(currentPlaylist[0]);
                    }

                    videoEndTimerRef.current = null;
                  }, 1000);
                }
              },
            },
          });
        }
      } catch (e) {
        console.error('Error creating player:', e);
      }
    };

    if (video?.platform === 'youtube') {
      if (window.YT && window.YT.Player) {
        initPlayer();
      } else {
        window.onYouTubeIframeAPIReady = initPlayer;
      }
    }

    return () => {
      mounted = false;
      if (timeoutId) clearTimeout(timeoutId);
      if (videoEndTimerRef.current) clearTimeout(videoEndTimerRef.current);
    };
    }, [open, minimized, videoId, hasNext, currentIndex]);

    // Cleanup player only when component unmounts completely
    useEffect(() => {
    return () => {
      if (playerRef.current) {
        try {
          if (typeof playerRef.current.destroy === 'function') {
            playerRef.current.destroy();
          }
        } catch (e) {
          // Ignore errors
        }
        playerRef.current = null;
      }
    };
    }, [video?.id]);

  if (!video) return null;

  // Minimized floating player
  if (minimized) {
    return (
      <div className="fixed bottom-20 right-4 z-50 w-64">
        <div className="bg-[#0D1117] border border-white/10 rounded-xl overflow-hidden shadow-2xl">
          <div className="relative aspect-video bg-black" onClick={() => window.useVideoPlayer?.maximizePlayer()}>
            {video.platform === 'youtube' && videoId && (
              <div 
                id={playerIdRef.current} 
                className="w-full h-full pointer-events-auto"
                style={{ pointerEvents: 'auto' }}
              />
            )}
            {video.platform === 'uploaded_video' && video.video_file_url && (
              <video
                ref={audioRef}
                src={video.video_file_url}
                controls
                className="w-full h-full"
                style={{ pointerEvents: 'auto' }}
              />
            )}
            {video.platform === 'audio' && video.audio_url && (
              <div className="w-full h-full bg-gradient-to-br from-[#0D1117] to-[#1C2128] flex items-center justify-center">
                <audio
                  ref={audioRef}
                  src={video.audio_url}
                  controls
                  className="w-full px-2"
                />
              </div>
            )}
          </div>
          <div className="p-3 flex items-center justify-between">
            <div className="flex-1 min-w-0 mr-2">
              <p className="text-white text-xs font-medium truncate">{video.title}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  // Save current time before maximizing
                  if (playerRef.current && typeof playerRef.current.getCurrentTime === 'function') {
                    try {
                      savedTimeRef.current = playerRef.current.getCurrentTime();
                    } catch (err) {
                      // Ignore
                    }
                  }
                  window.useVideoPlayer?.maximizePlayer();
                }}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
              >
                <Maximize2 className="w-4 h-4 text-white" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onClose();
                }}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <Dialog open={open} onOpenChange={() => {
      // Save current time before minimizing
      if (playerRef.current && typeof playerRef.current.getCurrentTime === 'function') {
        try {
          savedTimeRef.current = playerRef.current.getCurrentTime();
        } catch (e) {
          // Ignore
        }
      }
      onMinimize();
    }}>
      <DialogContent 
        className={cn(
          "bg-[#0D1117] border-white/10 text-white p-0 overflow-hidden",
          isFullscreen ? "max-w-[95vw] w-[95vw] h-[90vh]" : "max-w-3xl w-[95vw]"
        )}
      >
        {/* Header */}
        <div className="absolute top-0 left-0 right-0 z-20 p-4 bg-gradient-to-b from-black/80 to-transparent">
          <div className="flex items-center justify-between">
            <h3 className="text-white font-medium text-sm md:text-base line-clamp-1 pr-4 flex-1">
              {video.title}
            </h3>
            <div className="flex items-center gap-2">
              <button
                onClick={() => window.open(video.url, '_blank')}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
              </button>
              {memoryPhotos.length > 0 && (
                <button
                  onClick={() => setShowPhotoSelector(!showPhotoSelector)}
                  className={cn(
                    "p-2 rounded-full transition-colors",
                    selectedPhotos.length > 0 
                      ? "bg-[#FFD60A]/20 text-[#FFD60A]"
                      : "bg-white/10 hover:bg-white/20 text-white"
                  )}
                >
                  <Image className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors hidden md:block"
              >
                <Maximize2 className="w-4 h-4" />
              </button>
              {onMinimize && (
                <button
                  onClick={onMinimize}
                  className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={onClose}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Photo Selector Sidebar */}
        {showPhotoSelector && (
          <div className="absolute top-16 right-4 z-30 w-72 max-h-[70vh] bg-[#1C2128] border border-white/10 rounded-xl overflow-hidden shadow-2xl">
            <div className="p-3 border-b border-white/10 flex items-center justify-between">
              <span className="text-white font-medium text-sm">추억 사진 선택</span>
              <button
                onClick={() => setShowPhotoSelector(false)}
                className="p-1 rounded-lg hover:bg-white/10 transition-colors"
              >
                <X className="w-4 h-4 text-white/50" />
              </button>
            </div>
            <div className="p-3 space-y-2 overflow-y-auto max-h-[calc(70vh-60px)]">
              {memoryPhotos.map(photo => (
                <button
                  key={photo.id}
                  onClick={() => togglePhotoSelection(photo.id)}
                  className={cn(
                    "w-full relative rounded-lg overflow-hidden transition-all",
                    selectedPhotos.includes(photo.id)
                      ? "ring-2 ring-[#FFD60A]"
                      : "opacity-70 hover:opacity-100"
                  )}
                >
                  <div className="aspect-video">
                    <img 
                      src={photo.photo_url} 
                      alt="Memory" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {selectedPhotos.includes(photo.id) && (
                    <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-[#FFD60A] flex items-center justify-center">
                      <Check className="w-4 h-4 text-black" />
                    </div>
                  )}
                  <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/70 text-white text-xs">
                    {photo.mood}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Video Content */}
        <div className={cn(
          "relative bg-black overflow-hidden",
          isFullscreen ? "h-full" : "aspect-video"
        )}>
          {/* Video Player */}
          <div className="relative w-full h-full">
            {canEmbed ? (
              <>
                {video.platform === 'youtube' ? (
                  <div id={playerIdRef.current} className="w-full h-full" />
                ) : video.platform === 'uploaded_video' && video.video_file_url ? (
                  <div className="w-full h-full bg-black">
                    <video
                      src={video.video_file_url}
                      controls
                      autoPlay
                      onEnded={() => {
                        if (!mountedRef.current) return;
                        const currentPlaylist = playlistRef.current;
                        const currentRepeatMode = repeatModeRef.current;
                        const currentIdx = currentPlaylist.findIndex(v => v.id === video?.id);
                        const hasNextVideo = currentIdx < currentPlaylist.length - 1;

                        if (hasNextVideo && onNavigateRef.current) {
                          onNavigateRef.current(currentPlaylist[currentIdx + 1]);
                        } else if (currentRepeatMode && currentPlaylist.length > 0 && onNavigateRef.current) {
                          onNavigateRef.current(currentPlaylist[0]);
                        }
                      }}
                      className="w-full h-full"
                      />
                  </div>
                ) : video.platform === 'audio' && video.audio_url ? (
                  <div className="relative w-full h-full bg-black flex flex-col">
                    {/* Music Video Background - Full screen, clear photos with tap to play/pause */}
                    {video.music_video_photo_urls?.length > 0 && user?.music_video_mode !== false ? (
                      <div 
                        className="flex-1 relative overflow-hidden cursor-pointer"
                        onClick={toggleAudioPlayback}
                      >
                        {video.music_video_photo_urls.map((photoUrl, idx) => (
                          <div
                            key={idx}
                            className="absolute inset-0 transition-opacity duration-1000"
                            style={{
                              opacity: idx === currentPhotoIndex ? 1 : 0
                            }}
                          >
                            <img 
                              src={photoUrl}
                              alt={`Photo ${idx + 1}`}
                              className={cn(
                                "w-full h-full",
                                user?.music_video_fit === 'cover' ? "object-cover" : "object-contain"
                              )}
                            />
                          </div>
                        ))}
                        
                        {/* Play/Pause indicator overlay */}
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                          <div className={cn(
                            "w-20 h-20 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center transition-opacity duration-300",
                            audioPlaying ? "opacity-0" : "opacity-100"
                          )}>
                            <Play className="w-10 h-10 text-white ml-1" />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div 
                        className="flex-1 bg-gradient-to-br from-[#0D1117] to-[#1C2128] cursor-pointer flex items-center justify-center"
                        onClick={toggleAudioPlayback}
                      >
                        <div className={cn(
                          "w-20 h-20 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center transition-opacity duration-300",
                          audioPlaying ? "opacity-0" : "opacity-100"
                        )}>
                          <Play className="w-10 h-10 text-white ml-1" />
                        </div>
                      </div>
                    )}
                    
                    {/* Audio Controls - Bottom bar */}
                    <div className="bg-black/90 backdrop-blur-sm p-4">
                      <audio
                        ref={audioRef}
                        src={video.audio_url}
                        controls
                        autoPlay
                        onPlay={() => setAudioPlaying(true)}
                        onPause={() => setAudioPlaying(false)}
                        onEnded={() => {
                          if (!mountedRef.current) return;
                          const currentPlaylist = playlistRef.current;
                          const currentRepeatMode = repeatModeRef.current;
                          const currentIdx = currentPlaylist.findIndex(v => v.id === video?.id);
                          const hasNextVideo = currentIdx < currentPlaylist.length - 1;

                          if (hasNextVideo && onNavigateRef.current) {
                            onNavigateRef.current(currentPlaylist[currentIdx + 1]);
                          } else if (currentRepeatMode && currentPlaylist.length > 0 && onNavigateRef.current) {
                            onNavigateRef.current(currentPlaylist[0]);
                          }
                        }}
                        className="w-full"
                        style={{
                          filter: 'invert(1) hue-rotate(180deg)',
                          opacity: 0.9
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  <>
                    <iframe
                      src={iframeSrc}
                      className="w-full h-full"
                      style={{ border: 'none', overflow: 'hidden' }}
                      allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
                      allowFullScreen
                    />
                    {showOverlay && (
                      <div 
                        onClick={handleOverlayClick}
                        className="absolute inset-0 bg-black/40 flex items-center justify-center cursor-pointer z-10"
                      >
                        <p className="text-white text-sm bg-black/60 px-4 py-2 rounded-full">탭하여 재생</p>
                      </div>
                    )}
                  </>
                )}
              </>
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
                {video.thumbnail_url && (
                  <img 
                    src={video.thumbnail_url} 
                    alt={video.title}
                    className="absolute inset-0 w-full h-full object-cover opacity-30 blur-sm"
                  />
                )}
                <div className="relative z-10">
                  <p className="text-white/70 mb-4">
                    이 영상은 외부 사이트에서 볼 수 있어요
                  </p>
                  <a
                    href={video.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white font-medium hover:opacity-90 transition-opacity"
                  >
                    <ExternalLink className="w-5 h-5" />
                    원본 보기
                  </a>
                </div>
              </div>
            )}
          </div>

          {/* Memory Photos Overlay - Above Video */}
          {displayPhotos.length > 0 && (
            <div 
              className={cn(
                "absolute pointer-events-none transition-all duration-300",
                photoPosition === 'top' && "top-0 left-0 right-0 h-1/3",
                photoPosition === 'bottom' && "bottom-0 left-0 right-0 h-1/3",
                photoPosition === 'full' && "inset-0"
              )} 
              style={{ zIndex: 1 }}
            >
              {displayPhotos.map((photo, idx) => (
                <div
                  key={photo.id}
                  className={cn(
                    "absolute inset-0 transition-opacity duration-1000",
                    idx === currentPhotoIndex ? "opacity-100" : "opacity-0"
                  )}
                >
                  <div
                    className="absolute inset-0"
                    style={{
                      opacity: photoOpacity,
                      mixBlendMode: timeCapsuleMode === 'immersive' ? 'normal' : 'screen'
                    }}
                  >
                    <img
                      src={photo.photo_url}
                      alt="Memory"
                      className={cn(
                        "w-full h-full",
                        timeCapsuleMode === 'minimal' ? "object-cover blur-md" : "object-contain",
                        photoPosition === 'top' && "object-top",
                        photoPosition === 'bottom' && "object-bottom"
                      )}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Navigation Arrows */}
          {playlist.length > 1 && (
            <>
              {hasPrev && (
                <button
                  onClick={handlePrev}
                  className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors z-10"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
              )}
              {hasNext && (
                <button
                  onClick={handleNext}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors z-10"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              )}
            </>
          )}
        </div>

        {/* Playlist indicator */}
        {playlist.length > 1 && (
          <div className="p-3 bg-[#161B22] text-center">
            <p className="text-white/50 text-sm">
              {currentIndex + 1} / {playlist.length}
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}