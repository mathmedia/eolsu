import { base44 } from './base44Client';


export const createMusicVideo = base44.functions.createMusicVideo;

