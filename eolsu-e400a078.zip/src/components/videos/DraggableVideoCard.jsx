import React from 'react';
import { Draggable } from '@hello-pangea/dnd';
import { Play, GripVertical, Check } from 'lucide-react';
import GlassCard from '@/components/ui/GlassCard';
import { cn } from "@/lib/utils";

const platformColors = {
  youtube: { bg: 'bg-red-500/20', text: 'text-red-400', label: 'YouTube' },
  tiktok: { bg: 'bg-pink-500/20', text: 'text-pink-400', label: 'TikTok' },
  instagram: { bg: 'bg-purple-500/20', text: 'text-purple-400', label: 'Reels' },
  other: { bg: 'bg-gray-500/20', text: 'text-gray-400', label: 'Video' }
};

export default function DraggableVideoCard({ 
  video, 
  index,
  onPlay,
  folderName,
  isSelected = false,
  onToggleSelect
}) {
  const platform = platformColors[video.platform] || platformColors.other;

  return (
    <Draggable draggableId={video.id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          className={cn(
            "transition-shadow",
            snapshot.isDragging && "z-50"
          )}
        >
          <GlassCard 
            className={cn(
              "p-3",
              snapshot.isDragging && "shadow-2xl shadow-[#4158F1]/30 ring-2 ring-[#4158F1]/50",
              isSelected && "ring-2 ring-[#FFD60A]"
            )}
          >
            <div className="flex items-center gap-3">
              {/* Checkbox */}
              {onToggleSelect && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleSelect(video.id);
                  }}
                  className={cn(
                    "w-5 h-5 rounded flex items-center justify-center flex-shrink-0 transition-colors",
                    isSelected 
                      ? "bg-[#FFD60A] text-black" 
                      : "border-2 border-white/30 hover:border-white/50"
                  )}
                >
                  {isSelected && <Check className="w-3.5 h-3.5" />}
                </button>
              )}
              
              {/* Thumbnail */}
              <div 
                className="relative w-20 h-14 rounded-lg overflow-hidden flex-shrink-0 bg-white/5 cursor-pointer"
                onClick={() => onPlay(video)}
              >
                {video.thumbnail_url ? (
                  <img 
                    src={video.thumbnail_url} 
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Play className="w-6 h-6 text-white/30" />
                  </div>
                )}
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                  <Play className="w-6 h-6 text-white" fill="white" />
                </div>
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0" onClick={() => onPlay(video)}>
                <h4 className="text-white text-sm font-medium truncate cursor-pointer">{video.title}</h4>
                <div className="flex items-center gap-2 mt-1">
                  <span className={cn("text-[10px] px-1.5 py-0.5 rounded-full", platform.bg, platform.text)}>
                    {platform.label}
                  </span>
                  {folderName && (
                    <span className="text-white/30 text-[10px] truncate">
                      {folderName}
                    </span>
                  )}
                </div>
              </div>

              {/* Drag Handle */}
              <div 
                {...provided.dragHandleProps}
                className="p-2 rounded-lg hover:bg-white/10 transition-colors cursor-grab active:cursor-grabbing touch-none"
              >
                <GripVertical className="w-5 h-5 text-white/40" />
              </div>
            </div>
          </GlassCard>
        </div>
      )}
    </Draggable>
  );
}