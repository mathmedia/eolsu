import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, Loader2, Copy, Check, FileText, Share2, MessageSquare } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import GradientButton from '@/components/ui/GradientButton';
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export default function AIAssistantModal({ 
  open, 
  onClose, 
  video,
  onApplySuggestions
}) {
  const [activeTab, setActiveTab] = useState('summary');
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState('');
  const [titleSuggestions, setTitleSuggestions] = useState([]);
  const [descriptionSuggestion, setDescriptionSuggestion] = useState('');
  const [socialPosts, setSocialPosts] = useState({});
  const [copied, setCopied] = useState('');

  const generateSummary = async () => {
    setLoading(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `다음 영상에 대한 간결하고 유용한 요약을 작성해주세요:

제목: ${video.title}
플랫폼: ${video.platform}
${video.notes ? `메모: ${video.notes}` : ''}

요약은 3-4문장으로 작성하고, 주요 내용과 핵심 포인트를 포함해주세요.`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: { type: "string" }
          }
        }
      });

      setSummary(response.summary);
    } catch (error) {
      toast.error('요약 생성에 실패했어요');
    } finally {
      setLoading(false);
    }
  };

  const generateTitleDescriptions = async () => {
    setLoading(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `다음 영상에 대한 제목과 설명을 제안해주세요:

현재 제목: ${video.title}
플랫폼: ${video.platform}
${video.notes ? `메모: ${video.notes}` : ''}

3개의 다양한 제목 옵션을 제공하고 (간결하고 매력적인, SEO 친화적인, 감성적인),
각 제목에 맞는 짧은 설명을 포함해주세요.`,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  style: { type: "string" }
                }
              }
            }
          }
        }
      });

      setTitleSuggestions(response.suggestions || []);
      if (response.suggestions?.length > 0) {
        setDescriptionSuggestion(response.suggestions[0].description);
      }
    } catch (error) {
      toast.error('제목/설명 생성에 실패했어요');
    } finally {
      setLoading(false);
    }
  };

  const generateSocialPosts = async () => {
    setLoading(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `다음 영상을 소셜 미디어에 공유하기 위한 게시물을 작성해주세요:

제목: ${video.title}
플랫폼: ${video.platform}
${video.notes ? `메모: ${video.notes}` : ''}

다음 플랫폼별로 최적화된 게시물을 작성해주세요:
- Instagram: 짧고 감성적이며 해시태그 포함
- Twitter: 간결하고 흥미로운 내용 (280자 이내)
- Facebook: 상세하고 친근한 톤

각 게시물은 영상을 잘 설명하고 사람들이 보고 싶게 만들어야 해요.`,
        response_json_schema: {
          type: "object",
          properties: {
            instagram: { type: "string" },
            twitter: { type: "string" },
            facebook: { type: "string" }
          }
        }
      });

      setSocialPosts(response);
    } catch (error) {
      toast.error('소셜 게시물 생성에 실패했어요');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    toast.success('복사되었어요!');
    setTimeout(() => setCopied(''), 2000);
  };

  const handleApplyTitle = (suggestion) => {
    onApplySuggestions({
      title: suggestion.title,
      notes: suggestion.description
    });
    toast.success('제목과 설명이 적용되었어요');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#161B22] border-white/10 text-white max-w-2xl mx-4 max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#FFD60A]/20 to-[#FFD60A]/5 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-[#FFD60A]" />
            </div>
            AI 어시스턴트
          </DialogTitle>
          <p className="text-white/50 text-sm mt-1">{video?.title}</p>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="bg-white/5 border border-white/10 grid grid-cols-3">
            <TabsTrigger value="summary" className="data-[state=active]:bg-[#4158F1]">
              <FileText className="w-4 h-4 mr-2" />
              요약
            </TabsTrigger>
            <TabsTrigger value="title" className="data-[state=active]:bg-[#4158F1]">
              <MessageSquare className="w-4 h-4 mr-2" />
              제목/설명
            </TabsTrigger>
            <TabsTrigger value="social" className="data-[state=active]:bg-[#4158F1]">
              <Share2 className="w-4 h-4 mr-2" />
              소셜 미디어
            </TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-y-auto mt-4">
            {/* Summary Tab */}
            <TabsContent value="summary" className="space-y-4 mt-0">
              {!summary ? (
                <div className="text-center py-12">
                  <Sparkles className="w-12 h-12 text-[#FFD60A] mx-auto mb-4" />
                  <p className="text-white/50 mb-4">AI가 영상을 요약해드려요</p>
                  <GradientButton onClick={generateSummary} loading={loading}>
                    요약 생성하기
                  </GradientButton>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="text-white font-medium flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-[#FFD60A]" />
                        영상 요약
                      </h3>
                      <button
                        onClick={() => copyToClipboard(summary, 'summary')}
                        className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
                      >
                        {copied === 'summary' ? (
                          <Check className="w-4 h-4 text-green-400" />
                        ) : (
                          <Copy className="w-4 h-4 text-white/50" />
                        )}
                      </button>
                    </div>
                    <p className="text-white/70 text-sm leading-relaxed">{summary}</p>
                  </div>
                  <GradientButton 
                    variant="ghost" 
                    size="sm" 
                    fullWidth 
                    onClick={generateSummary}
                    loading={loading}
                  >
                    다시 생성하기
                  </GradientButton>
                </div>
              )}
            </TabsContent>

            {/* Title & Description Tab */}
            <TabsContent value="title" className="space-y-4 mt-0">
              {titleSuggestions.length === 0 ? (
                <div className="text-center py-12">
                  <MessageSquare className="w-12 h-12 text-[#8B5CF6] mx-auto mb-4" />
                  <p className="text-white/50 mb-4">AI가 제목과 설명을 제안해드려요</p>
                  <GradientButton onClick={generateTitleDescriptions} loading={loading}>
                    제안 받기
                  </GradientButton>
                </div>
              ) : (
                <div className="space-y-3">
                  {titleSuggestions.map((suggestion, index) => (
                    <div 
                      key={index}
                      className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-[#4158F1]/50 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <span className={cn(
                          "text-xs px-2 py-1 rounded-full",
                          "bg-[#4158F1]/20 text-[#4158F1]"
                        )}>
                          {suggestion.style}
                        </span>
                        <button
                          onClick={() => copyToClipboard(suggestion.title, `title-${index}`)}
                          className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
                        >
                          {copied === `title-${index}` ? (
                            <Check className="w-4 h-4 text-green-400" />
                          ) : (
                            <Copy className="w-4 h-4 text-white/50" />
                          )}
                        </button>
                      </div>
                      <h4 className="text-white font-medium mb-2">{suggestion.title}</h4>
                      <p className="text-white/50 text-sm mb-3">{suggestion.description}</p>
                      <GradientButton 
                        size="sm" 
                        variant="ghost"
                        onClick={() => handleApplyTitle(suggestion)}
                      >
                        적용하기
                      </GradientButton>
                    </div>
                  ))}
                  <GradientButton 
                    variant="ghost" 
                    size="sm" 
                    fullWidth 
                    onClick={generateTitleDescriptions}
                    loading={loading}
                  >
                    다시 생성하기
                  </GradientButton>
                </div>
              )}
            </TabsContent>

            {/* Social Media Tab */}
            <TabsContent value="social" className="space-y-4 mt-0">
              {!socialPosts.instagram ? (
                <div className="text-center py-12">
                  <Share2 className="w-12 h-12 text-[#8B5CF6] mx-auto mb-4" />
                  <p className="text-white/50 mb-4">소셜 미디어 게시물을 생성해드려요</p>
                  <GradientButton onClick={generateSocialPosts} loading={loading}>
                    게시물 생성하기
                  </GradientButton>
                </div>
              ) : (
                <div className="space-y-3">
                  {/* Instagram */}
                  <div className="p-4 rounded-xl bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-white font-medium flex items-center gap-2">
                        <span className="text-xl">📸</span> Instagram
                      </h3>
                      <button
                        onClick={() => copyToClipboard(socialPosts.instagram, 'instagram')}
                        className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
                      >
                        {copied === 'instagram' ? (
                          <Check className="w-4 h-4 text-green-400" />
                        ) : (
                          <Copy className="w-4 h-4 text-white/50" />
                        )}
                      </button>
                    </div>
                    <p className="text-white/70 text-sm whitespace-pre-wrap">{socialPosts.instagram}</p>
                  </div>

                  {/* Twitter */}
                  <div className="p-4 rounded-xl bg-gradient-to-br from-blue-500/10 to-blue-400/10 border border-blue-500/20">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-white font-medium flex items-center gap-2">
                        <span className="text-xl">🐦</span> Twitter
                      </h3>
                      <button
                        onClick={() => copyToClipboard(socialPosts.twitter, 'twitter')}
                        className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
                      >
                        {copied === 'twitter' ? (
                          <Check className="w-4 h-4 text-green-400" />
                        ) : (
                          <Copy className="w-4 h-4 text-white/50" />
                        )}
                      </button>
                    </div>
                    <p className="text-white/70 text-sm whitespace-pre-wrap">{socialPosts.twitter}</p>
                  </div>

                  {/* Facebook */}
                  <div className="p-4 rounded-xl bg-gradient-to-br from-blue-600/10 to-blue-500/10 border border-blue-600/20">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-white font-medium flex items-center gap-2">
                        <span className="text-xl">👍</span> Facebook
                      </h3>
                      <button
                        onClick={() => copyToClipboard(socialPosts.facebook, 'facebook')}
                        className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
                      >
                        {copied === 'facebook' ? (
                          <Check className="w-4 h-4 text-green-400" />
                        ) : (
                          <Copy className="w-4 h-4 text-white/50" />
                        )}
                      </button>
                    </div>
                    <p className="text-white/70 text-sm whitespace-pre-wrap">{socialPosts.facebook}</p>
                  </div>

                  <GradientButton 
                    variant="ghost" 
                    size="sm" 
                    fullWidth 
                    onClick={generateSocialPosts}
                    loading={loading}
                  >
                    다시 생성하기
                  </GradientButton>
                </div>
              )}
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}