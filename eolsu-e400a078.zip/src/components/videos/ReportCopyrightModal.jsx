import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import GradientButton from '@/components/ui/GradientButton';
import { base44 } from '@/api/base44Client';
import { AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

export default function ReportCopyrightModal({ open, onClose, video }) {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!email.trim() || !message.trim()) {
      toast.error('이메일과 메시지를 모두 입력해주세요');
      return;
    }

    setLoading(true);
    try {
      await base44.integrations.Core.SendEmail({
        to: 'your-email@gmail.com',
        subject: `저작권 침해 신고 - ${video.title}`,
        body: `
신고자 이메일: ${email}
영상 제목: ${video.title}
영상 URL: ${video.url}
플랫폼: ${video.platform}

신고 내용:
${message}
        `.trim()
      });
      
      toast.success('신고가 접수되었습니다');
      onClose();
      setEmail('');
      setMessage('');
    } catch (error) {
      toast.error('신고 접수에 실패했습니다');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#161B22] border-white/10 text-white max-w-md mx-4">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            저작권 침해 신고
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <div className="bg-white/5 rounded-lg p-3 text-sm text-white/70">
            <p className="font-medium text-white mb-1">{video?.title}</p>
            <p className="text-xs">{video?.url}</p>
          </div>

          <div className="space-y-2">
            <Label className="text-white/70">이메일</Label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-white/70">신고 내용</Label>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="저작권 침해 사유를 설명해주세요..."
              rows={4}
              className="bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none"
            />
          </div>

          <GradientButton 
            fullWidth 
            variant="danger"
            onClick={handleSubmit}
            loading={loading}
            disabled={!email.trim() || !message.trim()}
          >
            신고 접수
          </GradientButton>
        </div>
      </DialogContent>
    </Dialog>
  );
}