import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Sparkles, Heart, CloudRain, Loader2, Download, Check, ChevronDown, ChevronUp, GripVertical, Plus, X, Image as ImageIcon, Play, Pause } from 'lucide-react';
import { cn } from "@/lib/utils";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { useLanguage } from '@/components/i18n/LanguageContext';
import { Video } from 'lucide-react';
import { createPageUrl } from '@/utils';



export default function CreateMusicVideoModal({ open, onClose, video }) {
  const { t, language } = useLanguage();
  const [selectedTheme, setSelectedTheme] = useState('standard');
  const [creating, setCreating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressStep, setProgressStep] = useState('');
  const [videoUrl, setVideoUrl] = useState(null);
  const [musicVideoFolderId, setMusicVideoFolderId] = useState(null);
  const [photoDuration, setPhotoDuration] = useState(7); // number in seconds, default 7
  const [settingsChanged, setSettingsChanged] = useState(false);
  const [photoUrls, setPhotoUrls] = useState([]); // local photo URLs
  const [videoUrls, setVideoUrls] = useState([]); // local video URLs (reordered)
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [loopMedia, setLoopMedia] = useState(true); // Loop videos/photos
  const [savingPhotos, setSavingPhotos] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const isMobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  const [videoResolution, setVideoResolution] = useState(isMobileDevice ? '480p' : '720p'); // 1080p, 720p, 480p
  const [previewPhotoIndex, setPreviewPhotoIndex] = useState(0);
  const [previewVideoIndex, setPreviewVideoIndex] = useState(0);
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const [musicVideoFit, setMusicVideoFit] = useState('contain'); // contain or cover
  const previewAudioRef = React.useRef(null);
  const previewVideoRef = React.useRef(null);
  const previewIntervalRef = React.useRef(null);

  const themes = [
    { value: 'standard', label: t('standard'), icon: Sparkles, desc: t('standardDesc') },
    { value: 'romantic', label: t('romantic'), icon: Heart, desc: t('romanticDesc') },
    { value: 'memorial', label: t('memorial'), icon: CloudRain, desc: t('memorialDesc') }
  ];

  const handleCreate = async () => {
    const finalPhotoUrls = photoUrls.length > 0 ? photoUrls : (video.music_video_photo_urls || []);
    const finalVideoUrls = videoUrls.length > 0 ? videoUrls : (video.video_file_urls || []);
    const hasVideos = finalVideoUrls.length > 0;

    if (hasVideos) {
      toast.error(language === 'ko' ? '비디오는 지원되지 않습니다' : 'Video not supported');
      return;
    }

    if (finalPhotoUrls.length < 2) {
      toast.error(language === 'ko' ? '최소 2장의 사진이 필요합니다' : 'At least 2 photos required');
      return;
    }

    setCreating(true);
    setProgress(0);

    try {
      // Step 1: Load images
      setProgressStep(language === 'ko' ? '사진 로딩 중...' : 'Loading photos...');
      setProgress(5);
      
      const images = await Promise.all(
        finalPhotoUrls.map(url => {
          return new Promise((resolve, reject) => {
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = () => resolve(img);
            img.onerror = reject;
            img.src = url;
          });
        })
      );
      setProgress(15);

      // Step 2: Load audio
      setProgressStep(language === 'ko' ? '오디오 로딩 중...' : 'Loading audio...');
      const audio = new Audio();
      audio.crossOrigin = 'anonymous';
      audio.src = video.audio_url;
      await new Promise((resolve, reject) => {
        audio.onloadedmetadata = resolve;
        audio.onerror = reject;
      });
      const audioDuration = audio.duration;
      setProgress(25);

      // Step 3: Setup canvas and audio
      setProgressStep(language === 'ko' ? '비디오 생성 준비 중...' : 'Preparing video...');

      // Resolution settings based on user selection
      const resolutionSettings = {
        '1080p': { width: 1920, height: 1080, fps: 30, bitrate: 5000000 },
        '720p': { width: 1280, height: 720, fps: 30, bitrate: 2500000 },
        '480p': { width: 854, height: 480, fps: 24, bitrate: 1000000 }
      };

      const settings = resolutionSettings[videoResolution];
      const canvasWidth = settings.width;
      const canvasHeight = settings.height;
      const fps = settings.fps;
      const videoBitrate = settings.bitrate;

      const canvas = document.createElement('canvas');
      canvas.width = canvasWidth;
      canvas.height = canvasHeight;
      const ctx = canvas.getContext('2d');

      const videoStream = canvas.captureStream(fps);

      // Setup Web Audio API for audio capture
      const audioCtx = new AudioContext();
      const audioSource = audioCtx.createMediaElementSource(audio);
      const dest = audioCtx.createMediaStreamDestination();
      audioSource.connect(dest);

      // Create gain node to control volume during recording
      const gainNode = audioCtx.createGain();
      gainNode.gain.value = 0; // Mute playback during recording
      audioSource.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      // Combine video and audio streams
      const combinedStream = new MediaStream([
        ...videoStream.getVideoTracks(),
        ...dest.stream.getAudioTracks()
      ]);

      // Check supported MIME types and use fallback
      let mimeType = 'video/webm;codecs=vp9';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm;codecs=vp8';
        if (!MediaRecorder.isTypeSupported(mimeType)) {
          mimeType = 'video/webm';
          if (!MediaRecorder.isTypeSupported(mimeType)) {
            mimeType = 'video/mp4';
            if (!MediaRecorder.isTypeSupported(mimeType)) {
              throw new Error(language === 'ko' ? '이 기기에서는 비디오 녹화가 지원되지 않습니다' : 'Video recording not supported on this device');
            }
          }
        }
      }

      const mediaRecorder = new MediaRecorder(combinedStream, {
        mimeType: mimeType,
        videoBitsPerSecond: videoBitrate
      });

      const chunks = [];
      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };
      
      setProgress(35);

      // Step 4: Record video
      setProgressStep(language === 'ko' ? '비디오 녹화 중...' : 'Recording video...');
      
      let photoIndex = 0;
      let elapsed = 0;
      const frameDuration = 1000 / fps;
      const calcDuration = Number(photoDuration);
      
      mediaRecorder.start(1000); // Record in 1s chunks for better memory management
      audio.play();

      await new Promise((resolve) => {
        const interval = setInterval(() => {
          if (elapsed >= audioDuration * 1000) {
            clearInterval(interval);
            mediaRecorder.stop();
            audio.pause();
            resolve();
            return;
          }

          // Draw current photo
          const img = images[photoIndex % images.length];
          
          // Clear canvas
          ctx.fillStyle = 'black';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          // Draw image
          const scale = musicVideoFit === 'cover' 
            ? Math.max(canvas.width / img.width, canvas.height / img.height)
            : Math.min(canvas.width / img.width, canvas.height / img.height);
          
          const w = img.width * scale;
          const h = img.height * scale;
          const x = (canvas.width - w) / 2;
          const y = (canvas.height - h) / 2;
          
          ctx.drawImage(img, x, y, w, h);

          // Apply theme filter
          if (selectedTheme === 'romantic') {
            ctx.filter = 'sepia(0.3) brightness(1.1)';
          } else if (selectedTheme === 'memorial') {
            ctx.filter = 'grayscale(1)';
          }

          elapsed += frameDuration;
          
          // Change photo
          if (elapsed % (calcDuration * 1000) < frameDuration) {
            photoIndex++;
          }

          // Update progress
          const progress = 35 + (elapsed / (audioDuration * 1000)) * 50;
          setProgress(Math.min(progress, 85));
        }, frameDuration);
      });

      setProgress(90);

      // Step 5: Create blob and upload
      setProgressStep(language === 'ko' ? '업로드 중...' : 'Uploading...');
      
      const blob = new Blob(chunks, { type: 'video/webm' });
      const videoFile = new File([blob], 'music-video.webm', { type: 'video/webm' });

      console.log('Uploading video file...');
      const { file_url: videoUrl } = await base44.integrations.Core.UploadFile({ file: videoFile });
      console.log('Video uploaded:', videoUrl);

      console.log('Fetching thumbnail blob from:', finalPhotoUrls[0]);
      const thumbnailResponse = await fetch(finalPhotoUrls[0]);
      const thumbnailBlob = await thumbnailResponse.blob();
      console.log('Thumbnail blob:', thumbnailBlob.type, thumbnailBlob.size);
      
      const thumbnailFile = new File([thumbnailBlob], 'thumbnail.jpg', { 
        type: thumbnailBlob.type || 'image/jpeg' 
      });
      console.log('Thumbnail file created:', thumbnailFile.name, thumbnailFile.type, thumbnailFile.size);
      
      console.log('Uploading thumbnail file...');
      const { file_url: thumbnailUrl } = await base44.integrations.Core.UploadFile({ file: thumbnailFile });
      console.log('Thumbnail uploaded:', thumbnailUrl);

      setProgress(95);

      // Step 6: Save to database
      // Generate timestamp in user's local timezone
      const now = new Date();
      const timestamp = `${now.getFullYear()}.${String(now.getMonth() + 1).padStart(2, '0')}.${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      
      const response = await base44.functions.invoke('createMusicVideo', {
        video_url: videoUrl,
        thumbnail_url: thumbnailUrl,
        video_id: video.id,
        duration: audioDuration,
        photo_count: finalPhotoUrls.length,
        timestamp: timestamp
      });

      setProgress(100);
      setVideoUrl(videoUrl);
      setMusicVideoFolderId(response.data.music_video_folder_id);
      setCreating(false);

      toast.success(language === 'ko' 
        ? '뮤직비디오가 생성되었습니다!' 
        : 'Music video created!');

    } catch (error) {
      console.error('Video creation failed:', error);
      let errorMessage = language === 'ko' ? '비디오 생성 실패' : 'Video creation failed';

      // Provide more specific error messages
      if (error.message?.includes('not supported')) {
        errorMessage = language === 'ko' 
          ? '이 기기에서는 비디오 생성이 지원되지 않습니다. PC에서 시도해주세요.' 
          : 'Video creation not supported on this device. Please try on PC.';
      } else if (error.message?.includes('memory')) {
        errorMessage = language === 'ko' 
          ? '메모리가 부족합니다. 사진 개수를 줄이거나 PC에서 시도해주세요.' 
          : 'Not enough memory. Reduce photos or try on PC.';
      } else if (error.name === 'NotAllowedError' || error.name === 'SecurityError') {
        errorMessage = language === 'ko' 
          ? '권한이 거부되었습니다. 브라우저 설정을 확인해주세요.' 
          : 'Permission denied. Check browser settings.';
      }

      toast.error(errorMessage, { duration: 5000 });
      setCreating(false);
      setProgress(0);
    }
  };

  const handleDownload = async () => {
    if (!videoUrl) return;
    
    try {
      toast.loading(language === 'ko' ? '다운로드 준비 중...' : 'Preparing download...', { id: 'download' });
      
      // Fetch video as blob
      const response = await fetch(videoUrl);
      const blob = await response.blob();
      
      // Create download link
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = `${video.title || 'music_video'}.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(blobUrl);
      
      toast.success(language === 'ko' ? '다운로드 시작!' : 'Download started!', { id: 'download' });
    } catch (error) {
      console.error('Download failed:', error);
      toast.error(language === 'ko' ? '다운로드 실패. 새 탭에서 엽니다.' : 'Download failed. Opening in new tab.', { id: 'download' });
      window.open(videoUrl, '_blank');
    }
  };

  const handleReset = () => {
    setCreating(false);
    setProgress(0);
    setProgressStep('');
    setVideoUrl(null);
    setMusicVideoFolderId(null);
    setSelectedTheme('standard');
    setPhotoDuration(7);
    setPhotoUrls([]);
    setVideoUrls(video?.video_file_urls ? [...video.video_file_urls] : []);
    setShowAdvanced(false);
    setLoopMedia(true);
    setMusicVideoFit('contain');
    setVideoResolution(isMobileDevice ? '480p' : '720p');
    stopPreview();
  };

  const handleApplyChanges = async () => {
    if (!video?.id) return;
    
    try {
      setSavingPhotos(true);
      await base44.entities.Video.update(video.id, {
        music_video_photo_urls: photoUrls,
        thumbnail_url: photoUrls[0] || video.thumbnail_url
      });
      
      // Update local video object to reflect changes
      if (video) {
        video.music_video_photo_urls = [...photoUrls];
        video.thumbnail_url = photoUrls[0] || video.thumbnail_url;
      }
      
      toast.success(language === 'ko' ? '변경사항이 적용되었습니다. 폴더로 돌아가면 썸네일이 업데이트됩니다.' : 'Changes applied. Thumbnail will update when you return to folder.');
    } catch (error) {
      console.error('Failed to apply changes:', error);
      toast.error(language === 'ko' ? '저장 실패' : 'Failed to save');
    } finally {
      setSavingPhotos(false);
    }
  };

  const handleVideoDragEnd = (result) => {
    if (!result.destination) return;
    
    const items = Array.from(videoUrls);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    setVideoUrls(items);
  };

  const startPreview = () => {
    const hasVideos = videoUrls.length > 0;
    
    // Check requirements
    if (hasVideos) {
      if (!video?.audio_url) {
        toast.error(language === 'ko' ? '오디오가 필요합니다' : 'Audio required');
        return;
      }
    } else {
      if (!video?.audio_url || photoUrls.length < 2) {
        toast.error(t('mvMinPhotos'));
        return;
      }
    }
    
    // Pause any playing video in the background
    const globalAudio = document.querySelector('audio[src*="' + video.audio_url.split('/').pop() + '"]');
    if (globalAudio && !globalAudio.paused) {
      globalAudio.pause();
    }
    
    setShowPreview(true);
    setPreviewPhotoIndex(0);
    setPreviewVideoIndex(0);
    setPreviewPlaying(true);
    
    // Start audio
    if (previewAudioRef.current) {
      previewAudioRef.current.currentTime = 0;
      previewAudioRef.current.play();
    }
    
    // For videos, start first video
    if (hasVideos && previewVideoRef.current) {
      previewVideoRef.current.currentTime = 0;
      previewVideoRef.current.play();
    }
  };

  const stopPreview = () => {
    setShowPreview(false);
    setPreviewPlaying(false);
    setPreviewPhotoIndex(0);
    
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current.currentTime = 0;
    }
    
    if (previewIntervalRef.current) {
      clearInterval(previewIntervalRef.current);
      previewIntervalRef.current = null;
    }
  };

  const togglePreviewPlayback = () => {
    if (!previewAudioRef.current) return;
    
    if (previewPlaying) {
      previewAudioRef.current.pause();
      setPreviewPlaying(false);
    } else {
      previewAudioRef.current.play();
      setPreviewPlaying(true);
    }
  };

  // Preview slideshow effect (photos only)
  React.useEffect(() => {
    const hasVideos = videoUrls.length > 0;
    if (!showPreview || !previewPlaying || photoUrls.length === 0 || hasVideos) {
      if (previewIntervalRef.current) {
        clearInterval(previewIntervalRef.current);
        previewIntervalRef.current = null;
      }
      return;
    }

    // Calculate slide interval
    let slideInterval = 5000; // default 5s
    if (photoDuration !== 'auto') {
      slideInterval = Number(photoDuration) * 1000;
    } else if (previewAudioRef.current?.duration) {
      const audioDur = previewAudioRef.current.duration;
      slideInterval = Math.max(3000, Math.min(6000, (audioDur / photoUrls.length) * 1000));
    }

    previewIntervalRef.current = setInterval(() => {
      setPreviewPhotoIndex(prev => (prev + 1) % photoUrls.length);
    }, slideInterval);

    return () => {
      if (previewIntervalRef.current) {
        clearInterval(previewIntervalRef.current);
        previewIntervalRef.current = null;
      }
    };
  }, [showPreview, previewPlaying, photoUrls.length, photoDuration, videoUrls.length]);

  // Auto-play next video when video index changes
  React.useEffect(() => {
    if (showPreview && previewPlaying && videoUrls.length > 0 && previewVideoRef.current) {
      previewVideoRef.current.currentTime = 0;
      previewVideoRef.current.play().catch(err => {
        console.log('Video autoplay failed:', err);
      });
    }
  }, [previewVideoIndex, showPreview, previewPlaying, videoUrls.length]);

  // Cleanup on unmount
  React.useEffect(() => {
    return () => {
      stopPreview();
    };
  }, []);

  // Initialize photo/video URLs and user settings on mount
  useEffect(() => {
    if (open && video) {
      console.log('=== Modal Opening Debug ===');
      console.log('Video object:', video);
      console.log('video.music_video_photo_urls:', video.music_video_photo_urls);
      console.log('video.video_file_urls:', video.video_file_urls);
      
      // Initialize photoUrls
      if (video.music_video_photo_urls && Array.isArray(video.music_video_photo_urls) && video.music_video_photo_urls.length > 0) {
        console.log('Setting photoUrls from video.music_video_photo_urls');
        setPhotoUrls([...video.music_video_photo_urls]);
      } else {
        console.log('No music_video_photo_urls found, setting empty array');
        setPhotoUrls([]);
      }
      
      // Initialize videoUrls
      if (video.video_file_urls && Array.isArray(video.video_file_urls) && video.video_file_urls.length > 0) {
        console.log('Setting videoUrls from video.video_file_urls');
        setVideoUrls([...video.video_file_urls]);
      } else {
        console.log('No video_file_urls found, setting empty array');
        setVideoUrls([]);
      }
      
      // Load all user settings
      base44.auth.me().then(user => {
        if (user?.music_video_fit) {
          setMusicVideoFit(user.music_video_fit);
        }
        if (user?.photo_slide_interval) {
          setPhotoDuration(user.photo_slide_interval);
        }
      }).catch(() => {});
    }
  }, [open, video]);

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    
    const items = Array.from(photoUrls);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    setPhotoUrls(items);
  };

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const currentCount = photoUrls.length;
    const newCount = currentCount + files.length;

    if (newCount > 35) {
      toast.error(`${language === 'ko' ? '사진은 최대 35장까지 가능해요' : 'Maximum 35 photos allowed'} (${currentCount}/35)`);
      e.target.value = '';
      return;
    }

    setUploadingPhoto(true);
    try {
      const uploadPromises = files.map(async (file) => {
        if (!file.type.startsWith('image/')) {
          return null;
        }
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        return file_url;
      });

      const uploadedUrls = await Promise.all(uploadPromises);
      const validUrls = uploadedUrls.filter(url => url !== null);

      const newPhotoUrls = currentCount + validUrls.length > 35
        ? [...photoUrls, ...validUrls.slice(0, 35 - currentCount)]
        : [...photoUrls, ...validUrls];

      setPhotoUrls(newPhotoUrls);

      if (currentCount + validUrls.length > 35) {
        const allowedCount = 35 - currentCount;
        toast.warning(`${language === 'ko' ? '사진은 최대 35장까지 가능해요' : 'Maximum 35 photos allowed'} - ${allowedCount}${t('loading').includes('...') ? ' photos added' : '장 추가됨'}`);
      } else {
        toast.success(`${validUrls.length}${t('loading').includes('...') ? ' photos added' : '장 추가됨'}`);
      }
    } catch (error) {
      console.error('Photo upload failed:', error);
      toast.error(t('error'));
    } finally {
      setUploadingPhoto(false);
      e.target.value = '';
    }
  };

  const removePhoto = (indexToRemove) => {
    const newPhotoUrls = photoUrls.filter((_, index) => index !== indexToRemove);
    setPhotoUrls(newPhotoUrls);
    toast.success(t('loading').includes('...') ? 'Photo removed' : '사진 삭제됨');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className={cn("bg-[#161B22] border-white/10 text-white max-h-[90vh] overflow-y-auto [&_*]:!backdrop-blur-none", showPreview ? "max-w-4xl" : "max-w-md")} style={{ WebkitFontSmoothing: 'antialiased', MozOsxFontSmoothing: 'grayscale', textRendering: 'optimizeLegibility', fontSmooth: 'always' }}>
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2 text-xl">
          <Sparkles className="w-5 h-5 text-[#FFD60A]" />
          {t('createMusicVideo')}
        </DialogTitle>
        <DialogDescription className="text-white/50 text-sm">
          {videoUrls.length > 0 
            ? (language === 'ko' ? '비디오와 오디오를 합쳐서 새로운 뮤직비디오를 만듭니다' : 'Create a new music video by combining videos and audio')
            : (language === 'ko' ? '사진과 오디오로 뮤직비디오를 만듭니다' : 'Create a music video with photos and audio')
          }
        </DialogDescription>
      </DialogHeader>

      {/* Hidden audio for preview */}
      <audio
        ref={previewAudioRef}
        src={video?.audio_url}
        crossOrigin="anonymous"
        onPlay={() => setPreviewPlaying(true)}
        onPause={() => setPreviewPlaying(false)}
        className="hidden"
      />

        <div className="space-y-4 mt-4">
          {!creating && !videoUrl && !showPreview && (
            <>
              <div className="space-y-1">
                {videoUrls.length > 0 ? (
                  <>
                    <p className="text-white/70 text-sm">
                      🎬 {videoUrls.length}개 비디오 + 🎵 오디오를 합쳐서 새 영상을 만듭니다
                    </p>
                    <p className="text-white/40 text-xs">
                      비디오들이 순서대로 연결되고 오디오가 오버레이됩니다
                    </p>
                  </>
                ) : (
                  <>
                    <p className="text-white/70 text-sm">
                      {photoUrls.length}{t('photosWithVideo')}
                    </p>
                    <p className="text-white/40 text-xs">
                      {language === 'ko' ? '사진: 2장~35장 • 오디오: 3초~10분' : 'Photos: 2-35 • Audio: 3s-10min'}
                    </p>
                  </>
                )}
              </div>

              {/* Theme Selection - only for photos */}
              {videoUrls.length === 0 && (
              <div className="space-y-2">
                <p className="text-white/70 text-sm font-medium">{t('themeSelection')}</p>
                <div className="grid grid-cols-3 gap-2">
                  {themes.map(theme => {
                    const Icon = theme.icon;
                    return (
                      <button
                        key={theme.value}
                        onClick={() => {
                          setSelectedTheme(theme.value);
                          setSettingsChanged(true);
                        }}
                        className={cn(
                          "p-3 rounded-xl border transition-all",
                          selectedTheme === theme.value
                            ? "bg-[#4158F1]/20 border-[#4158F1] ring-2 ring-[#4158F1]/50"
                            : "bg-white/5 border-white/10 hover:border-white/30"
                        )}
                      >
                        <Icon className={cn(
                          "w-6 h-6 mx-auto mb-1",
                          selectedTheme === theme.value ? "text-[#4158F1]" : "text-white/50"
                        )} />
                        <p className={cn(
                          "text-xs font-medium",
                          selectedTheme === theme.value ? "text-white" : "text-white/70"
                        )}>
                          {theme.label}
                        </p>
                        <p className="text-xs text-white/40 mt-0.5">{theme.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>
              )}

              {/* Mobile Device Notice */}
              {isMobileDevice && (
                <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <p className="text-blue-400 text-xs leading-relaxed">
                    💡 {language === 'ko' 
                      ? 'PC/노트북에서 만들면 최대 1080p 고화질로 생성할 수 있어요!' 
                      : 'Use PC/laptop to create videos up to 1080p quality!'}
                  </p>
                </div>
              )}

              {/* Advanced Settings Toggle */}
              <button
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="w-full py-2 px-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors flex items-center justify-between text-white/70 text-sm"
              >
                <span>{t('advancedSettings')}</span>
                {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>

              {showAdvanced && (
                <div className="space-y-4 p-4 rounded-xl bg-white/5 border border-white/10">
                  {/* Video Resolution Option */}
                  <div className="space-y-2">
                    <label className="text-white/70 text-xs font-medium">
                      {language === 'ko' ? '비디오 해상도' : 'Video Resolution'}
                    </label>
                    <p className="text-white/40 text-xs">
                      {language === 'ko' ? '높을수록 화질이 좋지만 용량이 커집니다' : 'Higher quality means larger file size'}
                    </p>
                    <div className="grid grid-cols-3 gap-2">
                      {['1080p', '720p', '480p'].map(res => (
                        <button
                          key={res}
                          onClick={() => {
                            if (isMobileDevice && res === '1080p') {
                              toast.warning(language === 'ko' 
                                ? '모바일에서 1080p는 실패할 수 있습니다. 720p 이하를 권장합니다.' 
                                : '1080p may fail on mobile. 720p or lower recommended.');
                            }
                            setVideoResolution(res);
                            setSettingsChanged(true);
                          }}
                          className={cn(
                            "px-3 py-2 rounded-lg text-xs font-medium transition-all relative",
                            videoResolution === res
                              ? "bg-[#4158F1] text-white"
                              : "bg-white/5 text-white/50 hover:bg-white/10"
                          )}
                        >
                          {res}
                          {isMobileDevice && res === '1080p' && (
                            <span className="absolute -top-1 -right-1 w-2 h-2 bg-yellow-500 rounded-full" />
                          )}
                        </button>
                      ))}
                    </div>
                    {isMobileDevice && (
                      <p className="text-xs text-yellow-500/70 mt-1">
                        {language === 'ko' ? '⚠️ 모바일은 480p 권장 (메모리 제한)' : '⚠️ 480p recommended for mobile (memory limit)'}
                      </p>
                    )}
                  </div>

                  {/* Music Video Fit Option */}
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-white/70 text-xs font-medium">
                        {language === 'ko' ? '화면 표시 방식' : 'Display Mode'}
                      </label>
                      <p className="text-white/40 text-xs mt-0.5">
                        {musicVideoFit === 'cover' 
                          ? (language === 'ko' ? '화면 채우기 (잘림 가능)' : 'Fill Screen (may crop)')
                          : (language === 'ko' ? '원본 비율 유지' : 'Original Ratio')
                        }
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setMusicVideoFit(musicVideoFit === 'cover' ? 'contain' : 'cover');
                        setSettingsChanged(true);
                      }}
                      className={cn(
                        "relative w-11 h-6 rounded-full transition-colors",
                        musicVideoFit === 'cover' ? "bg-[#4158F1]" : "bg-white/20"
                      )}
                    >
                      <div className={cn(
                        "absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform",
                        musicVideoFit === 'cover' && "translate-x-5"
                      )} />
                    </button>
                  </div>

                  {/* Loop Media Option */}
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-white/70 text-xs font-medium">
                        {videoUrls.length > 0 ? '비디오 반복 재생' : '사진 반복 재생'}
                      </label>
                      <p className="text-white/40 text-xs mt-0.5">
                        {loopMedia 
                          ? (videoUrls.length > 0 ? '오디오가 끝날 때까지 비디오 반복' : '오디오가 끝날 때까지 사진 반복')
                          : (videoUrls.length > 0 ? '비디오를 한 번만 재생' : '사진을 한 번만 표시')
                        }
                      </p>
                    </div>
                    <button
                      onClick={() => setLoopMedia(!loopMedia)}
                      className={cn(
                        "relative w-11 h-6 rounded-full transition-colors",
                        loopMedia ? "bg-[#4158F1]" : "bg-white/20"
                      )}
                    >
                      <div className={cn(
                        "absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform",
                        loopMedia && "translate-x-5"
                      )} />
                    </button>
                  </div>

                  {/* Video Management - only for videos */}
                  {videoUrls.length > 0 && (
                    <div className="space-y-2">
                      <label className="text-white/70 text-xs font-medium">{language === 'ko' ? '비디오 순서' : 'Video Order'}</label>
                      <p className="text-white/40 text-xs">{language === 'ko' ? '드래그하여 순서 변경' : 'Drag to reorder'}</p>
                      <div className="max-h-64 overflow-y-auto rounded-lg border border-white/10">
                        <DragDropContext onDragEnd={handleVideoDragEnd}>
                          <Droppable droppableId="videos">
                            {(provided) => (
                              <div {...provided.droppableProps} ref={provided.innerRef}>
                                {videoUrls.map((videoUrl, index) => (
                                  <Draggable key={videoUrl} draggableId={videoUrl} index={index}>
                                    {(provided, snapshot) => (
                                      <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        className={cn(
                                          "flex items-center gap-2 p-2 bg-[#1C2128] border-b border-white/5",
                                          snapshot.isDragging && "opacity-50"
                                        )}
                                      >
                                        <div {...provided.dragHandleProps} className="cursor-grab active:cursor-grabbing">
                                            <GripVertical className="w-4 h-4 text-white/30" />
                                          </div>
                                          <video
                                            src={videoUrl}
                                            className="w-16 h-10 rounded object-cover flex-shrink-0 bg-black"
                                            muted
                                            playsInline
                                          />
                                          <span className="text-white/50 text-xs flex-1">{language === 'ko' ? '비디오' : 'Video'} {index + 1}</span>
                                      </div>
                                    )}
                                  </Draggable>
                                ))}
                                {provided.placeholder}
                              </div>
                            )}
                          </Droppable>
                        </DragDropContext>
                      </div>
                    </div>
                  )}

                  {/* Photo Duration - only for photos */}
                  {videoUrls.length === 0 && (
                    <div className="space-y-2">
                      <label className="text-white/70 text-xs font-medium">{t('photoDuration')}</label>
                      <p className="text-white/40 text-xs">각 사진이 화면에 표시되는 시간을 설정합니다</p>
                      <div className="grid grid-cols-4 gap-2">
                        {[3, 4, 5, 6, 7, 8, 9, 10].map(sec => (
                          <button
                            key={sec}
                            onClick={() => {
                              setPhotoDuration(sec);
                              setSettingsChanged(true);
                            }}
                            className={cn(
                              "px-3 py-2 rounded-lg text-xs font-medium transition-all",
                              photoDuration === sec
                                ? "bg-[#4158F1] text-white"
                                : "bg-white/5 text-white/50 hover:bg-white/10"
                            )}
                          >
                            {sec}초
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Photo Management - only for photos */}
                  {videoUrls.length === 0 && (
                    <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-white/70 text-xs font-medium">{t('photoOrder')}</label>
                      <label 
                        htmlFor="add-photo-upload"
                        className={cn(
                          "px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer flex items-center gap-1",
                          photoUrls.length >= 35 
                            ? "bg-white/5 text-white/30 cursor-not-allowed"
                            : "bg-[#4158F1]/20 text-[#4158F1] hover:bg-[#4158F1]/30"
                        )}
                      >
                        {uploadingPhoto ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <Plus className="w-3 h-3" />
                        )}
                        {t('loading').includes('...') ? 'Add' : '추가'} ({photoUrls.length}/35)
                      </label>
                      <input
                        id="add-photo-upload"
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handlePhotoUpload}
                        disabled={uploadingPhoto || photoUrls.length >= 35}
                        className="hidden"
                      />
                    </div>
                    <div className="max-h-64 overflow-y-auto rounded-lg border border-white/10">
                      <DragDropContext onDragEnd={handleDragEnd}>
                        <Droppable droppableId="photos">
                          {(provided) => (
                            <div {...provided.droppableProps} ref={provided.innerRef}>
                              {photoUrls.map((photoUrl, index) => (
                                <Draggable key={photoUrl} draggableId={photoUrl} index={index}>
                                  {(provided, snapshot) => (
                                    <div
                                      ref={provided.innerRef}
                                      {...provided.draggableProps}
                                      className={cn(
                                        "flex items-center gap-2 p-2 bg-[#1C2128] border-b border-white/5",
                                        snapshot.isDragging && "opacity-50"
                                      )}
                                    >
                                      <div {...provided.dragHandleProps} className="cursor-grab active:cursor-grabbing">
                                        <GripVertical className="w-4 h-4 text-white/30" />
                                      </div>
                                      <img 
                                        src={photoUrl} 
                                        alt={`Photo ${index + 1}`}
                                        className="w-12 h-12 rounded object-cover flex-shrink-0"
                                      />
                                      <span className="text-white/50 text-xs flex-1">{t('loading').includes('...') ? 'Photo' : '사진'} {index + 1}</span>
                                      <button
                                        onClick={() => removePhoto(index)}
                                        className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 transition-colors flex-shrink-0"
                                      >
                                        <X className="w-3.5 h-3.5 text-red-400" />
                                      </button>
                                    </div>
                                  )}
                                </Draggable>
                              ))}
                              {provided.placeholder}
                              </div>
                              )}
                              </Droppable>
                              </DragDropContext>
                              </div>
                              </div>
                              )}
                              </div>
                              )}

              <div className="space-y-2">
                {(photoUrls.length !== video?.music_video_photo_urls?.length || 
                 JSON.stringify(photoUrls) !== JSON.stringify(video?.music_video_photo_urls) ||
                 settingsChanged) && (
                  <button
                    onClick={async () => {
                      await handleApplyChanges();
                      // Save settings to user
                      await base44.auth.updateMe({
                        music_video_fit: musicVideoFit,
                        photo_slide_interval: photoDuration
                      });
                      setSettingsChanged(false);
                      toast.success('설정이 저장되었습니다');
                    }}
                    disabled={savingPhotos}
                    className="w-full py-3 rounded-xl bg-[#FFD60A] text-black font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {savingPhotos ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        {language === 'ko' ? '저장 중...' : 'Saving...'}
                      </>
                    ) : (
                      <>
                        <Check className="w-5 h-5" />
                        {language === 'ko' ? '설정 저장' : 'Save Settings'}
                      </>
                    )}
                  </button>
                )}

                <button
                  onClick={startPreview}
                  className="w-full py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-medium transition-all flex items-center justify-center gap-2 border border-white/20"
                >
                  <Play className="w-5 h-5" />
                  {t('previewSettings')}
                </button>

                <button
                  onClick={handleCreate}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-5 h-5" />
                  {t('createVideo')}
                </button>
              </div>
            </>
          )}

          {/* Preview Mode */}
          {showPreview && (
            <div className="space-y-4">
              {/* Preview Display */}
              <div className="relative aspect-video rounded-xl overflow-hidden bg-black w-full" style={{ maxHeight: '70vh' }}>
                {videoUrls.length > 0 ? (
                  // Video preview with sequential playback
                  <>
                    {videoUrls.map((videoUrl, idx) => (
                      <video
                        key={idx}
                        ref={idx === previewVideoIndex ? previewVideoRef : null}
                        src={videoUrl}
                        className="absolute inset-0 w-full h-full object-contain"
                        style={{
                          opacity: idx === previewVideoIndex ? 1 : 0,
                          pointerEvents: idx === previewVideoIndex ? 'auto' : 'none'
                        }}
                        muted
                        playsInline
                        onEnded={() => {
                          // Move to next video
                          if (idx < videoUrls.length - 1) {
                            setPreviewVideoIndex(idx + 1);
                            // Next video will auto-play via useEffect
                          }
                        }}
                      />
                    ))}
                  </>
                ) : (
                  // Photo preview
                  photoUrls.map((photoUrl, idx) => {
                    // Apply theme filters
                    const themeFilter = {
                      standard: 'none',
                      romantic: 'sepia(0.3) brightness(1.1) contrast(1.1)',
                      memorial: 'grayscale(1) brightness(0.9)'
                    }[selectedTheme] || 'none';

                    return (
                      <div
                        key={idx}
                        className="absolute inset-0 transition-opacity duration-1000"
                        style={{
                          opacity: idx === previewPhotoIndex ? 1 : 0,
                          filter: themeFilter
                        }}
                      >
                        <img 
                          src={photoUrl}
                          alt={`Preview ${idx + 1}`}
                          className={cn(
                            "w-full h-full",
                            musicVideoFit === 'cover' ? "object-cover" : "object-contain"
                          )}
                          />
                      </div>
                    );
                  })
                )}

                {/* Playback controls overlay */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                  <div className="flex items-center justify-between text-white">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={togglePreviewPlayback}
                        className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
                      >
                        {previewPlaying ? (
                          <Pause className="w-5 h-5" />
                        ) : (
                          <Play className="w-5 h-5" />
                        )}
                      </button>
                      <span className="text-sm">
                        {videoUrls.length > 0 
                          ? `${previewVideoIndex + 1} / ${videoUrls.length}`
                          : `${previewPhotoIndex + 1} / ${photoUrls.length}`
                        }
                      </span>
                    </div>
                    <div className="text-xs text-white/70">
                      {videoUrls.length > 0 ? (language === 'ko' ? '비디오' : 'Video') : t(selectedTheme)}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-white/70">{language === 'ko' ? '화면 표시' : 'Display'}:</span>
                  <span className="text-white font-medium">
                    {musicVideoFit === 'cover' 
                      ? (language === 'ko' ? '화면 채우기' : 'Fill Screen')
                      : (language === 'ko' ? '원본 비율' : 'Original Ratio')
                    }
                  </span>
                </div>
                {videoUrls.length === 0 && (
                  <>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-white/70">{t('photoDuration')}:</span>
                      <span className="text-white font-medium">
                        {photoDuration === 'auto' ? t('autoFit') : `${photoDuration}${language === 'ko' ? '초' : 's'}`}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-white/70">{t('themeSelection')}:</span>
                      <span className="text-white font-medium">
                        {t(selectedTheme)}
                      </span>
                    </div>
                  </>
                )}
                {videoUrls.length > 0 && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-white/70">{language === 'ko' ? '비디오 개수' : 'Videos'}:</span>
                    <span className="text-white font-medium">
                      {videoUrls.length}{language === 'ko' ? '개' : ' videos'}
                    </span>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  onClick={stopPreview}
                  className="flex-1 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm transition-colors"
                >
                  {t('backToSettings')}
                </button>
                <button
                  onClick={() => {
                    stopPreview();
                    handleCreate();
                  }}
                  className="flex-1 py-2 rounded-lg bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white text-sm font-medium hover:opacity-90 transition-opacity"
                >
                  {t('createNow')}
                </button>
              </div>
            </div>
          )}

          {creating && !videoUrl && (
            <div className="py-8 space-y-4">
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="w-12 h-12 text-[#4158F1] animate-spin" />
                <p className="text-white font-medium">{t('creatingVideo')}</p>
                <p className="text-[#8B5CF6] text-sm font-medium">{progressStep}</p>
                <p className="text-white/50 text-xs">{t('pleaseWait')}</p>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-center text-white/50 text-sm">{Math.round(progress)}%</p>
            </div>
          )}

          {videoUrl && (
            <div className="py-6 space-y-4">
              <div className="flex flex-col items-center gap-3 mb-4">
                <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center">
                  <Check className="w-8 h-8 text-green-400" />
                </div>
                <p className="text-white font-medium text-lg">{t('creationComplete')}</p>
                <p className="text-white/50 text-xs text-center max-w-xs">
                  {t('loading').includes('...') 
                    ? 'Your music video has been created and saved to your folder. You can download it or close to view it in your library.'
                    : '뮤직비디오가 생성되어 폴더에 저장되었습니다. 다운로드하거나 닫기를 눌러 폴더에서 확인하세요.'}
                </p>
              </div>

              <button
                onClick={handleDownload}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
              >
                <Download className="w-5 h-5" />
                {t('downloadVideo')}
              </button>

              <button
                onClick={() => {
                  // Navigate to music video folder directly without closing first
                  if (musicVideoFolderId) {
                    window.location.href = createPageUrl('FolderDetail') + `?id=${musicVideoFolderId}`;
                  } else {
                    // Stay on current page and just close modal
                    onClose();
                  }
                }}
                className="w-full py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-medium transition-colors"
              >
                {language === 'ko' ? '뮤직비디오 폴더에서 확인' : 'View in Music Video Folder'}
              </button>

              <button
                onClick={handleReset}
                className="w-full py-2 text-white/50 hover:text-white transition-colors text-sm"
              >
                {t('recreate')}
              </button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}