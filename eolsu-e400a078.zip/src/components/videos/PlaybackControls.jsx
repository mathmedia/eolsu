import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Volume2, VolumeX, Settings, SkipBack, SkipForward } from 'lucide-react';
import { cn } from "@/lib/utils";
import { Slider } from "@/components/ui/slider";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export default function PlaybackControls({
  isPlaying,
  currentTime,
  duration,
  volume,
  playbackRate,
  onPlayPause,
  onSeek,
  onVolumeChange,
  onPlaybackRateChange,
  onSkipBackward,
  onSkipForward,
  className
}) {
  const [isDragging, setIsDragging] = useState(false);
  const [tempTime, setTempTime] = useState(currentTime);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const progressBarRef = useRef(null);

  useEffect(() => {
    if (!isDragging) {
      setTempTime(currentTime);
    }
  }, [currentTime, isDragging]);

  const formatTime = (seconds) => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleProgressBarClick = (e) => {
    if (!progressBarRef.current || !duration) return;
    
    const rect = progressBarRef.current.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    const newTime = percent * duration;
    onSeek(Math.max(0, Math.min(newTime, duration)));
  };

  const handleProgressChange = (value) => {
    const newTime = (value[0] / 100) * duration;
    setTempTime(newTime);
    setIsDragging(true);
  };

  const handleProgressCommit = (value) => {
    const newTime = (value[0] / 100) * duration;
    onSeek(newTime);
    setIsDragging(false);
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
  const displayTime = isDragging ? tempTime : currentTime;

  return (
    <div className={cn("flex flex-col gap-2", className)}>
      {/* Progress Bar */}
      <div className="flex items-center gap-2">
        <span className="text-xs text-white/70 min-w-[40px]">
          {formatTime(displayTime)}
        </span>
        
        <div 
          ref={progressBarRef}
          className="flex-1 h-1 bg-white/20 rounded-full cursor-pointer relative group"
          onClick={handleProgressBarClick}
        >
          <div 
            className="h-full bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] rounded-full transition-all relative"
            style={{ width: `${progress}%` }}
          >
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg" />
          </div>
        </div>

        <span className="text-xs text-white/70 min-w-[40px] text-right">
          {formatTime(duration)}
        </span>
      </div>

      {/* Control Buttons */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* Play/Pause */}
          <button
            onClick={onPlayPause}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
          >
            {isPlaying ? (
              <Pause className="w-5 h-5 text-white" fill="white" />
            ) : (
              <Play className="w-5 h-5 text-white ml-0.5" fill="white" />
            )}
          </button>

          {/* Skip Backward */}
          {onSkipBackward && (
            <button
              onClick={onSkipBackward}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            >
              <SkipBack className="w-4 h-4 text-white" />
            </button>
          )}

          {/* Skip Forward */}
          {onSkipForward && (
            <button
              onClick={onSkipForward}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            >
              <SkipForward className="w-4 h-4 text-white" />
            </button>
          )}

          {/* Volume Control */}
          <Popover open={showVolumeSlider} onOpenChange={setShowVolumeSlider}>
            <PopoverTrigger asChild>
              <button className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
                {volume === 0 ? (
                  <VolumeX className="w-4 h-4 text-white" />
                ) : (
                  <Volume2 className="w-4 h-4 text-white" />
                )}
              </button>
            </PopoverTrigger>
            <PopoverContent 
              className="bg-[#1C2128] border-white/10 w-36 p-3"
              side="top"
            >
              <div className="flex items-center gap-3">
                <VolumeX className="w-4 h-4 text-white/50 flex-shrink-0" />
                <Slider
                  value={[volume * 100]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={(value) => onVolumeChange(value[0] / 100)}
                  className="flex-1"
                />
                <Volume2 className="w-4 h-4 text-white/50 flex-shrink-0" />
              </div>
              <div className="text-center text-white/70 text-xs mt-2">
                {Math.round(volume * 100)}%
              </div>
            </PopoverContent>
          </Popover>
        </div>

        {/* Playback Speed */}
        <Popover>
          <PopoverTrigger asChild>
            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
              <Settings className="w-4 h-4 text-white" />
              <span className="text-xs text-white font-medium">
                {playbackRate}x
              </span>
            </button>
          </PopoverTrigger>
          <PopoverContent 
            className="bg-[#1C2128] border-white/10 w-40 p-2"
            side="top"
          >
            <div className="text-white/70 text-xs mb-2 px-2">재생 속도</div>
            <div className="space-y-1">
              {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((rate) => (
                <button
                  key={rate}
                  onClick={() => onPlaybackRateChange(rate)}
                  className={cn(
                    "w-full px-3 py-2 rounded-lg text-sm transition-colors text-left",
                    playbackRate === rate
                      ? "bg-[#4158F1] text-white font-medium"
                      : "text-white/70 hover:bg-white/10"
                  )}
                >
                  {rate === 1 ? '보통' : `${rate}x`}
                </button>
              ))}
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </div>
  );
}