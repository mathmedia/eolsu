import React, { useState } from 'react';
import { Play, MoreVertical, Trash2, Edit2, ExternalLink, Sparkles, AlertTriangle, FolderPlus, Download, Film } from 'lucide-react';
import { toast } from 'sonner';
import GlassCard from '@/components/ui/GlassCard';
import ReportCopyrightModal from './ReportCopyrightModal';
import CreateMusicVideoModal from './CreateMusicVideoModal';
import { useLanguage } from '@/components/i18n/LanguageContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

const platformColors = {
  youtube: { bg: 'bg-red-500/20', text: 'text-red-400', label: 'YouTube' },
  tiktok: { bg: 'bg-pink-500/20', text: 'text-pink-400', label: 'TikTok' },
  instagram: { bg: 'bg-purple-500/20', text: 'text-purple-400', label: 'Reels' },
  other: { bg: 'bg-gray-500/20', text: 'text-gray-400', label: 'Video' }
};

export default function VideoCard({ 
  video, 
  onPlay, 
  onEdit, 
  onDelete,
  onAIAssist,
  onSave,
  showSaveButton = false,
  compact = false 
}) {
  const { t } = useLanguage();
  const [showReportModal, setShowReportModal] = useState(false);
  const [showCreateVideoModal, setShowCreateVideoModal] = useState(false);
  const platform = platformColors[video.platform] || platformColors.other;

  // Check if this is a completed music video (can be downloaded)
  const isCompletedMusicVideo = video.platform === 'uploaded_video';
  
  // Check if music video can be created
  // Conditions: must be audio-only (no video files, no YouTube URL with video)
  const canCreateMusicVideo = video.platform === 'audio' && video.audio_url;

  const handleDownload = async () => {
    if (!video.video_file_urls?.[0]) return;
    
    try {
      toast.loading('다운로드 준비 중...', { id: 'download' });
      
      const response = await fetch(video.video_file_urls[0]);
      const blob = await response.blob();
      
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = `${video.title || 'video'}.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(blobUrl);
      
      toast.success('다운로드 시작!', { id: 'download' });
    } catch (error) {
      console.error('Download failed:', error);
      toast.error('다운로드 실패. 새 탭에서 엽니다.', { id: 'download' });
      window.open(video.video_file_urls[0], '_blank');
    }
  };

  if (compact) {
    return (
      <GlassCard hover className="p-3">
        <div className="flex items-center gap-3" onClick={() => onPlay(video)}>
          {/* Thumbnail */}
          <div className="relative w-20 h-14 rounded-lg overflow-hidden flex-shrink-0 bg-white/5">
            {video.thumbnail_url ? (
              <img 
                src={video.thumbnail_url} 
                alt={video.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Play className="w-6 h-6 text-white/30" />
              </div>
            )}
            <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
              <Play className="w-6 h-6 text-white" fill="white" />
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <h4 className="text-white text-sm font-medium truncate">{video.title}</h4>
            <span className={cn("text-[10px] px-1.5 py-0.5 rounded-full mt-1 inline-block", platform.bg, platform.text)}>
              {platform.label}
            </span>
          </div>

          {/* Actions */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <button className="p-1 rounded-lg hover:bg-white/10 transition-colors">
                <MoreVertical className="w-4 h-4 text-white/50" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-[#1C2128] border-white/10 text-white">
              {isCompletedMusicVideo && video.video_file_urls?.[0] && (
                <DropdownMenuItem onClick={handleDownload} className="hover:bg-white/10 text-[#4158F1]">
                  <Download className="w-4 h-4 mr-2" /> 다운로드
                </DropdownMenuItem>
              )}
              {showSaveButton && onSave && (
                <DropdownMenuItem onClick={() => onSave(video)} className="hover:bg-white/10 text-[#4158F1]">
                  <FolderPlus className="w-4 h-4 mr-2" /> 내 폴더에 저장
                </DropdownMenuItem>
              )}
              {onAIAssist && (
                <DropdownMenuItem onClick={() => onAIAssist(video)} className="hover:bg-white/10">
                  <Sparkles className="w-4 h-4 mr-2 text-[#FFD60A]" /> AI 어시스턴트
                </DropdownMenuItem>
              )}
              {!showSaveButton && (
                <>
                  <DropdownMenuItem onClick={() => onEdit(video)} className="hover:bg-white/10">
                    <Edit2 className="w-4 h-4 mr-2" /> 수정
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDelete(video)} className="hover:bg-white/10 text-red-400">
                    <Trash2 className="w-4 h-4 mr-2" /> 삭제
                  </DropdownMenuItem>
                </>
              )}
              {canCreateMusicVideo && (
                <DropdownMenuItem onClick={() => setShowCreateVideoModal(true)} className="hover:bg-white/10 text-[#FFD60A]">
                  <Film className="w-4 h-4 mr-2" /> {t('createMusicVideo')}
                </DropdownMenuItem>
              )}
              {video.url && (
                <DropdownMenuItem onClick={() => window.open(video.url, '_blank')} className="hover:bg-white/10">
                  <ExternalLink className="w-4 h-4 mr-2" /> 원본 보기
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={() => setShowReportModal(true)} className="hover:bg-white/10 text-orange-400">
                <AlertTriangle className="w-4 h-4 mr-2" /> 저작권 신고
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <ReportCopyrightModal 
          open={showReportModal}
          onClose={() => setShowReportModal(false)}
          video={video}
        />
        {canCreateMusicVideo && (
          <CreateMusicVideoModal
            open={showCreateVideoModal}
            onClose={() => setShowCreateVideoModal(false)}
            video={video}
          />
        )}
      </GlassCard>
    );
  }

  return (
    <GlassCard hover glow className="overflow-hidden">
      {/* Thumbnail */}
      <div 
        className="relative aspect-video bg-white/5 cursor-pointer group"
        onClick={(e) => {
          // If music video badge is clicked, show create modal instead
          if (e.target.closest('.mv-create-badge')) {
            e.stopPropagation();
            setShowCreateVideoModal(true);
          } else {
            onPlay(video);
          }
        }}
      >
        {video.thumbnail_url ? (
          <img 
            src={video.thumbnail_url} 
            alt={video.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Play className="w-12 h-12 text-white/30" />
          </div>
        )}
        
        {/* Play Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center">
          <div className="w-14 h-14 rounded-full bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] flex items-center justify-center shadow-lg shadow-[#4158F1]/50 transform scale-75 group-hover:scale-100 transition-transform">
            <Play className="w-6 h-6 text-white ml-1" fill="white" />
          </div>
        </div>

        {/* Platform Badge */}
        <div className={cn(
          "absolute top-2 left-2 px-2 py-1 rounded-full text-[10px] font-medium",
          platform.bg, platform.text
        )}>
          {platform.label}
        </div>

        {/* Music Video Badge - Only show if can create music video */}
        {canCreateMusicVideo && (
          <button
            className="mv-create-badge absolute top-2 right-2 px-3 py-1.5 rounded-full text-xs font-bold bg-gradient-to-r from-[#FFD60A] to-[#FFA500] text-black flex items-center gap-1.5 shadow-xl hover:scale-105 transition-transform z-10 animate-pulse"
            onClick={(e) => {
              e.stopPropagation();
              setShowCreateVideoModal(true);
            }}
          >
            <Film className="w-4 h-4" />
            🎬 뮤직비디오 생성
          </button>
        )}
        
        {/* YouTube URL without audio hint */}
        {video.platform === 'youtube' && !video.audio_url && (
          <div className="absolute bottom-2 left-2 px-2 py-1 rounded-lg bg-blue-500/20 backdrop-blur-sm border border-blue-500/30 text-blue-300 text-[10px] font-medium">
            💡 오디오 추가 → 뮤직비디오
          </div>
        )}

        {/* Duration */}
        {video.duration && (
          <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/70 text-white text-[10px]">
            {video.duration}
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-3">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-white font-medium text-sm line-clamp-2 flex-1">
            {video.title}
          </h3>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="p-1 rounded-lg hover:bg-white/10 transition-colors flex-shrink-0">
                <MoreVertical className="w-4 h-4 text-white/50" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-[#1C2128] border-white/10 text-white">
              {isCompletedMusicVideo && video.video_file_urls?.[0] && (
                <DropdownMenuItem onClick={handleDownload} className="hover:bg-white/10 text-[#4158F1]">
                  <Download className="w-4 h-4 mr-2" /> 다운로드
                </DropdownMenuItem>
              )}
              {showSaveButton && onSave && (
                <DropdownMenuItem onClick={() => onSave(video)} className="hover:bg-white/10 text-[#4158F1]">
                  <FolderPlus className="w-4 h-4 mr-2" /> 내 폴더에 저장
                </DropdownMenuItem>
              )}
              {onAIAssist && (
                <DropdownMenuItem onClick={() => onAIAssist(video)} className="hover:bg-white/10">
                  <Sparkles className="w-4 h-4 mr-2 text-[#FFD60A]" /> AI 어시스턴트
                </DropdownMenuItem>
              )}
              {!showSaveButton && (
                <>
                  <DropdownMenuItem onClick={() => onEdit(video)} className="hover:bg-white/10">
                    <Edit2 className="w-4 h-4 mr-2" /> 수정
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDelete(video)} className="hover:bg-white/10 text-red-400">
                    <Trash2 className="w-4 h-4 mr-2" /> 삭제
                  </DropdownMenuItem>
                </>
              )}
              {canCreateMusicVideo && (
                <DropdownMenuItem onClick={() => setShowCreateVideoModal(true)} className="hover:bg-white/10 text-[#FFD60A]">
                  <Sparkles className="w-4 h-4 mr-2" /> {t('createMusicVideo')}
                </DropdownMenuItem>
              )}
              {video.url && (
                <DropdownMenuItem onClick={() => window.open(video.url, '_blank')} className="hover:bg-white/10">
                  <ExternalLink className="w-4 h-4 mr-2" /> 원본 보기
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={() => setShowReportModal(true)} className="hover:bg-white/10 text-orange-400">
                <AlertTriangle className="w-4 h-4 mr-2" /> 저작권 신고
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        {video.notes && (
          <p className="text-white/50 text-xs mt-2 line-clamp-2">{video.notes}</p>
        )}
      </div>
      
      <ReportCopyrightModal 
        open={showReportModal}
        onClose={() => setShowReportModal(false)}
        video={video}
      />
      {canCreateMusicVideo && (
        <CreateMusicVideoModal
          open={showCreateVideoModal}
          onClose={() => setShowCreateVideoModal(false)}
          video={video}
        />
      )}
    </GlassCard>
  );
}