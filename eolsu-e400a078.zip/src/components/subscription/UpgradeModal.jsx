import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Check, X, Crown, Sparkles, Zap } from 'lucide-react';
import { motion } from 'framer-motion';
import GradientButton from '@/components/ui/GradientButton';
import { cn } from "@/lib/utils";
import { toast } from 'sonner';
import { useLanguage } from '@/components/i18n/LanguageContext';

export default function UpgradeModal({ open, onClose, currentPlan = 'free' }) {
  const [selectedPlan, setSelectedPlan] = useState(null);
  const { t, language } = useLanguage();

  const plans = [
    {
      id: 'free',
      name: 'Free',
      price: '₩0',
      period: t('freeFeatures'),
      features: [
        { text: language === 'ko' ? '5개 폴더' : language === 'ja' ? '5フォルダ' : language === 'id' ? '5 folder' : language === 'es' ? '5 carpetas' : language === 'pt' ? '5 pastas' : '5 folders', included: true },
        { text: language === 'ko' ? '무제한 영상' : language === 'ja' ? '無制限動画' : language === 'id' ? 'Video tanpa batas' : language === 'es' ? 'Videos ilimitados' : language === 'pt' ? 'Vídeos ilimitados' : 'Unlimited videos', included: true },
        { text: language === 'ko' ? '광고 표시' : language === 'ja' ? '広告表示' : language === 'id' ? 'Dengan iklan' : language === 'es' ? 'Con anuncios' : language === 'pt' ? 'Com anúncios' : 'With ads', included: false },
        { text: language === 'ko' ? '뮤직 앨범 생성' : language === 'ja' ? 'ミュージックアルバム作成' : language === 'id' ? 'Pembuatan album musik' : language === 'es' ? 'Creación de álbumes musicales' : language === 'pt' ? 'Criação de álbuns musicais' : 'Music album creation', included: false },
        { text: t('offlineMode'), included: false },
        { text: t('backgroundPlay'), included: false }
      ],
      icon: Sparkles,
      gradient: 'from-gray-500 to-gray-600'
    },
    {
      id: 'basic',
      name: 'Basic',
      price: '₩2,900',
      period: t('perMonth'),
      features: [
        { text: language === 'ko' ? '무제한 폴더' : language === 'ja' ? '無制限フォルダ' : language === 'id' ? 'Folder tanpa batas' : language === 'es' ? 'Carpetas ilimitadas' : language === 'pt' ? 'Pastas ilimitadas' : 'Unlimited folders', included: true },
        { text: language === 'ko' ? '무제한 영상' : language === 'ja' ? '無制限動画' : language === 'id' ? 'Video tanpa batas' : language === 'es' ? 'Videos ilimitados' : language === 'pt' ? 'Vídeos ilimitados' : 'Unlimited videos', included: true },
        { text: t('noAds'), included: true },
        { text: language === 'ko' ? '뮤직 앨범 다운로드' : language === 'ja' ? 'ミュージックアルバムダウンロード' : language === 'id' ? 'Unduh album musik' : language === 'es' ? 'Descarga de álbumes musicales' : language === 'pt' ? 'Download de álbuns musicais' : 'Music album download', included: true },
        { text: t('offlineMode'), included: false },
        { text: t('backgroundPlay'), included: false }
      ],
      icon: Zap,
      gradient: 'from-[#4158F1] to-[#8B5CF6]',
      popular: true
    },
    {
      id: 'pro',
      name: 'Pro',
      price: '₩5,900',
      period: t('perMonth'),
      features: [
        { text: language === 'ko' ? '무제한 폴더' : language === 'ja' ? '無制限フォルダ' : language === 'id' ? 'Folder tanpa batas' : language === 'es' ? 'Carpetas ilimitadas' : language === 'pt' ? 'Pastas ilimitadas' : 'Unlimited folders', included: true },
        { text: language === 'ko' ? '무제한 영상' : language === 'ja' ? '無制限動画' : language === 'id' ? 'Video tanpa batas' : language === 'es' ? 'Videos ilimitados' : language === 'pt' ? 'Vídeos ilimitados' : 'Unlimited videos', included: true },
        { text: t('noAds'), included: true },
        { text: language === 'ko' ? '뮤직 앨범 다운로드' : language === 'ja' ? 'ミュージックアルバムダウンロード' : language === 'id' ? 'Unduh album musik' : language === 'es' ? 'Descarga de álbumes musicales' : language === 'pt' ? 'Download de álbuns musicais' : 'Music album download', included: true },
        { text: language === 'ko' ? '오프라인 자동 저장' : language === 'ja' ? 'オフライン自動保存' : language === 'id' ? 'Penyimpanan otomatis offline' : language === 'es' ? 'Guardado automático offline' : language === 'pt' ? 'Salvamento automático offline' : 'Auto offline save', included: true },
        { text: t('backgroundPlay'), included: true },
        { text: language === 'ko' ? '실시간 공동 시청' : language === 'ja' ? 'リアルタイム共同視聴' : language === 'id' ? 'Menonton bersama real-time' : language === 'es' ? 'Visualización compartida en tiempo real' : language === 'pt' ? 'Visualização compartilhada em tempo real' : 'Real-time co-watching', included: true }
      ],
      icon: Crown,
      gradient: 'from-[#FFD60A] to-[#FFA500]'
    }
  ];

  const handleUpgrade = (planId) => {
    const messages = {
      alreadyFree: language === 'ko' ? '이미 무료 플랜을 사용 중이에요' : language === 'ja' ? 'すでに無料プランを使用中です' : language === 'id' ? 'Sudah menggunakan paket gratis' : language === 'es' ? 'Ya estás usando el plan gratuito' : language === 'pt' ? 'Já está usando o plano gratuito' : 'Already on free plan',
      appOnly: language === 'ko' ? '앱에서만 결제 가능해요' : language === 'ja' ? 'アプリでのみ決済可能です' : language === 'id' ? 'Pembayaran hanya tersedia di aplikasi' : language === 'es' ? 'El pago solo está disponible en la aplicación' : language === 'pt' ? 'Pagamento disponível apenas no aplicativo' : 'Payment only available in app',
      redirecting: language === 'ko' ? '인앱 결제로 이동합니다...' : language === 'ja' ? 'アプリ内課金に移動します...' : language === 'id' ? 'Mengarahkan ke pembayaran dalam aplikasi...' : language === 'es' ? 'Redirigiendo al pago en la aplicación...' : language === 'pt' ? 'Redirecionando para pagamento no aplicativo...' : 'Redirecting to in-app purchase...'
    };
    
    if (planId === 'free') {
      toast.error(messages.alreadyFree);
      return;
    }

    // Check if mobile app or web
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    
    if (!isMobile) {
      // Web version - show app store links
      toast.error(messages.appOnly);
      setTimeout(() => {
        const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);
        const storeUrl = isIOS 
          ? 'https://apps.apple.com/app/eolsu'
          : 'https://play.google.com/store/apps/details?id=com.eolsu';
        window.open(storeUrl, '_blank');
      }, 1000);
    } else {
      // Mobile app - redirect to in-app purchase
      toast.success(messages.redirecting);
      // This would trigger native in-app purchase
      // window.ReactNativeWebView?.postMessage(JSON.stringify({ action: 'purchase', plan: planId }));
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#0D1117] border-white/10 max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white text-center mb-2">
            {t('planSelection')}
          </DialogTitle>
          <p className="text-white/50 text-center text-sm">
            {t('unlimitedMusicVideo')}
          </p>
        </DialogHeader>

        <div className="grid md:grid-cols-3 gap-4 mt-6">
          {plans.map((plan, index) => {
            const Icon = plan.icon;
            const isCurrent = currentPlan === plan.id;
            
            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={cn(
                  "relative rounded-2xl p-6 border-2 transition-all cursor-pointer",
                  isCurrent 
                    ? "border-[#4158F1] bg-[#4158F1]/10" 
                    : "border-white/10 bg-white/5 hover:border-white/20"
                )}
                onClick={() => setSelectedPlan(plan.id)}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white text-xs font-bold">
                    {t('mostPopular')}
                  </div>
                )}

                {isCurrent && (
                  <div className="absolute -top-3 right-4 px-3 py-1 rounded-full bg-green-500 text-white text-xs font-bold">
                    {language === 'ko' ? '현재 플랜' : language === 'ja' ? '現在のプラン' : language === 'id' ? 'Paket saat ini' : language === 'es' ? 'Plan actual' : language === 'pt' ? 'Plano atual' : 'Current plan'}
                  </div>
                )}

                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center mb-4 bg-gradient-to-br",
                  plan.gradient
                )}>
                  <Icon className="w-6 h-6 text-white" />
                </div>

                <h3 className="text-white font-bold text-xl mb-2">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-white">{plan.price}</span>
                  <span className="text-white/50 text-sm ml-1">{plan.period}</span>
                </div>

                <div className="space-y-3 mb-6">
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      {feature.included ? (
                        <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                      ) : (
                        <X className="w-4 h-4 text-white/30 flex-shrink-0" />
                      )}
                      <span className={cn(
                        "text-sm",
                        feature.included ? "text-white" : "text-white/30"
                      )}>
                        {feature.text}
                      </span>
                    </div>
                  ))}
                </div>

                {!isCurrent && (
                  <GradientButton
                    fullWidth
                    variant={plan.popular ? 'primary' : 'ghost'}
                    onClick={() => handleUpgrade(plan.id)}
                  >
                    {plan.id === 'free' 
                      ? (language === 'ko' ? '현재 플랜' : language === 'ja' ? '現在のプラン' : language === 'id' ? 'Paket saat ini' : language === 'es' ? 'Plan actual' : language === 'pt' ? 'Plano atual' : 'Current plan')
                      : t('selectPlan')}
                  </GradientButton>
                )}
              </motion.div>
            );
          })}
        </div>

        <div className="mt-6 p-4 rounded-xl bg-white/5 border border-white/10">
          <p className="text-white/70 text-xs text-center">
            💡 {language === 'ko' 
              ? '웹 버전은 무료로 모든 기능을 사용하실 수 있습니다' 
              : language === 'ja' 
              ? 'ウェブ版は全機能を無料でご利用いただけます' 
              : language === 'id' 
              ? 'Versi web gratis untuk semua fitur' 
              : language === 'es' 
              ? 'La versión web es gratuita para todas las funciones' 
              : language === 'pt' 
              ? 'A versão web é gratuita para todos os recursos' 
              : 'Web version is free for all features'}<br />
            {language === 'ko' 
              ? '모바일 앱에서 프리미엄 기능(오프라인, 백그라운드 재생)을 이용하려면 구독이 필요해요' 
              : language === 'ja' 
              ? 'モバイルアプリでプレミアム機能（オフライン、バックグラウンド再生）を利用するにはサブスクリプションが必要です' 
              : language === 'id' 
              ? 'Berlangganan diperlukan untuk fitur premium (offline, pemutaran latar belakang) di aplikasi mobile' 
              : language === 'es' 
              ? 'Se requiere suscripción para funciones premium (offline, reproducción en segundo plano) en la aplicación móvil' 
              : language === 'pt' 
              ? 'Assinatura necessária para recursos premium (offline, reprodução em segundo plano) no aplicativo móvel' 
              : 'Subscription required for premium features (offline, background play) in mobile app'}
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}