import React from 'react';
import { Crown, ExternalLink } from 'lucide-react';
import GlassCard from '@/components/ui/GlassCard';
import { motion } from 'framer-motion';
import { useLanguage } from '@/components/i18n/LanguageContext';

export default function SubscriptionBanner({ subscription = 'free', onUpgrade }) {
  const { t } = useLanguage();
  if (subscription === 'pro') {
    return (
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-4"
      >
        <GlassCard className="p-4 bg-gradient-to-r from-[#FFD60A]/20 to-[#FFA500]/20 border-[#FFD60A]/30">
          <div className="flex items-center gap-3">
            <Crown className="w-6 h-6 text-[#FFD60A]" />
            <div className="flex-1">
              <p className="text-white font-medium">Pro 플랜 사용 중</p>
              <p className="text-white/50 text-xs">모든 프리미엄 기능을 즐기세요!</p>
            </div>
          </div>
        </GlassCard>
      </motion.div>
    );
  }

  if (subscription === 'basic') {
    return (
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-4"
      >
        <GlassCard className="p-4 bg-gradient-to-r from-[#4158F1]/20 to-[#8B5CF6]/20 border-[#4158F1]/30">
          <div className="flex items-center gap-3">
            <Crown className="w-6 h-6 text-[#4158F1]" />
            <div className="flex-1">
              <p className="text-white font-medium">Basic 플랜 사용 중</p>
              <p className="text-white/50 text-xs">Pro로 업그레이드하고 더 많은 기능을!</p>
            </div>
            <button
              onClick={onUpgrade}
              className="px-3 py-1.5 rounded-lg bg-[#4158F1] text-white text-sm font-medium hover:bg-[#4158F1]/80 transition-all"
            >
              업그레이드
            </button>
          </div>
        </GlassCard>
      </motion.div>
    );
  }

  // Free plan
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-4"
    >
      <GlassCard className="p-4 border-white/20">
        <div className="flex items-center gap-3">
          <Crown className="w-6 h-6 text-white/50" />
          <div className="flex-1">
            <p className="text-white font-medium">{t('wantOfflineBackgroundPlay')}</p>
            <p className="text-white/50 text-xs">{t('usePremiumInApp')}</p>
          </div>
          <div className="flex gap-2">
            <a
              href="https://apps.apple.com/app/eolsu"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-lg bg-white/10 text-white text-sm font-medium hover:bg-white/20 transition-all flex items-center gap-1"
            >
              App Store
              <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href="https://play.google.com/store/apps/details?id=com.eolsu"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-lg bg-white/10 text-white text-sm font-medium hover:bg-white/20 transition-all flex items-center gap-1"
            >
              Play Store
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </GlassCard>
    </motion.div>
  );
}