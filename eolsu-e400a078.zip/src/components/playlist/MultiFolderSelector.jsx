import React from 'react';
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronDown, Folder } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useLanguage } from '@/components/i18n/LanguageContext';

export default function MultiFolderSelector({ 
  folders, 
  selectedFolders, 
  onSelectionChange 
}) {
  const { t } = useLanguage();
  
  const toggleFolder = (folderId) => {
    if (selectedFolders.includes(folderId)) {
      onSelectionChange(selectedFolders.filter(id => id !== folderId));
    } else {
      onSelectionChange([...selectedFolders, folderId]);
    }
  };

  const selectAll = () => {
    onSelectionChange(folders.map(f => f.id));
  };

  const clearAll = () => {
    onSelectionChange([]);
  };

  const getDisplayText = () => {
    if (selectedFolders.length === 0) return String(t('selectFolder'));
    if (selectedFolders.length === folders.length) return String(t('allFolders'));
    if (selectedFolders.length === 1) {
      const folder = folders.find(f => f.id === selectedFolders[0]);
      return folder?.name || String(t('oneSelected'));
    }
    return `${selectedFolders.length}${String(t('foldersCount'))}`;
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          className="bg-white/5 border-white/10 text-white hover:bg-white/10 justify-between min-w-[140px]"
        >
          <span className="truncate">{getDisplayText()}</span>
          <ChevronDown className="w-4 h-4 ml-2 flex-shrink-0" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="bg-[#1C2128] border-white/10 text-white w-64 p-2">
        {/* Quick Actions */}
        <div className="flex gap-2 mb-2 pb-2 border-b border-white/10">
          <button
            onClick={selectAll}
            className="flex-1 px-2 py-1 text-xs rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
          >
            {String(t('selectAll'))}
          </button>
          <button
            onClick={clearAll}
            className="flex-1 px-2 py-1 text-xs rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
          >
            {String(t('clearSelection'))}
          </button>
        </div>

        {/* Folder List */}
        <div className="space-y-1 max-h-[300px] overflow-y-auto">
          {folders.length === 0 ? (
            <p className="text-white/50 text-sm text-center py-4">
              {String(t('noFoldersAvailable'))}
            </p>
          ) : (
            folders.map(folder => (
              <label
                key={folder.id}
                className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer transition-colors",
                  "hover:bg-white/10",
                  selectedFolders.includes(folder.id) && "bg-white/5"
                )}
              >
                <Checkbox
                  checked={selectedFolders.includes(folder.id)}
                  onCheckedChange={() => toggleFolder(folder.id)}
                  className="border-white/30"
                />
                <div 
                  className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${folder.color}30` }}
                >
                  <Folder className="w-3 h-3" style={{ color: folder.color }} />
                </div>
                <span className="text-sm flex-1 truncate">{folder.name}</span>
              </label>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}