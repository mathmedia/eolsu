import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import GradientButton from '@/components/ui/GradientButton';
import { Save } from 'lucide-react';

export default function SavePlaylistModal({ open, onClose, onSave, loading }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setIsPublic] = useState(false);

  const handleSubmit = () => {
    if (!name.trim()) return;
    onSave({ name, description, isPublic });
    setName('');
    setDescription('');
    setIsPublic(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#161B22] border-white/10 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white">재생목록 저장</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div>
            <Label className="text-white/70 text-sm mb-2 block">재생목록 이름</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="예: 내가 좋아하는 노래들"
              className="bg-white/5 border-white/10 text-white"
            />
          </div>

          <div>
            <Label className="text-white/70 text-sm mb-2 block">설명 (선택)</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="재생목록에 대한 설명을 입력하세요"
              className="bg-white/5 border-white/10 text-white h-20"
            />
          </div>

          <div className="flex items-center justify-between">
            <Label className="text-white/70 text-sm">공개 재생목록</Label>
            <Switch
              checked={isPublic}
              onCheckedChange={setIsPublic}
            />
          </div>
          {isPublic && (
            <p className="text-white/50 text-xs">
              공개 재생목록은 링크를 통해 누구나 볼 수 있어요
            </p>
          )}
        </div>

        <div className="flex gap-2">
          <GradientButton
            variant="ghost"
            onClick={onClose}
            disabled={loading}
            fullWidth
          >
            취소
          </GradientButton>
          <GradientButton
            onClick={handleSubmit}
            disabled={!name.trim() || loading}
            loading={loading}
            icon={Save}
            fullWidth
          >
            저장
          </GradientButton>
        </div>
      </DialogContent>
    </Dialog>
  );
}