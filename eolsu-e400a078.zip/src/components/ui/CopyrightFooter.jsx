import React from 'react';
import { useLanguage } from '@/components/i18n/LanguageContext';

export default function CopyrightFooter() {
  const { t } = useLanguage();
  
  return (
    <div className="fixed bottom-16 left-0 right-0 pb-2 px-4 pointer-events-none z-30">
      <p className="text-center text-[10px] text-white/30">
        {t('copyrightDisclaimer')}
      </p>
    </div>
  );
}