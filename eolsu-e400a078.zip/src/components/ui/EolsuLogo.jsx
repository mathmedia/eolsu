import React from 'react';

export default function EolsuLogo({ size = 'md', showSubtitle = true }) {
  const sizes = {
    sm: { logo: 'text-2xl', sub: 'text-[8px]' },
    md: { logo: 'text-4xl', sub: 'text-xs' },
    lg: { logo: 'text-6xl', sub: 'text-sm' },
    xl: { logo: 'text-8xl', sub: 'text-base' }
  };

  return (
    <div className="flex flex-col items-center">
      <div className="relative">
        {/* Main Logo */}
        <div className={`${sizes[size].logo} font-bold tracking-tight`}>
          <span className="relative">
            {/* Stylized 'e' with Korean palace roof */}
            <span className="relative inline-block">
              <span className="bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] bg-clip-text text-transparent">
                e
              </span>
              {/* Palace roof curve */}
              <svg 
                className="absolute -top-[30%] left-1/2 -translate-x-1/2 w-[120%]" 
                viewBox="0 0 40 12" 
                fill="none"
              >
                <path 
                  d="M2 10 C10 2, 30 2, 38 10" 
                  stroke="url(#roofGradient)" 
                  strokeWidth="2.5" 
                  strokeLinecap="round"
                  fill="none"
                />
                <path 
                  d="M8 8 C15 3, 25 3, 32 8" 
                  stroke="url(#roofGradient)" 
                  strokeWidth="1.5" 
                  strokeLinecap="round"
                  fill="none"
                />
                <defs>
                  <linearGradient id="roofGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#4158F1" />
                    <stop offset="100%" stopColor="#8B5CF6" />
                  </linearGradient>
                </defs>
              </svg>
            </span>
            <span className="bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] bg-clip-text text-transparent">
              olsu
            </span>
          </span>
        </div>
      </div>
      
      {/* Korean subtitle */}
      {showSubtitle && (
        <span className={`${sizes[size].sub} text-[#FFD60A] font-medium mt-1 tracking-wider`}>
          얼쑤~
        </span>
      )}
    </div>
  );
}