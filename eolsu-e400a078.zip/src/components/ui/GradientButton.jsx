import React from 'react';
import { cn } from "@/lib/utils";
import { Loader2 } from 'lucide-react';

export default function GradientButton({ 
  children, 
  onClick, 
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  fullWidth = false,
  className = '',
  icon: Icon
}) {
  const variants = {
    primary: "bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white shadow-lg shadow-[#4158F1]/25 hover:shadow-[#4158F1]/40",
    accent: "bg-[#FFD60A] text-[#0D1117] font-semibold hover:bg-[#FFD60A]/90",
    ghost: "bg-white/5 text-white border border-white/10 hover:bg-white/10",
    danger: "bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30"
  };

  const sizes = {
    sm: "px-3 py-1.5 text-sm rounded-lg",
    md: "px-5 py-2.5 text-base rounded-xl",
    lg: "px-7 py-3.5 text-lg rounded-xl"
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={cn(
        "font-medium transition-all duration-300 flex items-center justify-center gap-2",
        "disabled:opacity-50 disabled:cursor-not-allowed",
        "active:scale-95",
        variants[variant],
        sizes[size],
        fullWidth && "w-full",
        className
      )}
    >
      {loading ? (
        <Loader2 className="w-5 h-5 animate-spin" />
      ) : Icon ? (
        <Icon className="w-5 h-5" />
      ) : null}
      {children}
    </button>
  );
}