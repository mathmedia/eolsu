export const translations = {
  ko: {
    // Navigation
    home: '추천',
    folders: '폴더',
    playlist: '재생목록',
    profile: '설정',
    
    // Home page
    aiRecommendations: 'AI 맞춤 추천',
    generatingRecommendations: 'AI가 당신을 위한 영상을 찾고 있어요...',
    noVideosYet: '아직 저장된 영상이 없어요',
    saveVideosFirst: '폴더에 영상을 추가하면 AI가 맞춤 추천을 제공해요!',
    goToFolders: '폴더로 이동',
    
    // Folders
    searchFolders: '폴더 검색...',
    createFolder: '새 폴더',
    noFoldersYet: '폴더가 없어요',
    createFirstFolder: '첫 폴더를 만들어보세요!',
    videos: '개의 영상',
    subfolders: '개의 하위폴더',
    
    // Playlist
    dragToReorder: '드래그로 순서 변경',
    repeat: '반복',
    shuffle: '셔플',
    playAll: '전체 재생',
    noVideos: '영상이 없어요',
    addVideosToFolder: '폴더에 영상을 추가해보세요!',
    orderSaved: '순서가 저장되었어요',
    orderSaveFailed: '순서 저장에 실패했어요',
    
    // Profile
    statistics: '통계',
    totalFolders: '전체 폴더',
    totalVideos: '전체 영상',
    blockedUsers: '차단한 사용자',
    editProfile: '프로필 수정',
    editNickname: '닉명 수정',
    nickname: '닉명',
    save: '저장',
    cancel: '취소',
    changeProfileImage: '프로필 이미지 변경',
    uploadNewImage: '새 이미지 업로드',
    management: '관리',
    blockedUsersList: '차단한 사용자',
    noBlockedUsers: '차단한 사용자가 없어요',
    unblock: '차단 해제',
    settings: '설정',
    language: '언어',
    logout: '로그아웃',
    about: '앱 정보',
    version: '버전',
    
    // Video actions
    aiAssistant: 'AI 어시스턴트',
    edit: '수정',
    viewOriginal: '원본 보기',
    copyrightReport: '저작권 신고',
    delete: '삭제',
    
    // Video modal
    addVideo: '영상/노래 추가',
    editVideo: '영상 수정',
    videoUrl: '영상 URL',
    platform: '플랫폼',
    title: '제목',
    thumbnailUrl: '썸네일 URL',
    thumbnailOptional: '썸네일 URL (선택)',
    videoLength: '영상 길이',
    videoLengthOptional: '영상 길이 (선택)',
    notes: '메모',
    notesOptional: '메모 (선택)',
    addComplete: '영상 추가',
    editComplete: '수정 완료',
    enterTitle: '영상 제목을 입력하세요',
    enterUrl: '영상 URL을 입력하세요',
    notesPlaceholder: '이 영상에 대한 메모...',
    
    // Folder modal
    createNewFolder: '새 폴더 만들기',
    folderName: '폴더 이름',
    folderColor: '폴더 색상',
    publicFolder: '공개 폴더',
    publicDescription: '다른 사용자가 이 폴더를 볼 수 있어요',
    enterFolderName: '폴더 이름을 입력하세요',
    
    // Share modal
    shareFolder: '폴더 공유',
    publicLink: '공개 링크',
    copyLink: '링크 복사',
    linkCopied: '링크가 복사되었어요',
    shareViaEmail: '이메일로 공유',
    emailPlaceholder: 'user@example.com',
    sharedWith: '공유된 사용자',
    noSharedUsers: '아직 공유된 사용자가 없어요',
    remove: '제거',
    
    // Copyright report
    reportCopyright: '저작권 침해 신고',
    email: '이메일',
    reportContent: '신고 내용',
    reportPlaceholder: '저작권 침해 사유를 설명해주세요...',
    submitReport: '신고 접수',
    reportSubmitted: '신고가 접수되었습니다',
    reportFailed: '신고 접수에 실패했습니다',
    fillAllFields: '이메일과 메시지를 모두 입력해주세요',
    
    // AI Assistant
    summary: '요약',
    titleSuggestions: '제목 제안',
    socialMedia: '소셜 미디어',
    generateSummary: '요약 생성',
    generating: '생성 중...',
    copied: '복사되었어요',
    apply: '적용',
    
    // Footer
    copyrightDisclaimer: '얼쑤는 공식 YouTube 임베드 플레이어를 사용합니다. 모든 영상의 저작권은 원작자에게 있습니다.',
    
    // Video player
    tapToPlay: '탭하여 재생',
    cannotEmbed: '이 영상은 외부 사이트에서 볼 수 있어요',
    
    // Common
    close: '닫기',
    loading: '로딩 중...',
    error: '오류',
    success: '성공',
    confirm: '확인',
  },
  
  en: {
    // Navigation
    home: 'Discover',
    folders: 'Folders',
    playlist: 'Playlist',
    profile: 'Settings',
    
    // Home page
    aiRecommendations: 'AI Recommendations',
    generatingRecommendations: 'AI is finding videos for you...',
    noVideosYet: 'No videos saved yet',
    saveVideosFirst: 'Add videos to folders and AI will provide personalized recommendations!',
    goToFolders: 'Go to Folders',
    
    // Folders
    searchFolders: 'Search folders...',
    createFolder: 'New Folder',
    noFoldersYet: 'No folders yet',
    createFirstFolder: 'Create your first folder!',
    videos: ' videos',
    subfolders: ' subfolders',
    
    // Playlist
    dragToReorder: 'Drag to reorder',
    repeat: 'Repeat',
    shuffle: 'Shuffle',
    playAll: 'Play All',
    noVideos: 'No videos',
    addVideosToFolder: 'Add videos to your folders!',
    orderSaved: 'Order saved',
    orderSaveFailed: 'Failed to save order',
    
    // Profile
    statistics: 'Statistics',
    totalFolders: 'Total Folders',
    totalVideos: 'Total Videos',
    blockedUsers: 'Blocked Users',
    editProfile: 'Edit Profile',
    editNickname: 'Edit Nickname',
    nickname: 'Nickname',
    save: 'Save',
    cancel: 'Cancel',
    changeProfileImage: 'Change Profile Image',
    uploadNewImage: 'Upload New Image',
    management: 'Management',
    blockedUsersList: 'Blocked Users',
    noBlockedUsers: 'No blocked users',
    unblock: 'Unblock',
    settings: 'Settings',
    language: 'Language',
    logout: 'Logout',
    about: 'About',
    version: 'Version',
    
    // Video actions
    aiAssistant: 'AI Assistant',
    edit: 'Edit',
    viewOriginal: 'View Original',
    copyrightReport: 'Report Copyright',
    delete: 'Delete',
    
    // Video modal
    addVideo: 'Add Video/Music',
    editVideo: 'Edit Video',
    videoUrl: 'Video URL',
    platform: 'Platform',
    title: 'Title',
    thumbnailUrl: 'Thumbnail URL',
    thumbnailOptional: 'Thumbnail URL (optional)',
    videoLength: 'Video Length',
    videoLengthOptional: 'Video Length (optional)',
    notes: 'Notes',
    notesOptional: 'Notes (optional)',
    addComplete: 'Add Video',
    editComplete: 'Update',
    enterTitle: 'Enter video title',
    enterUrl: 'Enter video URL',
    notesPlaceholder: 'Notes about this video...',
    
    // Folder modal
    createNewFolder: 'Create New Folder',
    folderName: 'Folder Name',
    folderColor: 'Folder Color',
    publicFolder: 'Public Folder',
    publicDescription: 'Other users can view this folder',
    enterFolderName: 'Enter folder name',
    
    // Share modal
    shareFolder: 'Share Folder',
    publicLink: 'Public Link',
    copyLink: 'Copy Link',
    linkCopied: 'Link copied',
    shareViaEmail: 'Share via Email',
    emailPlaceholder: 'user@example.com',
    sharedWith: 'Shared With',
    noSharedUsers: 'No shared users yet',
    remove: 'Remove',
    
    // Copyright report
    reportCopyright: 'Report Copyright Violation',
    email: 'Email',
    reportContent: 'Report Details',
    reportPlaceholder: 'Explain the copyright violation...',
    submitReport: 'Submit Report',
    reportSubmitted: 'Report submitted',
    reportFailed: 'Failed to submit report',
    fillAllFields: 'Please fill in all fields',
    
    // AI Assistant
    summary: 'Summary',
    titleSuggestions: 'Title Suggestions',
    socialMedia: 'Social Media',
    generateSummary: 'Generate Summary',
    generating: 'Generating...',
    copied: 'Copied',
    apply: 'Apply',
    
    // Footer
    copyrightDisclaimer: 'Eolsu uses official YouTube embedded player. All videos belong to their respective owners.',
    
    // Video player
    tapToPlay: 'Tap to play',
    cannotEmbed: 'This video can be viewed on external site',
    
    // Common
    close: 'Close',
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
    confirm: 'Confirm',
  },
  
  ja: {
    // Navigation
    home: 'おすすめ',
    folders: 'フォルダ',
    playlist: 'プレイリスト',
    profile: '設定',
    
    // Home page
    aiRecommendations: 'AIおすすめ',
    generatingRecommendations: 'AIがあなたにぴったりの動画を探しています...',
    noVideosYet: 'まだ動画がありません',
    saveVideosFirst: 'フォルダに動画を追加すると、AIがおすすめを提供します！',
    goToFolders: 'フォルダへ',
    
    // Folders
    searchFolders: 'フォルダを検索...',
    createFolder: '新規フォルダ',
    noFoldersYet: 'フォルダがありません',
    createFirstFolder: '最初のフォルダを作成しましょう！',
    videos: '本の動画',
    subfolders: '個のサブフォルダ',
    
    // Playlist
    dragToReorder: 'ドラッグして並び替え',
    repeat: 'リピート',
    shuffle: 'シャッフル',
    playAll: 'すべて再生',
    noVideos: '動画がありません',
    addVideosToFolder: 'フォルダに動画を追加してください！',
    orderSaved: '順序を保存しました',
    orderSaveFailed: '順序の保存に失敗しました',
    
    // Profile
    statistics: '統計',
    totalFolders: '総フォルダ数',
    totalVideos: '総動画数',
    blockedUsers: 'ブロック中のユーザー',
    editProfile: 'プロフィール編集',
    editNickname: 'ニックネーム編集',
    nickname: 'ニックネーム',
    save: '保存',
    cancel: 'キャンセル',
    changeProfileImage: 'プロフィール画像を変更',
    uploadNewImage: '新しい画像をアップロード',
    management: '管理',
    blockedUsersList: 'ブロック中のユーザー',
    noBlockedUsers: 'ブロック中のユーザーはいません',
    unblock: 'ブロック解除',
    settings: '設定',
    language: '言語',
    logout: 'ログアウト',
    about: 'アプリについて',
    version: 'バージョン',
    
    // Video actions
    aiAssistant: 'AIアシスタント',
    edit: '編集',
    viewOriginal: 'オリジナルを見る',
    copyrightReport: '著作権違反を報告',
    delete: '削除',
    
    // Video modal
    addVideo: '動画/音楽を追加',
    editVideo: '動画を編集',
    videoUrl: '動画URL',
    platform: 'プラットフォーム',
    title: 'タイトル',
    thumbnailUrl: 'サムネイルURL',
    thumbnailOptional: 'サムネイルURL（任意）',
    videoLength: '動画の長さ',
    videoLengthOptional: '動画の長さ（任意）',
    notes: 'メモ',
    notesOptional: 'メモ（任意）',
    addComplete: '動画を追加',
    editComplete: '更新',
    enterTitle: '動画のタイトルを入力',
    enterUrl: '動画URLを入力',
    notesPlaceholder: 'この動画についてのメモ...',
    
    // Folder modal
    createNewFolder: '新しいフォルダを作成',
    folderName: 'フォルダ名',
    folderColor: 'フォルダの色',
    publicFolder: '公開フォルダ',
    publicDescription: '他のユーザーがこのフォルダを見ることができます',
    enterFolderName: 'フォルダ名を入力',
    
    // Share modal
    shareFolder: 'フォルダを共有',
    publicLink: '公開リンク',
    copyLink: 'リンクをコピー',
    linkCopied: 'リンクをコピーしました',
    shareViaEmail: 'メールで共有',
    emailPlaceholder: 'user@example.com',
    sharedWith: '共有中',
    noSharedUsers: 'まだ共有されていません',
    remove: '削除',
    
    // Copyright report
    reportCopyright: '著作権違反を報告',
    email: 'メール',
    reportContent: '報告内容',
    reportPlaceholder: '著作権違反の理由を説明してください...',
    submitReport: '報告を送信',
    reportSubmitted: '報告を受け付けました',
    reportFailed: '報告の送信に失敗しました',
    fillAllFields: 'すべての項目を入力してください',
    
    // AI Assistant
    summary: '要約',
    titleSuggestions: 'タイトル提案',
    socialMedia: 'ソーシャルメディア',
    generateSummary: '要約を生成',
    generating: '生成中...',
    copied: 'コピーしました',
    apply: '適用',
    
    // Footer
    copyrightDisclaimer: 'Eolsuは公式YouTube埋め込みプレーヤーを使用しています。すべての動画は各所有者に帰属します。',
    
    // Video player
    tapToPlay: 'タップして再生',
    cannotEmbed: 'この動画は外部サイトで視聴できます',
    
    // Common
    close: '閉じる',
    loading: '読み込み中...',
    error: 'エラー',
    success: '成功',
    confirm: '確認',
  },
  
  id: {
    // Navigation
    home: 'Rekomendasi',
    folders: 'Folder',
    playlist: 'Daftar Putar',
    profile: 'Pengaturan',
    
    // Home page
    aiRecommendations: 'Rekomendasi AI',
    generatingRecommendations: 'AI sedang mencari video untuk Anda...',
    noVideosYet: 'Belum ada video',
    saveVideosFirst: 'Tambahkan video ke folder dan AI akan memberikan rekomendasi!',
    goToFolders: 'Ke Folder',
    
    // Folders
    searchFolders: 'Cari folder...',
    createFolder: 'Folder Baru',
    noFoldersYet: 'Belum ada folder',
    createFirstFolder: 'Buat folder pertama Anda!',
    videos: ' video',
    subfolders: ' subfolder',
    
    // Playlist
    dragToReorder: 'Seret untuk mengurutkan',
    repeat: 'Ulangi',
    shuffle: 'Acak',
    playAll: 'Putar Semua',
    noVideos: 'Tidak ada video',
    addVideosToFolder: 'Tambahkan video ke folder!',
    orderSaved: 'Urutan tersimpan',
    orderSaveFailed: 'Gagal menyimpan urutan',
    
    // Profile
    statistics: 'Statistik',
    totalFolders: 'Total Folder',
    totalVideos: 'Total Video',
    blockedUsers: 'Pengguna Diblokir',
    editProfile: 'Edit Profil',
    editNickname: 'Edit Nama Panggilan',
    nickname: 'Nama Panggilan',
    save: 'Simpan',
    cancel: 'Batal',
    changeProfileImage: 'Ubah Foto Profil',
    uploadNewImage: 'Unggah Gambar Baru',
    management: 'Manajemen',
    blockedUsersList: 'Pengguna Diblokir',
    noBlockedUsers: 'Tidak ada pengguna diblokir',
    unblock: 'Buka Blokir',
    settings: 'Pengaturan',
    language: 'Bahasa',
    logout: 'Keluar',
    about: 'Tentang',
    version: 'Versi',
    
    // Video actions
    aiAssistant: 'Asisten AI',
    edit: 'Edit',
    viewOriginal: 'Lihat Asli',
    copyrightReport: 'Laporkan Hak Cipta',
    delete: 'Hapus',
    
    // Video modal
    addVideo: 'Tambah Video/Musik',
    editVideo: 'Edit Video',
    videoUrl: 'URL Video',
    platform: 'Platform',
    title: 'Judul',
    thumbnailUrl: 'URL Thumbnail',
    thumbnailOptional: 'URL Thumbnail (opsional)',
    videoLength: 'Durasi Video',
    videoLengthOptional: 'Durasi Video (opsional)',
    notes: 'Catatan',
    notesOptional: 'Catatan (opsional)',
    addComplete: 'Tambah Video',
    editComplete: 'Perbarui',
    enterTitle: 'Masukkan judul video',
    enterUrl: 'Masukkan URL video',
    notesPlaceholder: 'Catatan tentang video ini...',
    
    // Folder modal
    createNewFolder: 'Buat Folder Baru',
    folderName: 'Nama Folder',
    folderColor: 'Warna Folder',
    publicFolder: 'Folder Publik',
    publicDescription: 'Pengguna lain dapat melihat folder ini',
    enterFolderName: 'Masukkan nama folder',
    
    // Share modal
    shareFolder: 'Bagikan Folder',
    publicLink: 'Tautan Publik',
    copyLink: 'Salin Tautan',
    linkCopied: 'Tautan disalin',
    shareViaEmail: 'Bagikan via Email',
    emailPlaceholder: 'user@example.com',
    sharedWith: 'Dibagikan Dengan',
    noSharedUsers: 'Belum ada pengguna berbagi',
    remove: 'Hapus',
    
    // Copyright report
    reportCopyright: 'Laporkan Pelanggaran Hak Cipta',
    email: 'Email',
    reportContent: 'Detail Laporan',
    reportPlaceholder: 'Jelaskan pelanggaran hak cipta...',
    submitReport: 'Kirim Laporan',
    reportSubmitted: 'Laporan terkirim',
    reportFailed: 'Gagal mengirim laporan',
    fillAllFields: 'Harap isi semua kolom',
    
    // AI Assistant
    summary: 'Ringkasan',
    titleSuggestions: 'Saran Judul',
    socialMedia: 'Media Sosial',
    generateSummary: 'Buat Ringkasan',
    generating: 'Membuat...',
    copied: 'Tersalin',
    apply: 'Terapkan',
    
    // Footer
    copyrightDisclaimer: 'Eolsu menggunakan pemutar YouTube resmi. Semua video adalah milik pemilik masing-masing.',
    
    // Video player
    tapToPlay: 'Ketuk untuk memutar',
    cannotEmbed: 'Video ini dapat dilihat di situs eksternal',
    
    // Common
    close: 'Tutup',
    loading: 'Memuat...',
    error: 'Kesalahan',
    success: 'Berhasil',
    confirm: 'Konfirmasi',
  },
  
  es: {
    // Navigation
    home: 'Descubrir',
    folders: 'Carpetas',
    playlist: 'Lista de Reproducción',
    profile: 'Ajustes',
    
    // Home page
    aiRecommendations: 'Recomendaciones de IA',
    generatingRecommendations: 'La IA está buscando videos para ti...',
    noVideosYet: 'Aún no hay videos',
    saveVideosFirst: '¡Agrega videos a las carpetas y la IA te dará recomendaciones!',
    goToFolders: 'Ir a Carpetas',
    
    // Folders
    searchFolders: 'Buscar carpetas...',
    createFolder: 'Nueva Carpeta',
    noFoldersYet: 'Aún no hay carpetas',
    createFirstFolder: '¡Crea tu primera carpeta!',
    videos: ' videos',
    subfolders: ' subcarpetas',
    
    // Playlist
    dragToReorder: 'Arrastra para reordenar',
    repeat: 'Repetir',
    shuffle: 'Aleatorio',
    playAll: 'Reproducir Todo',
    noVideos: 'No hay videos',
    addVideosToFolder: '¡Agrega videos a tus carpetas!',
    orderSaved: 'Orden guardado',
    orderSaveFailed: 'Error al guardar orden',
    
    // Profile
    statistics: 'Estadísticas',
    totalFolders: 'Total de Carpetas',
    totalVideos: 'Total de Videos',
    blockedUsers: 'Usuarios Bloqueados',
    editProfile: 'Editar Perfil',
    editNickname: 'Editar Apodo',
    nickname: 'Apodo',
    save: 'Guardar',
    cancel: 'Cancelar',
    changeProfileImage: 'Cambiar Foto de Perfil',
    uploadNewImage: 'Subir Nueva Imagen',
    management: 'Gestión',
    blockedUsersList: 'Usuarios Bloqueados',
    noBlockedUsers: 'No hay usuarios bloqueados',
    unblock: 'Desbloquear',
    settings: 'Ajustes',
    language: 'Idioma',
    logout: 'Cerrar Sesión',
    about: 'Acerca de',
    version: 'Versión',
    
    // Video actions
    aiAssistant: 'Asistente IA',
    edit: 'Editar',
    viewOriginal: 'Ver Original',
    copyrightReport: 'Reportar Derechos de Autor',
    delete: 'Eliminar',
    
    // Video modal
    addVideo: 'Agregar Video/Música',
    editVideo: 'Editar Video',
    videoUrl: 'URL del Video',
    platform: 'Plataforma',
    title: 'Título',
    thumbnailUrl: 'URL de Miniatura',
    thumbnailOptional: 'URL de Miniatura (opcional)',
    videoLength: 'Duración del Video',
    videoLengthOptional: 'Duración del Video (opcional)',
    notes: 'Notas',
    notesOptional: 'Notas (opcional)',
    addComplete: 'Agregar Video',
    editComplete: 'Actualizar',
    enterTitle: 'Ingresa el título del video',
    enterUrl: 'Ingresa la URL del video',
    notesPlaceholder: 'Notas sobre este video...',
    
    // Folder modal
    createNewFolder: 'Crear Nueva Carpeta',
    folderName: 'Nombre de la Carpeta',
    folderColor: 'Color de la Carpeta',
    publicFolder: 'Carpeta Pública',
    publicDescription: 'Otros usuarios pueden ver esta carpeta',
    enterFolderName: 'Ingresa el nombre de la carpeta',
    
    // Share modal
    shareFolder: 'Compartir Carpeta',
    publicLink: 'Enlace Público',
    copyLink: 'Copiar Enlace',
    linkCopied: 'Enlace copiado',
    shareViaEmail: 'Compartir por Email',
    emailPlaceholder: 'usuario@ejemplo.com',
    sharedWith: 'Compartido Con',
    noSharedUsers: 'Aún no hay usuarios compartidos',
    remove: 'Eliminar',
    
    // Copyright report
    reportCopyright: 'Reportar Violación de Derechos de Autor',
    email: 'Email',
    reportContent: 'Detalles del Reporte',
    reportPlaceholder: 'Explica la violación de derechos de autor...',
    submitReport: 'Enviar Reporte',
    reportSubmitted: 'Reporte enviado',
    reportFailed: 'Error al enviar reporte',
    fillAllFields: 'Por favor completa todos los campos',
    
    // AI Assistant
    summary: 'Resumen',
    titleSuggestions: 'Sugerencias de Título',
    socialMedia: 'Redes Sociales',
    generateSummary: 'Generar Resumen',
    generating: 'Generando...',
    copied: 'Copiado',
    apply: 'Aplicar',
    
    // Footer
    copyrightDisclaimer: 'Eolsu usa el reproductor oficial de YouTube. Todos los videos pertenecen a sus respectivos propietarios.',
    
    // Video player
    tapToPlay: 'Toca para reproducir',
    cannotEmbed: 'Este video se puede ver en el sitio externo',
    
    // Common
    close: 'Cerrar',
    loading: 'Cargando...',
    error: 'Error',
    success: 'Éxito',
    confirm: 'Confirmar',
  },
  
  pt: {
    // Navigation
    home: 'Descobrir',
    folders: 'Pastas',
    playlist: 'Lista de Reprodução',
    profile: 'Configurações',
    
    // Home page
    aiRecommendations: 'Recomendações de IA',
    generatingRecommendations: 'A IA está procurando vídeos para você...',
    noVideosYet: 'Ainda não há vídeos',
    saveVideosFirst: 'Adicione vídeos às pastas e a IA fornecerá recomendações!',
    goToFolders: 'Ir para Pastas',
    
    // Folders
    searchFolders: 'Buscar pastas...',
    createFolder: 'Nova Pasta',
    noFoldersYet: 'Ainda não há pastas',
    createFirstFolder: 'Crie sua primeira pasta!',
    videos: ' vídeos',
    subfolders: ' subpastas',
    
    // Playlist
    dragToReorder: 'Arraste para reordenar',
    repeat: 'Repetir',
    shuffle: 'Aleatório',
    playAll: 'Reproduzir Tudo',
    noVideos: 'Não há vídeos',
    addVideosToFolder: 'Adicione vídeos às suas pastas!',
    orderSaved: 'Ordem salva',
    orderSaveFailed: 'Falha ao salvar ordem',
    
    // Profile
    statistics: 'Estatísticas',
    totalFolders: 'Total de Pastas',
    totalVideos: 'Total de Vídeos',
    blockedUsers: 'Usuários Bloqueados',
    editProfile: 'Editar Perfil',
    editNickname: 'Editar Apelido',
    nickname: 'Apelido',
    save: 'Salvar',
    cancel: 'Cancelar',
    changeProfileImage: 'Mudar Foto de Perfil',
    uploadNewImage: 'Enviar Nova Imagem',
    management: 'Gerenciamento',
    blockedUsersList: 'Usuários Bloqueados',
    noBlockedUsers: 'Nenhum usuário bloqueado',
    unblock: 'Desbloquear',
    settings: 'Configurações',
    language: 'Idioma',
    logout: 'Sair',
    about: 'Sobre',
    version: 'Versão',
    
    // Video actions
    aiAssistant: 'Assistente de IA',
    edit: 'Editar',
    viewOriginal: 'Ver Original',
    copyrightReport: 'Reportar Direitos Autorais',
    delete: 'Excluir',
    
    // Video modal
    addVideo: 'Adicionar Vídeo/Música',
    editVideo: 'Editar Vídeo',
    videoUrl: 'URL do Vídeo',
    platform: 'Plataforma',
    title: 'Título',
    thumbnailUrl: 'URL da Miniatura',
    thumbnailOptional: 'URL da Miniatura (opcional)',
    videoLength: 'Duração do Vídeo',
    videoLengthOptional: 'Duração do Vídeo (opcional)',
    notes: 'Notas',
    notesOptional: 'Notas (opcional)',
    addComplete: 'Adicionar Vídeo',
    editComplete: 'Atualizar',
    enterTitle: 'Digite o título do vídeo',
    enterUrl: 'Digite a URL do vídeo',
    notesPlaceholder: 'Notas sobre este vídeo...',
    
    // Folder modal
    createNewFolder: 'Criar Nova Pasta',
    folderName: 'Nome da Pasta',
    folderColor: 'Cor da Pasta',
    publicFolder: 'Pasta Pública',
    publicDescription: 'Outros usuários podem ver esta pasta',
    enterFolderName: 'Digite o nome da pasta',
    
    // Share modal
    shareFolder: 'Compartilhar Pasta',
    publicLink: 'Link Público',
    copyLink: 'Copiar Link',
    linkCopied: 'Link copiado',
    shareViaEmail: 'Compartilhar por Email',
    emailPlaceholder: 'usuario@exemplo.com',
    sharedWith: 'Compartilhado Com',
    noSharedUsers: 'Ainda não há usuários compartilhados',
    remove: 'Remover',
    
    // Copyright report
    reportCopyright: 'Reportar Violação de Direitos Autorais',
    email: 'Email',
    reportContent: 'Detalhes do Relatório',
    reportPlaceholder: 'Explique a violação de direitos autorais...',
    submitReport: 'Enviar Relatório',
    reportSubmitted: 'Relatório enviado',
    reportFailed: 'Falha ao enviar relatório',
    fillAllFields: 'Por favor, preencha todos os campos',
    
    // AI Assistant
    summary: 'Resumo',
    titleSuggestions: 'Sugestões de Título',
    socialMedia: 'Redes Sociais',
    generateSummary: 'Gerar Resumo',
    generating: 'Gerando...',
    copied: 'Copiado',
    apply: 'Aplicar',
    
    // Footer
    copyrightDisclaimer: 'Eolsu usa o player oficial do YouTube. Todos os vídeos pertencem aos seus respectivos proprietários.',
    
    // Video player
    tapToPlay: 'Toque para reproduzir',
    cannotEmbed: 'Este vídeo pode ser visto no site externo',
    
    // Common
    close: 'Fechar',
    loading: 'Carregando...',
    error: 'Erro',
    success: 'Sucesso',
    confirm: 'Confirmar',
  }
};

export const languageOptions = [
  { code: 'ko', name: '한국어', flag: '🇰🇷' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'ja', name: '日本語', flag: '🇯🇵' },
  { code: 'id', name: 'Bahasa Indonesia', flag: '🇮🇩' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'pt', name: 'Português', flag: '🇧🇷' },
];