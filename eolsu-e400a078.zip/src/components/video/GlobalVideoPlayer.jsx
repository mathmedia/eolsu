import React, { createContext, useContext, useState, useEffect } from 'react';
import VideoPlayer from '@/components/videos/VideoPlayer';

const VideoPlayerContext = createContext();

export const useVideoPlayer = () => {
  const context = useContext(VideoPlayerContext);
  if (!context) {
    throw new Error('useVideoPlayer must be used within VideoPlayerProvider');
  }
  return context;
};

export const VideoPlayerProvider = ({ children }) => {
  const [playingVideo, setPlayingVideo] = useState(null);
  const [playlist, setPlaylist] = useState([]);
  const [isMinimized, setIsMinimized] = useState(false);
  const [repeatMode, setRepeatMode] = useState(false);

  const playVideo = (video, videoPlaylist = [], repeat = false) => {
    setPlayingVideo(video);
    setPlaylist(videoPlaylist);
    setRepeatMode(repeat);
    setIsMinimized(false);
  };

  const closePlayer = () => {
    setPlayingVideo(null);
    setPlaylist([]);
    setIsMinimized(false);
  };

  const minimizePlayer = () => {
    setIsMinimized(true);
  };

  const maximizePlayer = () => {
    setIsMinimized(false);
  };

  const navigateVideo = (video) => {
    setPlayingVideo(video);
    setIsMinimized(false);
  };

  // Expose maximizePlayer globally for minimized player
  useEffect(() => {
    window.useVideoPlayer = { maximizePlayer };
    return () => {
      delete window.useVideoPlayer;
    };
  }, []);

  return (
    <VideoPlayerContext.Provider value={{ 
      playVideo, 
      closePlayer, 
      minimizePlayer,
      maximizePlayer,
      playingVideo,
      isMinimized,
      repeatMode,
      setRepeatMode
    }}>
      {children}
      {playingVideo && (
        <VideoPlayer
          video={playingVideo}
          open={!isMinimized}
          minimized={isMinimized}
          onClose={closePlayer}
          onMinimize={minimizePlayer}
          playlist={playlist}
          onNavigate={navigateVideo}
          repeatMode={repeatMode}
        />
      )}
    </VideoPlayerContext.Provider>
  );
};