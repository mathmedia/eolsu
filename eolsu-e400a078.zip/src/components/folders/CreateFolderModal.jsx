import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import GradientButton from '@/components/ui/GradientButton';
import { Folder, Globe, Lock } from 'lucide-react';

const COLORS = [
  '#4158F1', '#8B5CF6', '#EC4899', '#F59E0B', 
  '#10B981', '#06B6D4', '#EF4444', '#FFD60A'
];

export default function CreateFolderModal({ 
  open, 
  onClose, 
  onSubmit, 
  parentId = null,
  loading = false 
}) {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#4158F1');
  const [isPublic, setIsPublic] = useState(false);

  const handleSubmit = () => {
    if (!name.trim()) return;
    onSubmit({ name: name.trim(), color, is_public: isPublic, parent_id: parentId });
    setName('');
    setColor('#4158F1');
    setIsPublic(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#161B22] border-white/10 text-white max-w-sm mx-4">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Folder className="w-5 h-5 text-[#8B5CF6]" />
            새 폴더 만들기
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 mt-4">
          {/* Folder Name */}
          <div className="space-y-2">
            <Label className="text-white/70">폴더 이름</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="예: 좋아하는 음악"
              className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-[#4158F1]"
            />
          </div>

          {/* Color Selection */}
          <div className="space-y-2">
            <Label className="text-white/70">폴더 색상</Label>
            <div className="flex gap-2 flex-wrap">
              {COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className={`w-8 h-8 rounded-full transition-all duration-200 ${
                    color === c 
                      ? 'ring-2 ring-white ring-offset-2 ring-offset-[#161B22] scale-110' 
                      : 'hover:scale-105'
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          {/* Public Toggle */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="flex items-center gap-3">
              {isPublic ? (
                <Globe className="w-5 h-5 text-[#8B5CF6]" />
              ) : (
                <Lock className="w-5 h-5 text-white/50" />
              )}
              <div>
                <p className="text-sm font-medium">공개 폴더</p>
                <p className="text-xs text-white/50">
                  {isPublic ? '누구나 볼 수 있어요' : '나만 볼 수 있어요'}
                </p>
              </div>
            </div>
            <Switch 
              checked={isPublic} 
              onCheckedChange={setIsPublic}
            />
          </div>

          {/* Submit Button */}
          <GradientButton 
            fullWidth 
            onClick={handleSubmit}
            loading={loading}
            disabled={!name.trim()}
          >
            폴더 만들기
          </GradientButton>
        </div>
      </DialogContent>
    </Dialog>
  );
}