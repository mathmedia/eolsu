import React from 'react';
import { ChevronRight, Home } from 'lucide-react';
import { cn } from "@/lib/utils";

export default function FolderBreadcrumbs({ path = [], onNavigate }) {
  return (
    <div className="flex items-center gap-1 text-sm overflow-x-auto no-scrollbar">
      <button
        onClick={() => onNavigate(null)}
        className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-white/5 transition-colors flex-shrink-0"
      >
        <Home className="w-4 h-4 text-white/70" />
        <span className="text-white/70">홈</span>
      </button>
      
      {path.map((folder, index) => {
        const isLast = index === path.length - 1;
        return (
          <React.Fragment key={folder.id}>
            <ChevronRight className="w-4 h-4 text-white/30 flex-shrink-0" />
            <button
              onClick={() => !isLast && onNavigate(folder.id)}
              disabled={isLast}
              className={cn(
                "px-2 py-1 rounded-lg transition-colors flex-shrink-0",
                isLast 
                  ? "text-white font-medium cursor-default" 
                  : "text-white/70 hover:bg-white/5 hover:text-white"
              )}
            >
              {folder.name}
            </button>
          </React.Fragment>
        );
      })}
    </div>
  );
}