import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Link2, Mail, Copy, Check, Loader2, X } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from "@/lib/utils";

export default function ShareFolderModal({ 
  open, 
  onClose, 
  folder,
  sharedUsers = [],
  onShareByEmail,
  onRemoveShare,
  loading
}) {
  const [email, setEmail] = useState('');
  const [copied, setCopied] = useState(false);

  const shareLink = folder?.share_code 
    ? `${window.location.origin}/SharedFolder?code=${folder.share_code}`
    : null;

  const copyLink = () => {
    if (shareLink) {
      navigator.clipboard.writeText(shareLink);
      setCopied(true);
      toast.success('링크가 복사되었어요');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleEmailShare = () => {
    if (!email.trim()) return;
    if (!email.includes('@')) {
      toast.error('올바른 이메일을 입력해주세요');
      return;
    }
    onShareByEmail(email.trim());
    setEmail('');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#161B22] border-white/10 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Link2 className="w-5 h-5 text-[#8B5CF6]" />
            폴더 공유
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 pt-2">
          {/* Public Link Section */}
          {folder?.is_public && shareLink && (
            <div className="space-y-2">
              <label className="text-sm text-white/70">공개 링크</label>
              <div className="flex gap-2">
                <Input
                  value={shareLink}
                  readOnly
                  className="bg-white/5 border-white/10 text-white text-sm"
                />
                <Button
                  onClick={copyLink}
                  className={cn(
                    "px-3 transition-all",
                    copied 
                      ? "bg-green-500/20 text-green-400" 
                      : "bg-white/10 hover:bg-white/20 text-white"
                  )}
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
              <p className="text-xs text-white/40">
                이 링크를 가진 모든 사람이 폴더를 볼 수 있어요
              </p>
            </div>
          )}

          {/* Email Share Section */}
          <div className="space-y-2">
            <label className="text-sm text-white/70 flex items-center gap-2">
              <Mail className="w-4 h-4" />
              이메일로 공유
            </label>
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleEmailShare()}
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
              />
              <Button
                onClick={handleEmailShare}
                disabled={loading || !email.trim()}
                className="bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white px-4"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : '공유'}
              </Button>
            </div>
          </div>

          {/* Shared Users List */}
          {sharedUsers.length > 0 && (
            <div className="space-y-2">
              <label className="text-sm text-white/70">공유된 사용자</label>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {sharedUsers.map((share) => (
                  <div 
                    key={share.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-white/5"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#4158F1] to-[#8B5CF6] flex items-center justify-center text-white text-sm font-medium">
                        {share.shared_with_email[0].toUpperCase()}
                      </div>
                      <span className="text-sm text-white/80">{share.shared_with_email}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onRemoveShare(share.id)}
                      className="h-8 w-8 text-white/40 hover:text-red-400 hover:bg-red-500/10"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}