const YOUTUBE_API_KEY = 'AIzaSyAEXz19jeXmSs52DCZU7HpvHQqToYNWrHM';
const YOUTUBE_API_BASE = 'https://www.googleapis.com/youtube/v3';

export const getVideoIdFromUrl = (url) => {
  if (!url) return null;
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([^&\s?]+)/);
  return match ? match[1] : null;
};

export const fetchVideoDetails = async (videoId) => {
  try {
    const response = await fetch(
      `${YOUTUBE_API_BASE}/videos?part=snippet,contentDetails&id=${videoId}&key=${YOUTUBE_API_KEY}`
    );
    
    if (!response.ok) {
      throw new Error('Failed to fetch video details');
    }
    
    const data = await response.json();
    
    if (!data.items || data.items.length === 0) {
      return null;
    }
    
    const video = data.items[0];
    return {
      title: video.snippet.title,
      thumbnail: video.snippet.thumbnails.maxres?.url || 
                 video.snippet.thumbnails.high?.url || 
                 video.snippet.thumbnails.medium?.url,
      duration: parseDuration(video.contentDetails.duration),
      channelTitle: video.snippet.channelTitle,
    };
  } catch (error) {
    console.error('YouTube API Error:', error);
    return null;
  }
};

export const fetchTrendingVideos = async (regionCode = 'KR', maxResults = 20) => {
  try {
    const response = await fetch(
      `${YOUTUBE_API_BASE}/videos?part=snippet,contentDetails,statistics&chart=mostPopular&regionCode=${regionCode}&maxResults=${maxResults}&key=${YOUTUBE_API_KEY}`
    );
    
    if (!response.ok) {
      throw new Error('Failed to fetch trending videos');
    }
    
    const data = await response.json();
    
    return data.items.map(video => ({
      id: video.id,
      title: video.snippet.title,
      thumbnail: video.snippet.thumbnails.high?.url || video.snippet.thumbnails.medium?.url,
      channelTitle: video.snippet.channelTitle,
      viewCount: formatViewCount(video.statistics.viewCount),
      duration: parseDuration(video.contentDetails.duration),
      videoId: video.id,
    }));
  } catch (error) {
    console.error('YouTube API Error:', error);
    return [];
  }
};

export const searchVideos = async (query, maxResults = 10) => {
  try {
    const response = await fetch(
      `${YOUTUBE_API_BASE}/search?part=snippet&q=${encodeURIComponent(query)}&type=video&maxResults=${maxResults}&key=${YOUTUBE_API_KEY}`
    );
    
    if (!response.ok) {
      const error = await response.json();
      console.error('YouTube API Error Response:', error);
      throw new Error('Failed to search videos');
    }
    
    const data = await response.json();
    
    if (!data.items || data.items.length === 0) {
      console.warn('No videos found for query:', query);
      return [];
    }
    
    return data.items.map(item => ({
      id: item.id.videoId,
      title: item.snippet.title,
      thumbnail: item.snippet.thumbnails.high?.url || item.snippet.thumbnails.medium?.url,
      channelTitle: item.snippet.channelTitle,
      videoId: item.id.videoId,
    }));
  } catch (error) {
    console.error('YouTube API Error:', error);
    return [];
  }
};

const parseDuration = (duration) => {
  const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
  if (!match) return '';
  
  const hours = (match[1] || '').replace('H', '');
  const minutes = (match[2] || '').replace('M', '');
  const seconds = (match[3] || '').replace('S', '');
  
  if (hours) {
    return `${hours}:${minutes.padStart(2, '0')}:${seconds.padStart(2, '0')}`;
  }
  return `${minutes || '0'}:${seconds.padStart(2, '0')}`;
};

const formatViewCount = (count) => {
  const num = parseInt(count);
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M`;
  }
  if (num >= 1000) {
    return `${(num / 1000).toFixed(1)}K`;
  }
  return num.toString();
};

export const COUNTRIES = [
  { code: 'KR', name_ko: '한국', name_en: 'South Korea', name_ja: '韓国', name_id: 'Korea Selatan', name_es: 'Corea del Sur', name_pt: 'Coreia do Sul', flag: '🇰🇷' },
  { code: 'US', name_ko: '미국', name_en: 'USA', name_ja: 'アメリカ', name_id: 'Amerika', name_es: 'EE.UU.', name_pt: 'EUA', flag: '🇺🇸' },
  { code: 'JP', name_ko: '일본', name_en: 'Japan', name_ja: '日本', name_id: 'Jepang', name_es: 'Japón', name_pt: 'Japão', flag: '🇯🇵' },
  { code: 'ID', name_ko: '인도네시아', name_en: 'Indonesia', name_ja: 'インドネシア', name_id: 'Indonesia', name_es: 'Indonesia', name_pt: 'Indonésia', flag: '🇮🇩' },
  { code: 'GB', name_ko: '영국', name_en: 'UK', name_ja: 'イギリス', name_id: 'Inggris', name_es: 'Reino Unido', name_pt: 'Reino Unido', flag: '🇬🇧' },
  { code: 'BR', name_ko: '브라질', name_en: 'Brazil', name_ja: 'ブラジル', name_id: 'Brasil', name_es: 'Brasil', name_pt: 'Brasil', flag: '🇧🇷' },
];