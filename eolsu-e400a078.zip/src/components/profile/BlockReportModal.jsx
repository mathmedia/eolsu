import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import GradientButton from '@/components/ui/GradientButton';
import { Ban, Flag, AlertTriangle } from 'lucide-react';

const REPORT_REASONS = [
  { value: 'spam', label: '스팸' },
  { value: 'inappropriate', label: '부적절한 콘텐츠' },
  { value: 'harassment', label: '괴롭힘 또는 혐오' },
  { value: 'copyright', label: '저작권 침해' },
  { value: 'other', label: '기타' }
];

export default function BlockReportModal({ 
  open, 
  onClose, 
  targetEmail,
  targetName,
  contentType = 'user',
  contentId = null,
  onBlock,
  onReport,
  loading = false 
}) {
  const [tab, setTab] = useState('block');
  const [blockReason, setBlockReason] = useState('');
  const [reportReason, setReportReason] = useState('spam');
  const [reportDetails, setReportDetails] = useState('');

  const handleBlock = () => {
    onBlock({ reason: blockReason });
    setBlockReason('');
  };

  const handleReport = () => {
    onReport({ 
      reason: reportReason, 
      details: reportDetails,
      content_type: contentType,
      content_id: contentId
    });
    setReportReason('spam');
    setReportDetails('');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#161B22] border-white/10 text-white max-w-sm mx-4">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-[#FFD60A]" />
            사용자 관리
          </DialogTitle>
          <DialogDescription className="text-white/50">
            {targetName || targetEmail}님에 대한 조치
          </DialogDescription>
        </DialogHeader>

        <Tabs value={tab} onValueChange={setTab} className="mt-4">
          <TabsList className="w-full bg-white/5">
            <TabsTrigger value="block" className="flex-1 data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
              <Ban className="w-4 h-4 mr-2" />
              차단
            </TabsTrigger>
            <TabsTrigger value="report" className="flex-1 data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-400">
              <Flag className="w-4 h-4 mr-2" />
              신고
            </TabsTrigger>
          </TabsList>

          <TabsContent value="block" className="mt-4 space-y-4">
            <p className="text-white/70 text-sm">
              이 사용자를 차단하면 더 이상 해당 사용자의 공유 폴더를 볼 수 없습니다.
            </p>
            <div className="space-y-2">
              <Label className="text-white/70">차단 사유 (선택)</Label>
              <Textarea
                value={blockReason}
                onChange={(e) => setBlockReason(e.target.value)}
                placeholder="차단하는 이유를 입력하세요..."
                rows={3}
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none"
              />
            </div>
            <GradientButton 
              fullWidth 
              variant="danger"
              onClick={handleBlock}
              loading={loading}
            >
              <Ban className="w-4 h-4" />
              차단하기
            </GradientButton>
          </TabsContent>

          <TabsContent value="report" className="mt-4 space-y-4">
            <div className="space-y-3">
              <Label className="text-white/70">신고 사유</Label>
              <RadioGroup value={reportReason} onValueChange={setReportReason}>
                {REPORT_REASONS.map((reason) => (
                  <div key={reason.value} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-white/5">
                    <RadioGroupItem 
                      value={reason.value} 
                      id={reason.value}
                      className="border-white/30 text-[#8B5CF6]"
                    />
                    <Label htmlFor={reason.value} className="text-white/90 cursor-pointer">
                      {reason.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label className="text-white/70">상세 내용 (선택)</Label>
              <Textarea
                value={reportDetails}
                onChange={(e) => setReportDetails(e.target.value)}
                placeholder="추가 정보를 입력하세요..."
                rows={3}
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none"
              />
            </div>

            <GradientButton 
              fullWidth 
              variant="accent"
              onClick={handleReport}
              loading={loading}
            >
              <Flag className="w-4 h-4" />
              신고하기
            </GradientButton>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}