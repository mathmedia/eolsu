import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Folder, PlaySquare, Download, User, Sparkles } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useLanguage } from '@/components/i18n/LanguageContext';

export default function BottomNav() {
  const { t } = useLanguage();
  
  const navItems = [
    { icon: Sparkles, label: String(t('home')), page: 'Home' },
    { icon: Folder, label: String(t('folders')), page: 'Folders' },
    { icon: PlaySquare, label: String(t('playlistPage')), page: 'Playlist' },
    { icon: Download, label: String(t('offlinePage')), page: 'Offline' },
    { icon: User, label: String(t('profile')), page: 'Profile' }
  ];
  const location = useLocation();
  
  const isActive = (page) => {
    return location.pathname.includes(page);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50">
      {/* Glass background */}
      <div className="absolute inset-0 bg-[#0D1117]/80 backdrop-blur-xl border-t border-white/10" />
      
      <div className="relative flex items-center justify-around px-4 py-2 pb-safe max-w-lg mx-auto">
        {navItems.map(({ icon: Icon, label, page }) => {
          const active = isActive(page);
          return (
            <Link
              key={page}
              to={createPageUrl(page)}
              className={cn(
                "flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all duration-300",
                active ? "text-white" : "text-white/40 hover:text-white/70"
              )}
            >
              <div className={cn(
                "relative p-2 rounded-xl transition-all duration-300",
                active && "bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] shadow-lg shadow-[#4158F1]/30"
              )}>
                <Icon className="w-5 h-5" />
                {active && (
                  <div className="absolute inset-0 rounded-xl bg-white/20 animate-pulse" />
                )}
              </div>
              <span className={cn(
                "text-[10px] font-medium transition-all",
                active && "text-[#FFD60A]"
              )}>
                {label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}