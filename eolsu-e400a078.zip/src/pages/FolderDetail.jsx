import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  ArrowLeft, Plus, MoreVertical, Edit2, Trash2, Share2, 
  FolderPlus, Video, Folder as FolderIcon, Globe, Lock, 
  Loader2, Check, Copy, ArrowUp 
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from 'framer-motion';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import GlassCard from '@/components/ui/GlassCard';
import GradientButton from '@/components/ui/GradientButton';
import FolderCard from '@/components/folders/FolderCard';
import CreateFolderModal from '@/components/folders/CreateFolderModal';
import VideoCard from '@/components/videos/VideoCard';
import AddVideoModal from '@/components/videos/AddVideoModal';
import ShareFolderModal from '@/components/folders/ShareFolderModal';
import FolderBreadcrumbs from '@/components/folders/FolderBreadcrumbs';
import AIAssistantModal from '@/components/videos/AIAssistantModal';
import { useVideoPlayer } from '@/components/video/GlobalVideoPlayer';
import { useLanguage } from '@/components/i18n/LanguageContext';

export default function FolderDetail() {
  const { t } = useLanguage();
  const urlParams = new URLSearchParams(window.location.search);
  const folderId = urlParams.get('id');
  
  const { playVideo } = useVideoPlayer();
  const [user, setUser] = useState(null);
  const [showCreateFolderModal, setShowCreateFolderModal] = useState(false);
  const [showAddVideoModal, setShowAddVideoModal] = useState(false);
  const [editingVideo, setEditingVideo] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [copied, setCopied] = useState(false);
  const [editingFolder, setEditingFolder] = useState(false);
  const [folderName, setFolderName] = useState('');
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareLoading, setShareLoading] = useState(false);
  const [showAIModal, setShowAIModal] = useState(false);
  const [aiTargetVideo, setAiTargetVideo] = useState(null);
  
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  // Fetch current folder
  const { data: folder, isLoading: folderLoading } = useQuery({
    queryKey: ['folder', folderId],
    queryFn: async () => {
      const folders = await base44.entities.Folder.filter({ id: folderId });
      return folders[0];
    },
    enabled: !!folderId,
  });

  // Fetch subfolders
  const { data: subfolders = [] } = useQuery({
    queryKey: ['subfolders', folderId],
    queryFn: () => base44.entities.Folder.filter({ parent_id: folderId }),
    enabled: !!folderId,
  });

  // Fetch videos in this folder
  const { data: videos = [] } = useQuery({
    queryKey: ['folderVideos', folderId],
    queryFn: () => base44.entities.Video.filter({ folder_id: folderId }),
    enabled: !!folderId,
  });

  // Fetch all videos for counts
  const { data: allVideos = [] } = useQuery({
    queryKey: ['videos', user?.email],
    queryFn: () => base44.entities.Video.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  // Fetch all folders for subfolder counts and breadcrumbs
  const { data: allFolders = [] } = useQuery({
    queryKey: ['allFolders', user?.email],
    queryFn: () => base44.entities.Folder.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  // Build breadcrumb path
  const getBreadcrumbPath = () => {
    if (!folder || !allFolders.length) return [];
    const path = [];
    let currentFolder = folder;
    
    while (currentFolder) {
      path.unshift(currentFolder);
      if (currentFolder.parent_id) {
        currentFolder = allFolders.find(f => f.id === currentFolder.parent_id);
      } else {
        break;
      }
    }
    
    return path;
  };

  const breadcrumbPath = getBreadcrumbPath();

  // Fetch shared users for this folder
  const { data: sharedUsers = [] } = useQuery({
    queryKey: ['sharedUsers', folderId],
    queryFn: () => base44.entities.SharedFolder.filter({ folder_id: folderId }),
    enabled: !!folderId,
  });

  // Fetch folder views for statistics
  const { data: folderViews = [] } = useQuery({
    queryKey: ['folderViews', folderId],
    queryFn: () => base44.entities.FolderView.filter({ folder_id: folderId }),
    enabled: !!folderId && folder?.owner_email === user?.email,
  });

  const totalViews = folderViews.reduce((sum, view) => sum + view.view_count, 0);
  const uniqueViewers = folderViews.length;

  useEffect(() => {
    if (folder) {
      setFolderName(folder.name);
    }
  }, [folder]);

  const createFolderMutation = useMutation({
    mutationFn: (data) => base44.entities.Folder.create({
      ...data,
      owner_email: user?.email,
      share_code: Math.random().toString(36).substring(2, 10)
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subfolders'] });
      queryClient.invalidateQueries({ queryKey: ['allFolders'] });
      setShowCreateFolderModal(false);
    }
  });

  const updateFolderMutation = useMutation({
    mutationFn: (data) => base44.entities.Folder.update(folderId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['folder'] });
      setEditingFolder(false);
    }
  });

  const deleteFolderMutation = useMutation({
    mutationFn: (id) => base44.entities.Folder.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subfolders'] });
      queryClient.invalidateQueries({ queryKey: ['allFolders'] });
      toast.success(t('folderDeleted'));
      // Navigate to Folders page after deletion
      setTimeout(() => {
        window.location.href = createPageUrl('Folders');
      }, 500);
    }
  });

  const createVideoMutation = useMutation({
    mutationFn: (data) => base44.entities.Video.create({
      ...data,
      owner_email: user?.email
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['folderVideos'] });
      queryClient.invalidateQueries({ queryKey: ['videos'] });
      setShowAddVideoModal(false);
    }
  });

  const updateVideoMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Video.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['folderVideos'] });
      setShowAddVideoModal(false);
      setEditingVideo(null);
    }
  });

  const deleteVideoMutation = useMutation({
    mutationFn: (id) => base44.entities.Video.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['folderVideos'] });
      queryClient.invalidateQueries({ queryKey: ['videos'] });
    }
  });

  const handleDelete = () => {
    if (deleteTarget?.type === 'folder') {
      deleteFolderMutation.mutate(deleteTarget.id);
    } else if (deleteTarget?.type === 'video') {
      deleteVideoMutation.mutate(deleteTarget.id);
    }
    setShowDeleteDialog(false);
    setDeleteTarget(null);
  };

  const copyShareLink = () => {
    const link = `${window.location.origin}${createPageUrl(`SharedFolder?code=${folder.share_code}`)}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    toast.success(t('linkCopied'));
    setTimeout(() => setCopied(false), 2000);
  };

  const togglePublic = () => {
    updateFolderMutation.mutate({ is_public: !folder.is_public });
  };

  const handleShareByEmail = async (email) => {
    if (email === user?.email) {
      toast.error(t('loading').includes('...') ? 'Cannot share with yourself' : '자신에게는 공유할 수 없어요');
      return;
    }
    const alreadyShared = sharedUsers.some(s => s.shared_with_email === email);
    if (alreadyShared) {
      toast.error(t('loading').includes('...') ? 'Already shared with this user' : '이미 공유된 사용자예요');
      return;
    }
    setShareLoading(true);
    try {
      await base44.entities.SharedFolder.create({
        folder_id: folderId,
        owner_email: user?.email,
        shared_with_email: email,
        permission: 'read'
      });
      queryClient.invalidateQueries({ queryKey: ['sharedUsers'] });
      toast.success(t('loading').includes('...') ? `Shared with ${email}` : `${email}에게 공유했어요`);
    } catch (error) {
      toast.error(t('loading').includes('...') ? 'Failed to share' : '공유에 실패했어요');
    } finally {
      setShareLoading(false);
    }
  };

  const handleRemoveShare = async (shareId) => {
    await base44.entities.SharedFolder.delete(shareId);
    queryClient.invalidateQueries({ queryKey: ['sharedUsers'] });
    toast.success(t('loading').includes('...') ? 'Share removed' : '공유가 해제되었어요');
  };

  const handleAIAssist = (video) => {
    setAiTargetVideo(video);
    setShowAIModal(true);
  };

  const handleApplyAISuggestions = async (suggestions) => {
    if (aiTargetVideo) {
      await updateVideoMutation.mutateAsync({
        id: aiTargetVideo.id,
        data: { ...aiTargetVideo, ...suggestions }
      });
    }
  };

  const getVideoCount = (fId) => allVideos.filter(v => v.folder_id === fId).length;
  const getSubfolderCount = (fId) => allFolders.filter(f => f.parent_id === fId).length;

  const handleBreadcrumbNavigate = (folderId) => {
    if (folderId) {
      window.location.href = createPageUrl(`FolderDetail?id=${folderId}`);
    } else {
      window.location.href = createPageUrl('Folders');
    }
  };

  const handleGoUp = () => {
    if (folder.parent_id) {
      window.location.href = createPageUrl(`FolderDetail?id=${folder.parent_id}`);
    } else {
      window.location.href = createPageUrl('Folders');
    }
  };

  if (!user || folderLoading) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  if (!folder) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <GlassCard className="p-8 text-center">
          <p className="text-white/70">{t('loading').includes('...') ? 'Folder not found' : '폴더를 찾을 수 없어요'}</p>
          <Link to={createPageUrl('Folders')} className="text-[#8B5CF6] mt-2 inline-block">
            {t('loading').includes('...') ? 'Back to folders' : '폴더 목록으로 돌아가기'}
          </Link>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1117] pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0D1117]/80 backdrop-blur-xl border-b border-white/5">
        <div className="px-4 py-4">
          {/* Breadcrumbs */}
          <div className="mb-3">
            <FolderBreadcrumbs 
              path={breadcrumbPath}
              onNavigate={handleBreadcrumbNavigate}
            />
          </div>

          <div className="flex items-center gap-3 mb-3">
            <button
              onClick={handleGoUp}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
              title={t('goToParent')}
            >
              <ArrowUp className="w-5 h-5 text-white" />
            </button>
            
            <div className="flex-1 min-w-0">
              {editingFolder ? (
                <div className="flex items-center gap-2">
                  <Input
                    value={folderName}
                    onChange={(e) => setFolderName(e.target.value)}
                    className="bg-white/5 border-white/10 text-white h-8"
                    autoFocus
                  />
                  <Button
                    size="sm"
                    onClick={() => updateFolderMutation.mutate({ name: folderName })}
                    className="bg-[#4158F1] hover:bg-[#4158F1]/80"
                  >
                    <Check className="w-4 h-4" />
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <div 
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${folder.color}30` }}
                  >
                    <FolderIcon className="w-4 h-4" style={{ color: folder.color }} />
                  </div>
                  <h1 className="text-white font-semibold text-lg truncate">{folder.name}</h1>
                  {folder.is_public ? (
                    <Globe className="w-4 h-4 text-[#8B5CF6] flex-shrink-0" />
                  ) : (
                    <Lock className="w-4 h-4 text-white/30 flex-shrink-0" />
                  )}
                </div>
              )}
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                  <MoreVertical className="w-5 h-5 text-white" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-[#1C2128] border-white/10 text-white">
                <DropdownMenuItem onClick={() => setEditingFolder(true)} className="hover:bg-white/10">
                  <Edit2 className="w-4 h-4 mr-2" /> {t('editName')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={togglePublic} className="hover:bg-white/10">
                  {folder.is_public ? (
                    <><Lock className="w-4 h-4 mr-2" /> {t('makePrivate')}</>
                  ) : (
                    <><Globe className="w-4 h-4 mr-2" /> {t('makePublic')}</>
                  )}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setShowShareModal(true)} className="hover:bg-white/10">
                  <Share2 className="w-4 h-4 mr-2" /> {t('shareSettings')}
                </DropdownMenuItem>
                {folder.is_public && (
                  <DropdownMenuItem onClick={copyShareLink} className="hover:bg-white/10">
                    {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                    {t('copyShareLink')}
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator className="bg-white/10" />
                <DropdownMenuItem 
                  onClick={() => {
                    setDeleteTarget({ type: 'folder', id: folder.id, name: folder.name });
                    setShowDeleteDialog(true);
                  }} 
                  className="hover:bg-white/10 text-red-400"
                >
                  <Trash2 className="w-4 h-4 mr-2" /> {t('delete')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Statistics */}
          {folder.is_public && folderViews.length > 0 && (
            <div className="mb-3 flex gap-2">
              <div className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10">
                <p className="text-white/50 text-xs">
                  👥 {uniqueViewers} {t('viewers')} · 👀 {totalViews} {t('views')}
                </p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2">
            <GradientButton 
              size="sm" 
              onClick={() => setShowAddVideoModal(true)}
              icon={Video}
              className="flex-1"
            >
              {t('addVideoMusic')}
            </GradientButton>
            <GradientButton 
              size="sm" 
              variant="ghost"
              onClick={() => setShowCreateFolderModal(true)}
              icon={FolderPlus}
            >
              {t('subfolder')}
            </GradientButton>
          </div>

          {/* Music Video Info Banner */}
          <div className="mt-3 p-3 rounded-lg bg-gradient-to-r from-[#FFD60A]/10 to-[#FFA500]/10 border border-[#FFD60A]/20">
            <p className="text-[#FFD60A] text-xs leading-relaxed">
              {t('mvInfoBanner')}
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6 space-y-6">
        {/* Viewer Stats */}
        {folder.is_public && folderViews.length > 0 && (
          <div>
            <h2 className="text-white/50 text-sm font-medium mb-3 flex items-center gap-2">
              👥 {t('recentViewers')}
            </h2>
            <GlassCard className="p-4">
              <div className="space-y-2">
                {folderViews.slice(0, 5).map((view, idx) => (
                  <div key={idx} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#4158F1] to-[#8B5CF6] flex items-center justify-center text-white text-xs font-medium">
                        {view.viewer_name?.[0]?.toUpperCase() || '?'}
                      </div>
                      <div>
                        <p className="text-white text-sm">{view.viewer_name}</p>
                        <p className="text-white/40 text-xs">{view.viewer_email}</p>
                      </div>
                    </div>
                    <span className="text-white/50 text-xs">{view.view_count}{t('views')}</span>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>
        )}
        {/* Subfolders */}
        {subfolders.length > 0 && (
          <div>
            <h2 className="text-white/50 text-sm font-medium mb-3 flex items-center gap-2">
              <FolderIcon className="w-4 h-4" />
              {t('subfolders')} ({subfolders.length})
            </h2>
            <div className="space-y-2">
              <AnimatePresence>
                {subfolders.map((subfolder, index) => (
                  <motion.div
                    key={subfolder.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <FolderCard 
                      folder={subfolder}
                      videoCount={getVideoCount(subfolder.id)}
                      subfolderCount={getSubfolderCount(subfolder.id)}
                    />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}

        {/* Videos */}
        <div>
          <h2 className="text-white/50 text-sm font-medium mb-3 flex items-center gap-2">
            <Video className="w-4 h-4" />
            {t('videoCount')} ({videos.length})
          </h2>
          
          {videos.length === 0 ? (
            <GlassCard className="p-8 text-center">
              <Video className="w-12 h-12 text-white/20 mx-auto mb-3" />
              <p className="text-white/50 text-sm mb-4">{t('noVideosInFolder')}</p>
              <GradientButton 
                size="sm"
                onClick={() => setShowAddVideoModal(true)}
                icon={Plus}
              >
                {t('addFirstVideo')}
              </GradientButton>
            </GlassCard>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <AnimatePresence>
                {videos.map((video, index) => (
                  <motion.div
                    key={video.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <VideoCard 
                      video={video}
                      onPlay={(v) => playVideo(v, videos)}
                      onEdit={(v) => {
                        setEditingVideo(v);
                        setShowAddVideoModal(true);
                      }}
                      onDelete={(v) => {
                        setDeleteTarget({ type: 'video', id: v.id, name: v.title });
                        setShowDeleteDialog(true);
                      }}
                      onAIAssist={handleAIAssist}
                    />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <CreateFolderModal
        open={showCreateFolderModal}
        onClose={() => setShowCreateFolderModal(false)}
        onSubmit={(data) => createFolderMutation.mutate(data)}
        parentId={folderId}
        loading={createFolderMutation.isPending}
      />

      <AddVideoModal
        open={showAddVideoModal}
        onClose={() => {
          setShowAddVideoModal(false);
          setEditingVideo(null);
        }}
        onSubmit={(data) => {
          if (editingVideo) {
            updateVideoMutation.mutate({ id: editingVideo.id, data });
          } else {
            createVideoMutation.mutate(data);
          }
        }}
        folderId={folderId}
        editingVideo={editingVideo}
        loading={createVideoMutation.isPending || updateVideoMutation.isPending}
      />

      <ShareFolderModal
        open={showShareModal}
        onClose={() => setShowShareModal(false)}
        folder={folder}
        sharedUsers={sharedUsers}
        onShareByEmail={handleShareByEmail}
        onRemoveShare={handleRemoveShare}
        loading={shareLoading}
      />

      <AIAssistantModal
        open={showAIModal}
        onClose={() => {
          setShowAIModal(false);
          setAiTargetVideo(null);
        }}
        video={aiTargetVideo}
        onApplySuggestions={handleApplyAISuggestions}
      />

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="bg-[#161B22] border-white/10 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>{t('confirmDelete')}</AlertDialogTitle>
            <AlertDialogDescription className="text-white/50">
              "{deleteTarget?.name}" {t('deleteWarning')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 text-white hover:bg-white/10">
              {t('cancel')}
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-red-500 hover:bg-red-600"
            >
              {t('delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      </div>
      );
      }