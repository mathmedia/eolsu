import Layout from "./Layout.jsx";

import Folders from "./Folders";

import FolderDetail from "./FolderDetail";

import Playlist from "./Playlist";

import SharedFolders from "./SharedFolders";

import SharedFolder from "./SharedFolder";

import Profile from "./Profile";

import Home from "./Home";

import SharedPlaylist from "./SharedPlaylist";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Folders: Folders,
    
    FolderDetail: FolderDetail,
    
    Playlist: Playlist,
    
    SharedFolders: SharedFolders,
    
    SharedFolder: SharedFolder,
    
    Profile: Profile,
    
    Home: Home,
    
    SharedPlaylist: SharedPlaylist,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Folders />} />
                
                
                <Route path="/Folders" element={<Folders />} />
                
                <Route path="/FolderDetail" element={<FolderDetail />} />
                
                <Route path="/Playlist" element={<Playlist />} />
                
                <Route path="/SharedFolders" element={<SharedFolders />} />
                
                <Route path="/SharedFolder" element={<SharedFolder />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/SharedPlaylist" element={<SharedPlaylist />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}