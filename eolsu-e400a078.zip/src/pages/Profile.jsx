import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  User, LogOut, Folder, Video, Ban, Settings,
  ChevronRight, Loader2, Shield, Trash2, Camera, Edit2, Check, X, Globe, Image, Upload, Eye, EyeOff
} from 'lucide-react';
import { useLanguage } from '@/components/i18n/LanguageContext';
import LanguageSelector from '@/components/profile/LanguageSelector';
import { motion } from 'framer-motion';
import EolsuLogo from '@/components/ui/EolsuLogo';
import GlassCard from '@/components/ui/GlassCard';
import GradientButton from '@/components/ui/GradientButton';
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from 'sonner';
import { cn } from "@/lib/utils";

export default function Profile() {
  const { t } = useLanguage();
  const [user, setUser] = useState(null);
  const [showUnblockDialog, setShowUnblockDialog] = useState(false);
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);
  const [unblockTarget, setUnblockTarget] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [newName, setNewName] = useState('');
  const [uploadingMemory, setUploadingMemory] = useState(false);
  const [timeCapsuleMode, setTimeCapsuleMode] = useState('minimal');
  const [photoOpacity, setPhotoOpacity] = useState(0.5);
  const [photoPosition, setPhotoPosition] = useState('full');
  const [musicVideoMode, setMusicVideoMode] = useState(true);
  const [photoSlideInterval, setPhotoSlideInterval] = useState(5);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  // Fetch user stats
  const { data: folders = [] } = useQuery({
    queryKey: ['userFolders', user?.email],
    queryFn: () => base44.entities.Folder.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const { data: videos = [] } = useQuery({
    queryKey: ['userVideos', user?.email],
    queryFn: () => base44.entities.Video.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const { data: blockedUsers = [] } = useQuery({
    queryKey: ['blockedUsers', user?.email],
    queryFn: () => base44.entities.BlockedUser.filter({ blocker_email: user?.email }),
    enabled: !!user?.email,
  });

  const { data: memoryPhotos = [] } = useQuery({
    queryKey: ['memoryPhotos', user?.email],
    queryFn: () => base44.entities.MemoryPhoto.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const unblockMutation = useMutation({
    mutationFn: (id) => base44.entities.BlockedUser.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['blockedUsers'] });
      toast.success('차단을 해제했어요');
      setShowUnblockDialog(false);
    }
  });

  const handleLogout = () => {
    base44.auth.logout();
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('이미지 파일만 업로드 가능해요');
      return;
    }

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      await base44.auth.updateMe({ profile_image: file_url });
      const updatedUser = await base44.auth.me();
      setUser(updatedUser);
      toast.success('프로필 사진이 업데이트되었어요');
    } catch (error) {
      toast.error('업로드에 실패했어요');
    } finally {
      setUploading(false);
    }
  };

  const handleStartEditName = () => {
    setNewName(user.nickname || user.full_name || '');
    setEditingName(true);
  };

  const handleSaveName = async () => {
    if (!newName.trim()) {
      toast.error('닉네임을 입력해주세요');
      return;
    }

    try {
      await base44.auth.updateMe({ nickname: newName.trim() });
      const updatedUser = await base44.auth.me();
      setUser(updatedUser);
      setEditingName(false);
      toast.success('닉네임이 변경되었어요');
    } catch (error) {
      toast.error('변경에 실패했어요');
    }
  };

  const handleCancelEdit = () => {
    setEditingName(false);
    setNewName('');
  };

  const handleMemoryUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('이미지 파일만 업로드 가능해요');
      return;
    }

    setUploadingMemory(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      // AI analyze mood
      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt: `이 이미지의 전반적인 분위기/감정을 하나의 단어로 표현해주세요. 다음 중 하나를 선택: happy, sad, energetic, calm, nostalgic, romantic, neutral`,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            mood: { type: "string" }
          }
        }
      });

      await base44.entities.MemoryPhoto.create({
        owner_email: user.email,
        photo_url: file_url,
        mood: aiResponse?.mood || 'neutral'
      });

      queryClient.invalidateQueries({ queryKey: ['memoryPhotos'] });
      toast.success('추억 사진이 추가되었어요');
    } catch (error) {
      toast.error('업로드에 실패했어요');
    } finally {
      setUploadingMemory(false);
    }
  };

  const deleteMemory = async (id) => {
    try {
      await base44.entities.MemoryPhoto.delete(id);
      queryClient.invalidateQueries({ queryKey: ['memoryPhotos'] });
      toast.success('사진이 삭제되었어요');
    } catch (error) {
      toast.error('삭제에 실패했어요');
    }
  };

  const toggleTimeCapsuleMode = async () => {
    const newMode = timeCapsuleMode === 'minimal' ? 'immersive' : 'minimal';
    setTimeCapsuleMode(newMode);
    await base44.auth.updateMe({ timecapsule_mode: newMode });
    toast.success(newMode === 'minimal' ? '최소 방해 모드로 변경됐어요' : '최대 몰입 모드로 변경됐어요');
  };

  useEffect(() => {
    if (user?.timecapsule_mode) {
      setTimeCapsuleMode(user.timecapsule_mode);
    }
    if (user?.photo_opacity !== undefined) {
      setPhotoOpacity(user.photo_opacity);
    }
    if (user?.photo_position) {
      setPhotoPosition(user.photo_position);
    }
    if (user?.music_video_mode !== undefined) {
      setMusicVideoMode(user.music_video_mode);
    }
    if (user?.photo_slide_interval !== undefined) {
      setPhotoSlideInterval(user.photo_slide_interval);
    }
  }, [user]);

  const updatePhotoOpacity = async (value) => {
    setPhotoOpacity(value);
    await base44.auth.updateMe({ photo_opacity: value });
  };

  const updatePhotoPosition = async (position) => {
    setPhotoPosition(position);
    await base44.auth.updateMe({ photo_position: position });
    toast.success('위치가 변경됐어요');
  };

  const updatePhotoSlideInterval = async (seconds) => {
    setPhotoSlideInterval(seconds);
    await base44.auth.updateMe({ photo_slide_interval: seconds });
    toast.success(`${seconds}초로 변경됐어요`);
  };

  const toggleMusicVideoMode = async () => {
    const newMode = !musicVideoMode;
    setMusicVideoMode(newMode);
    await base44.auth.updateMe({ music_video_mode: newMode });
    toast.success(newMode ? '뮤직 비디오 모드 켜짐' : '뮤직 비디오 모드 꺼짐');
  };

  const stats = [
    { icon: Folder, label: t('totalFolders'), value: folders.length, color: '#4158F1' },
    { icon: Video, label: t('totalVideos'), value: videos.length, color: '#8B5CF6' },
    { icon: Ban, label: t('blockedUsers'), value: blockedUsers.length, color: '#EF4444' },
  ];

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1117] pb-24">
      {/* Header */}
      <div className="bg-gradient-to-b from-[#4158F1]/20 to-transparent pt-8 pb-12 px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          {/* Avatar */}
          <div className="relative w-24 h-24 mx-auto mb-4">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#4158F1] to-[#8B5CF6] flex items-center justify-center shadow-lg shadow-[#4158F1]/30 overflow-hidden">
              {user.profile_image ? (
                <img 
                  src={user.profile_image} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <User className="w-12 h-12 text-white" />
              )}
            </div>
            <label 
              htmlFor="profile-upload"
              className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-[#4158F1] flex items-center justify-center cursor-pointer hover:bg-[#4158F1]/80 transition-colors shadow-lg"
            >
              {uploading ? (
                <Loader2 className="w-4 h-4 text-white animate-spin" />
              ) : (
                <Camera className="w-4 h-4 text-white" />
              )}
            </label>
            <input
              id="profile-upload"
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              disabled={uploading}
              className="hidden"
            />
          </div>
          
          {editingName ? (
            <div className="flex items-center justify-center gap-2 mb-1">
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSaveName();
                  if (e.key === 'Escape') handleCancelEdit();
                }}
                className="bg-white/10 border border-white/20 rounded-lg px-3 py-1.5 text-white text-lg text-center focus:outline-none focus:border-[#4158F1]"
                autoFocus
                maxLength={20}
              />
              <button
                onClick={handleSaveName}
                className="p-1.5 rounded-lg bg-[#4158F1] hover:bg-[#4158F1]/80 transition-colors"
              >
                <Check className="w-4 h-4 text-white" />
              </button>
              <button
                onClick={handleCancelEdit}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-2 mb-1">
              <h1 className="text-white text-xl font-semibold">
                {user.nickname || user.full_name || '사용자'}
              </h1>
              <button
                onClick={handleStartEditName}
                className="p-1 rounded-lg hover:bg-white/10 transition-colors"
              >
                <Edit2 className="w-4 h-4 text-white/50" />
              </button>
            </div>
          )}
          <p className="text-white/50 text-sm">{user.email}</p>

          {/* Stats */}
          <div className="flex justify-center gap-6 mt-6">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div 
                  className="w-12 h-12 rounded-xl mx-auto mb-2 flex items-center justify-center"
                  style={{ backgroundColor: `${stat.color}20` }}
                >
                  <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
                </div>
                <p className="text-white font-semibold">{stat.value}</p>
                <p className="text-white/50 text-xs">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Content */}
      <div className="px-4 -mt-4 space-y-4">
        {/* Time Capsule Memories */}
        <GlassCard className="overflow-hidden">
          <div className="p-4 border-b border-white/10">
            <h2 className="text-white font-medium flex items-center gap-2 mb-3">
              <Image className="w-4 h-4 text-[#FFD60A]" />
              추억 앨범 (타임캡슐)
            </h2>
            <div className="flex items-center justify-between mb-3">
              <span className="text-white/70 text-sm">재생 모드</span>
              <button
                onClick={toggleTimeCapsuleMode}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                {timeCapsuleMode === 'minimal' ? (
                  <>
                    <Eye className="w-4 h-4 text-[#4158F1]" />
                    <span className="text-white/70 text-sm">최소 방해</span>
                  </>
                ) : (
                  <>
                    <EyeOff className="w-4 h-4 text-[#8B5CF6]" />
                    <span className="text-white/70 text-sm">최대 몰입</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-white/50 text-xs">
              {timeCapsuleMode === 'minimal' 
                ? '파노라마 배경으로 슬라이드 재생' 
                : '큰 오버레이(50% 투명도)로 몰입감 증가'}
            </p>
            
            {/* Opacity Control */}
            <div className="mt-4 pt-4 border-t border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/70 text-sm">사진 선명도</span>
                <span className="text-white text-sm font-medium">{Math.round(photoOpacity * 100)}%</span>
              </div>
              <style>{`
                .opacity-slider-container {
                  position: relative;
                  height: 20px;
                  display: flex;
                  align-items: center;
                }
                
                input[type="range"].opacity-slider {
                  -webkit-appearance: none;
                  appearance: none;
                  width: 100%;
                  height: 20px;
                  background: transparent;
                  outline: none;
                  margin: 0;
                  padding: 0;
                }
                
                input[type="range"].opacity-slider::-webkit-slider-thumb {
                  -webkit-appearance: none;
                  appearance: none;
                  width: 20px;
                  height: 20px;
                  border-radius: 50%;
                  background: white;
                  cursor: pointer;
                  box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }
                
                input[type="range"].opacity-slider::-moz-range-thumb {
                  width: 20px;
                  height: 20px;
                  border-radius: 50%;
                  background: white;
                  cursor: pointer;
                  border: none;
                  box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }
                
                input[type="range"].opacity-slider::-webkit-slider-runnable-track {
                  width: 100%;
                  height: 20px;
                  background: transparent;
                }
                
                input[type="range"].opacity-slider::-moz-range-track {
                  width: 100%;
                  height: 20px;
                  background: transparent;
                }
              `}</style>
              <div className="opacity-slider-container">
                <div 
                  className="absolute left-0 right-0 top-1/2 -translate-y-1/2 flex items-center pointer-events-none"
                  style={{ paddingLeft: '10px', paddingRight: '10px' }}
                >
                  <div className="w-full h-1.5 rounded-full" style={{
                    background: `linear-gradient(to right, #4158F1 0%, #4158F1 ${((photoOpacity * 100 - 10) / 90) * 100}%, rgba(255,255,255,0.1) ${((photoOpacity * 100 - 10) / 90) * 100}%, rgba(255,255,255,0.1) 100%)`
                  }} />
                </div>
                <input
                  type="range"
                  min="10"
                  max="100"
                  value={photoOpacity * 100}
                  onChange={(e) => updatePhotoOpacity(e.target.value / 100)}
                  className="opacity-slider cursor-pointer relative z-10"
                />
              </div>
              <p className="text-white/40 text-xs mt-1">숫자가 클수록 사진이 선명해요</p>
            </div>

            {/* Position Control */}
            <div className="mt-4 pt-4 border-t border-white/10">
              <span className="text-white/70 text-sm block mb-3">사진 위치</span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => updatePhotoPosition('top')}
                  className={cn(
                    "px-3 py-2 rounded-lg text-xs transition-all",
                    photoPosition === 'top'
                      ? "bg-[#4158F1] text-white"
                      : "bg-white/5 text-white/50 hover:bg-white/10"
                  )}
                >
                  상단
                </button>
                <button
                  onClick={() => updatePhotoPosition('full')}
                  className={cn(
                    "px-3 py-2 rounded-lg text-xs transition-all",
                    photoPosition === 'full'
                      ? "bg-[#4158F1] text-white"
                      : "bg-white/5 text-white/50 hover:bg-white/10"
                  )}
                >
                  전체
                </button>
                <button
                  onClick={() => updatePhotoPosition('bottom')}
                  className={cn(
                    "px-3 py-2 rounded-lg text-xs transition-all",
                    photoPosition === 'bottom'
                      ? "bg-[#4158F1] text-white"
                      : "bg-white/5 text-white/50 hover:bg-white/10"
                  )}
                >
                  하단
                </button>
              </div>
            </div>

            {/* Slide Interval Control */}
            <div className="mt-4 pt-4 border-t border-white/10">
              <div className="flex items-center justify-between mb-3">
                <span className="text-white/70 text-sm">슬라이드 속도</span>
                <span className="text-white text-sm font-medium">{photoSlideInterval}초</span>
              </div>
              <div className="grid grid-cols-5 gap-2">
                {[2, 3, 4, 5, 6].map(sec => (
                  <button
                    key={sec}
                    onClick={() => updatePhotoSlideInterval(sec)}
                    className={cn(
                      "px-2 py-2 rounded-lg text-xs transition-all",
                      photoSlideInterval === sec
                        ? "bg-[#4158F1] text-white"
                        : "bg-white/5 text-white/50 hover:bg-white/10"
                    )}
                  >
                    {sec}초
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-4 gap-2 mt-2">
                {[7, 8, 9, 10].map(sec => (
                  <button
                    key={sec}
                    onClick={() => updatePhotoSlideInterval(sec)}
                    className={cn(
                      "px-2 py-2 rounded-lg text-xs transition-all",
                      photoSlideInterval === sec
                        ? "bg-[#4158F1] text-white"
                        : "bg-white/5 text-white/50 hover:bg-white/10"
                    )}
                  >
                    {sec}초
                  </button>
                ))}
              </div>
              <p className="text-white/40 text-xs mt-2">사진이 전환되는 시간 간격</p>
            </div>
            </div>

          <div className="p-4">
            <label
              htmlFor="memory-upload"
              className="block w-full p-4 border-2 border-dashed border-white/10 rounded-xl hover:border-[#4158F1]/50 transition-colors cursor-pointer text-center"
            >
              {uploadingMemory ? (
                <Loader2 className="w-8 h-8 text-[#4158F1] mx-auto animate-spin mb-2" />
              ) : (
                <Upload className="w-8 h-8 text-white/30 mx-auto mb-2" />
              )}
              <p className="text-white/70 text-sm">사진 추가하기</p>
              <p className="text-white/40 text-xs mt-1">AI가 자동으로 분위기를 분석해요</p>
            </label>
            <input
              id="memory-upload"
              type="file"
              accept="image/*"
              onChange={handleMemoryUpload}
              disabled={uploadingMemory}
              className="hidden"
            />
          </div>

          {memoryPhotos.length > 0 && (
            <div className="p-4 pt-0">
              <div className="grid grid-cols-3 gap-2">
                {memoryPhotos.map(photo => (
                  <div key={photo.id} className="relative aspect-square rounded-lg overflow-hidden group">
                    <img 
                      src={photo.photo_url} 
                      alt="Memory" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button
                        onClick={() => deleteMemory(photo.id)}
                        className="p-2 rounded-full bg-red-500/80 hover:bg-red-500 transition-colors"
                      >
                        <Trash2 className="w-4 h-4 text-white" />
                      </button>
                    </div>
                    <div className="absolute bottom-1 left-1 px-2 py-0.5 rounded bg-black/70 text-white text-[10px]">
                      {photo.mood}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </GlassCard>
        {/* Blocked Users */}
        <GlassCard className="overflow-hidden">
          <div className="p-4 border-b border-white/10">
            <h2 className="text-white font-medium flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#8B5CF6]" />
              {t('blockedUsersList')}
            </h2>
          </div>
          
          {blockedUsers.length === 0 ? (
            <div className="p-6 text-center">
              <p className="text-white/40 text-sm">{t('noBlockedUsers')}</p>
            </div>
          ) : (
            <div className="divide-y divide-white/5">
              {blockedUsers.map((blocked) => (
                <div 
                  key={blocked.id}
                  className="p-4 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                      <Ban className="w-5 h-5 text-red-400" />
                    </div>
                    <div>
                      <p className="text-white text-sm">{blocked.blocked_email}</p>
                      {blocked.reason && (
                        <p className="text-white/40 text-xs truncate max-w-[150px]">
                          {blocked.reason}
                        </p>
                      )}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setUnblockTarget(blocked);
                      setShowUnblockDialog(true);
                    }}
                    className="text-white/50 hover:text-white hover:bg-white/10"
                  >
                    {t('unblock')}
                  </Button>
                </div>
              ))}
            </div>
          )}
        </GlassCard>

          {/* Settings */}
          <GlassCard className="overflow-hidden">
            <button
              onClick={toggleMusicVideoMode}
            className="w-full p-4 flex items-center justify-between hover:bg-white/5 transition-colors border-b border-white/5"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#FFD60A]/20 flex items-center justify-center">
                <Settings className="w-5 h-5 text-[#FFD60A]" />
              </div>
              <div className="text-left">
                <p className="text-white font-medium">뮤직 비디오 모드</p>
                <p className="text-white/40 text-xs">오디오 재생 시 배경 사진 표시</p>
              </div>
            </div>
            <div className={cn(
              "w-12 h-6 rounded-full transition-colors relative",
              musicVideoMode ? "bg-[#4158F1]" : "bg-white/10"
            )}>
              <div className={cn(
                "absolute top-1 w-4 h-4 rounded-full bg-white transition-transform",
                musicVideoMode ? "translate-x-7" : "translate-x-1"
              )} />
              </div>
              </button>

              {musicVideoMode && (
              <div className="p-4 border-b border-white/5">
              <span className="text-white/70 text-sm block mb-3">사진 표시 방식</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={async () => {
                    await base44.auth.updateMe({ music_video_fit: 'contain' });
                    const updatedUser = await base44.auth.me();
                    setUser(updatedUser);
                    toast.success('원본 비율로 변경됐어요');
                  }}
                  className={cn(
                    "px-3 py-2 rounded-lg text-xs transition-all",
                    user?.music_video_fit !== 'cover'
                      ? "bg-[#4158F1] text-white"
                      : "bg-white/5 text-white/50 hover:bg-white/10"
                  )}
                >
                  원본 비율
                </button>
                <button
                  onClick={async () => {
                    await base44.auth.updateMe({ music_video_fit: 'cover' });
                    const updatedUser = await base44.auth.me();
                    setUser(updatedUser);
                    toast.success('화면 가득 채우기로 변경됐어요');
                  }}
                  className={cn(
                    "px-3 py-2 rounded-lg text-xs transition-all",
                    user?.music_video_fit === 'cover'
                      ? "bg-[#4158F1] text-white"
                      : "bg-white/5 text-white/50 hover:bg-white/10"
                  )}
                >
                  화면 채우기
                </button>
              </div>
              <p className="text-white/40 text-xs mt-2">
                {user?.music_video_fit === 'cover' ? '사진이 화면을 가득 채웁니다' : '사진 전체가 보이도록 표시합니다'}
              </p>
              </div>
              )}

              <button
            onClick={() => setShowLanguageSelector(true)}
            className="w-full p-4 flex items-center justify-between hover:bg-white/5 transition-colors border-b border-white/5"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#4158F1]/20 flex items-center justify-center">
                <Globe className="w-5 h-5 text-[#4158F1]" />
              </div>
              <span className="text-white font-medium">{t('language')}</span>
            </div>
            <ChevronRight className="w-5 h-5 text-white/30" />
          </button>
          
          <button
            onClick={handleLogout}
            className="w-full p-4 flex items-center justify-between hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
                <LogOut className="w-5 h-5 text-red-400" />
              </div>
              <span className="text-red-400 font-medium">{t('logout')}</span>
            </div>
            <ChevronRight className="w-5 h-5 text-white/30" />
          </button>
        </GlassCard>

        {/* App Info */}
        <div className="pt-8 pb-4 text-center">
          <EolsuLogo size="sm" />
          <p className="text-white/30 text-xs mt-4">{t('version')} 1.0.0</p>
        </div>
      </div>

      {/* Language Selector */}
      <LanguageSelector 
        open={showLanguageSelector}
        onClose={() => setShowLanguageSelector(false)}
      />

      {/* Unblock Dialog */}
      <AlertDialog open={showUnblockDialog} onOpenChange={setShowUnblockDialog}>
        <AlertDialogContent className="bg-[#161B22] border-white/10 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>{t('unblock')}</AlertDialogTitle>
            <AlertDialogDescription className="text-white/50">
              {unblockTarget?.blocked_email}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 text-white hover:bg-white/10">
              {t('cancel')}
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => unblockMutation.mutate(unblockTarget?.id)}
              className="bg-[#4158F1] hover:bg-[#4158F1]/80"
            >
              {t('unblock')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}