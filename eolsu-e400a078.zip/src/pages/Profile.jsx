import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  User, LogOut, Folder, Video, Ban, Settings, Crown,
  ChevronRight, Loader2, Shield, Trash2, Camera, Edit2, Check, X, Globe, Image, Upload, Eye, EyeOff, Share2, Download
} from 'lucide-react';
import { useLanguage } from '@/components/i18n/LanguageContext';
import LanguageSelector from '@/components/profile/LanguageSelector';
import UpgradeModal from '@/components/subscription/UpgradeModal';
import SubscriptionBanner from '@/components/subscription/SubscriptionBanner';
import { motion } from 'framer-motion';
import EolsuLogo from '@/components/ui/EolsuLogo';
import GlassCard from '@/components/ui/GlassCard';
import GradientButton from '@/components/ui/GradientButton';
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from 'sonner';
import { cn } from "@/lib/utils";

export default function Profile() {
  const { t, language } = useLanguage();
  const [user, setUser] = useState(null);
  const [showUnblockDialog, setShowUnblockDialog] = useState(false);
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);
  const [unblockTarget, setUnblockTarget] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [newName, setNewName] = useState('');
  const [uploadingMemory, setUploadingMemory] = useState(false);
  const [timeCapsuleMode, setTimeCapsuleMode] = useState('minimal');
  const [photoOpacity, setPhotoOpacity] = useState(0.5);
  const [photoPosition, setPhotoPosition] = useState('full');
  const [musicVideoMode, setMusicVideoMode] = useState(true);
  const [photoSlideInterval, setPhotoSlideInterval] = useState(5);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  // Fetch user stats
  const { data: folders = [] } = useQuery({
    queryKey: ['userFolders', user?.email],
    queryFn: () => base44.entities.Folder.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const { data: videos = [] } = useQuery({
    queryKey: ['userVideos', user?.email],
    queryFn: () => base44.entities.Video.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const { data: blockedUsers = [] } = useQuery({
    queryKey: ['blockedUsers', user?.email],
    queryFn: () => base44.entities.BlockedUser.filter({ blocker_email: user?.email }),
    enabled: !!user?.email,
  });

  const { data: memoryPhotos = [] } = useQuery({
    queryKey: ['memoryPhotos', user?.email],
    queryFn: () => base44.entities.MemoryPhoto.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const unblockMutation = useMutation({
    mutationFn: (id) => base44.entities.BlockedUser.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['blockedUsers'] });
      toast.success(t('unblocked'));
      setShowUnblockDialog(false);
    }
  });

  const handleLogout = () => {
    base44.auth.logout();
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error(t('imageOnly'));
      return;
    }

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      await base44.auth.updateMe({ profile_image: file_url });
      const updatedUser = await base44.auth.me();
      setUser(updatedUser);
      toast.success(t('profileUpdated'));
    } catch (error) {
      toast.error(t('uploadFailed'));
    } finally {
      setUploading(false);
    }
  };

  const handleStartEditName = () => {
    setNewName(user.nickname || user.full_name || '');
    setEditingName(true);
  };

  const handleSaveName = async () => {
    if (!newName.trim()) {
      toast.error(t('enterNickname'));
      return;
    }

    try {
      await base44.auth.updateMe({ nickname: newName.trim() });
      const updatedUser = await base44.auth.me();
      setUser(updatedUser);
      setEditingName(false);
      toast.success(t('nicknameChanged'));
    } catch (error) {
      toast.error(t('changeFailed'));
    }
  };

  const handleCancelEdit = () => {
    setEditingName(false);
    setNewName('');
  };

  const handleMemoryUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (memoryPhotos.length >= 15) {
      toast.error('최대 15장까지 업로드 가능합니다');
      return;
    }

    if (!file.type.startsWith('image/')) {
      toast.error(t('imageOnly'));
      return;
    }

    setUploadingMemory(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      // AI analyze mood
      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt: `이 이미지의 전반적인 분위기/감정을 하나의 단어로 표현해주세요. 다음 중 하나를 선택: happy, sad, energetic, calm, nostalgic, romantic, neutral`,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            mood: { type: "string" }
          }
        }
      });

      await base44.entities.MemoryPhoto.create({
        owner_email: user.email,
        photo_url: file_url,
        mood: aiResponse?.mood || 'neutral'
      });

      queryClient.invalidateQueries({ queryKey: ['memoryPhotos'] });
      toast.success(t('memoryPhotoAdded'));
    } catch (error) {
      toast.error(t('uploadFailed'));
    } finally {
      setUploadingMemory(false);
    }
  };

  const deleteMemory = async (id) => {
    try {
      await base44.entities.MemoryPhoto.delete(id);
      queryClient.invalidateQueries({ queryKey: ['memoryPhotos'] });
      toast.success(t('photoDeleted'));
    } catch (error) {
      toast.error(t('deleteFailed'));
    }
  };

  const toggleTimeCapsuleMode = async () => {
    const newMode = timeCapsuleMode === 'minimal' ? 'immersive' : 'minimal';
    setTimeCapsuleMode(newMode);
    await base44.auth.updateMe({ timecapsule_mode: newMode });
    toast.success(newMode === 'minimal' ? t('minimalModeChanged') : t('immersiveModeChanged'));
  };

  useEffect(() => {
    if (user?.timecapsule_mode) {
      setTimeCapsuleMode(user.timecapsule_mode);
    }
    if (user?.photo_opacity !== undefined) {
      setPhotoOpacity(user.photo_opacity);
    }
    if (user?.photo_position) {
      setPhotoPosition(user.photo_position);
    }
    if (user?.music_video_mode !== undefined) {
      setMusicVideoMode(user.music_video_mode);
    }
    if (user?.photo_slide_interval !== undefined) {
      setPhotoSlideInterval(user.photo_slide_interval);
    }
  }, [user]);

  const updatePhotoOpacity = async (value) => {
    setPhotoOpacity(value);
    await base44.auth.updateMe({ photo_opacity: value });
  };

  const updatePhotoPosition = async (position) => {
    setPhotoPosition(position);
    await base44.auth.updateMe({ photo_position: position });
    toast.success(t('positionChanged'));
  };

  const updatePhotoSlideInterval = async (seconds) => {
    setPhotoSlideInterval(seconds);
    await base44.auth.updateMe({ photo_slide_interval: seconds });
    toast.success(`${seconds}${t('secondsChanged')}`);
  };

  const toggleMusicVideoMode = async () => {
    const newMode = !musicVideoMode;
    setMusicVideoMode(newMode);
    await base44.auth.updateMe({ music_video_mode: newMode });
    toast.success(newMode ? t('musicVideoModeOn') : t('musicVideoModeOff'));
  };

  const stats = [
    { icon: Folder, label: t('totalFolders'), value: folders.length, color: '#4158F1', page: null },
    { icon: Video, label: t('totalVideos'), value: videos.length, color: '#8B5CF6', page: null },
    { icon: Ban, label: t('blockedUsers'), value: blockedUsers.length, color: '#EF4444', page: null },
  ];

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1117] pb-24">
      {/* Header */}
      <div className="bg-gradient-to-b from-[#4158F1]/20 to-transparent pt-8 pb-12 px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          {/* Avatar */}
          <div className="relative w-24 h-24 mx-auto mb-4">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#4158F1] to-[#8B5CF6] flex items-center justify-center shadow-lg shadow-[#4158F1]/30 overflow-hidden">
              {user.profile_image ? (
                <img 
                  src={user.profile_image} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <User className="w-12 h-12 text-white" />
              )}
            </div>
            <label 
              htmlFor="profile-upload"
              className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-[#4158F1] flex items-center justify-center cursor-pointer hover:bg-[#4158F1]/80 transition-colors shadow-lg"
            >
              {uploading ? (
                <Loader2 className="w-4 h-4 text-white animate-spin" />
              ) : (
                <Camera className="w-4 h-4 text-white" />
              )}
            </label>
            <input
              id="profile-upload"
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              disabled={uploading}
              className="hidden"
            />
          </div>
          
          {editingName ? (
            <div className="flex items-center justify-center gap-2 mb-1">
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSaveName();
                  if (e.key === 'Escape') handleCancelEdit();
                }}
                className="bg-white/10 border border-white/20 rounded-lg px-3 py-1.5 text-white text-lg text-center focus:outline-none focus:border-[#4158F1]"
                autoFocus
                maxLength={20}
              />
              <button
                onClick={handleSaveName}
                className="p-1.5 rounded-lg bg-[#4158F1] hover:bg-[#4158F1]/80 transition-colors"
              >
                <Check className="w-4 h-4 text-white" />
              </button>
              <button
                onClick={handleCancelEdit}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-2 mb-1">
              <h1 className="text-white text-xl font-semibold">
                {user.nickname || user.full_name || t('user')}
              </h1>
              <button
                onClick={handleStartEditName}
                className="p-1 rounded-lg hover:bg-white/10 transition-colors"
              >
                <Edit2 className="w-4 h-4 text-white/50" />
              </button>
            </div>
          )}
          <p className="text-white/50 text-sm">{user.email}</p>

          {/* Stats */}
          <div className="flex justify-center gap-6 mt-6">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div 
                  className="w-12 h-12 rounded-xl mx-auto mb-2 flex items-center justify-center"
                  style={{ backgroundColor: `${stat.color}20` }}
                >
                  <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
                </div>
                <p className="text-white font-semibold">{stat.value}</p>
                <p className="text-white/50 text-xs">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Content */}
      <div className="px-4 -mt-4 space-y-4">
        {/* Subscription Banner */}
        <SubscriptionBanner 
          subscription={user?.subscription || 'free'}
          onUpgrade={() => setShowUpgradeModal(true)}
        />

        {/* Subscription Section */}
        <GlassCard className="p-6">
          <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
            <Crown className="w-5 h-5 text-[#FFD60A]" />
            {t('subscriptionPlan')}
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
              <div>
                <p className="text-white font-medium">
                  {user?.subscription === 'pro' ? '✨ Pro' : user?.subscription === 'basic' ? '⚡ Basic' : '🆓 Free'}
                </p>
                <p className="text-white/50 text-sm">{language === 'ko' ? '현재 플랜' : language === 'ja' ? '現在のプラン' : language === 'id' ? 'Paket saat ini' : language === 'es' ? 'Plan actual' : language === 'pt' ? 'Plano atual' : 'Current plan'}</p>
              </div>
              <GradientButton
                size="sm"
                onClick={() => setShowUpgradeModal(true)}
              >
                {user?.subscription === 'pro' 
                  ? (language === 'ko' ? '플랜 관리' : language === 'ja' ? 'プラン管理' : language === 'id' ? 'Kelola paket' : language === 'es' ? 'Gestionar plan' : language === 'pt' ? 'Gerenciar plano' : 'Manage plan')
                  : t('upgrade')}
              </GradientButton>
            </div>
          </div>
        </GlassCard>

        {/* Video Playback Settings */}
        <GlassCard className="overflow-hidden">
          <div className="p-4 border-b border-white/10">
            <h2 className="text-white font-medium flex items-center gap-2 mb-3">
              <Image className="w-4 h-4 text-[#FFD60A]" />
              {t('videoPlaybackSettings')}
            </h2>
            <p className="text-white/40 text-xs mb-4">
              {t('videoPlaybackDesc')}
            </p>
            
            {/* Music Video Mode Toggle */}
            <div className="mb-4 pb-4 border-b border-white/10">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <span className="text-white/70 text-sm font-medium">{t('musicVideoModeTitle')}</span>
                  <p className="text-white/40 text-xs mt-0.5">{t('musicVideoModeDesc')}</p>
                </div>
                <button
                  onClick={toggleMusicVideoMode}
                  className={cn(
                    "w-12 h-6 rounded-full transition-colors relative",
                    musicVideoMode ? "bg-[#4158F1]" : "bg-white/10"
                  )}
                >
                  <div className={cn(
                    "absolute top-1 w-4 h-4 rounded-full bg-white transition-transform",
                    musicVideoMode ? "translate-x-7" : "translate-x-1"
                  )} />
                </button>
              </div>
              
              {musicVideoMode && (
                <div className="mt-3 p-3 rounded-lg bg-white/5">
                  <span className="text-white/70 text-xs block mb-2">{t('photoDisplayStyle')}</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={async () => {
                        await base44.auth.updateMe({ music_video_fit: 'contain' });
                        const updatedUser = await base44.auth.me();
                        setUser(updatedUser);
                        toast.success(t('originalRatio'));
                      }}
                      className={cn(
                        "px-3 py-2 rounded-lg text-xs transition-all",
                        user?.music_video_fit !== 'cover'
                          ? "bg-[#4158F1] text-white"
                          : "bg-white/5 text-white/50 hover:bg-white/10"
                      )}
                    >
                      {t('originalRatio')}
                    </button>
                    <button
                      onClick={async () => {
                        await base44.auth.updateMe({ music_video_fit: 'cover' });
                        const updatedUser = await base44.auth.me();
                        setUser(updatedUser);
                        toast.success(t('fillScreen'));
                      }}
                      className={cn(
                        "px-3 py-2 rounded-lg text-xs transition-all",
                        user?.music_video_fit === 'cover'
                          ? "bg-[#4158F1] text-white"
                          : "bg-white/5 text-white/50 hover:bg-white/10"
                      )}
                    >
                      {t('fillScreen')}
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Time Capsule Section */}
            <h3 className="text-white/70 text-sm font-medium mb-3">{t('timeCapsuleOverlay')}</h3>
            <div className="flex items-center justify-between mb-3">
              <span className="text-white/70 text-sm">{t('playbackMode')}</span>
              <button
                onClick={toggleTimeCapsuleMode}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                {timeCapsuleMode === 'minimal' ? (
                  <>
                    <Eye className="w-4 h-4 text-[#4158F1]" />
                    <span className="text-white/70 text-sm">{t('minimalMode')}</span>
                  </>
                ) : (
                  <>
                    <EyeOff className="w-4 h-4 text-[#8B5CF6]" />
                    <span className="text-white/70 text-sm">{t('immersiveMode')}</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-white/50 text-xs">
              {timeCapsuleMode === 'minimal' 
                ? t('minimalModeDesc')
                : t('immersiveModeDesc')}
            </p>
            
            {/* Opacity Control */}
            <div className="mt-4 pt-4 border-t border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/70 text-sm">{t('photoClarity')}</span>
                <span className="text-white text-sm font-medium">{Math.round(photoOpacity * 100)}%</span>
              </div>
              <style>{`
                .opacity-slider-container {
                  position: relative;
                  height: 20px;
                  display: flex;
                  align-items: center;
                }
                
                input[type="range"].opacity-slider {
                  -webkit-appearance: none;
                  appearance: none;
                  width: 100%;
                  height: 20px;
                  background: transparent;
                  outline: none;
                  margin: 0;
                  padding: 0;
                }
                
                input[type="range"].opacity-slider::-webkit-slider-thumb {
                  -webkit-appearance: none;
                  appearance: none;
                  width: 20px;
                  height: 20px;
                  border-radius: 50%;
                  background: white;
                  cursor: pointer;
                  box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }
                
                input[type="range"].opacity-slider::-moz-range-thumb {
                  width: 20px;
                  height: 20px;
                  border-radius: 50%;
                  background: white;
                  cursor: pointer;
                  border: none;
                  box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }
                
                input[type="range"].opacity-slider::-webkit-slider-runnable-track {
                  width: 100%;
                  height: 20px;
                  background: transparent;
                }
                
                input[type="range"].opacity-slider::-moz-range-track {
                  width: 100%;
                  height: 20px;
                  background: transparent;
                }
              `}</style>
              <div className="opacity-slider-container">
                <div 
                  className="absolute left-0 right-0 top-1/2 -translate-y-1/2 flex items-center pointer-events-none"
                  style={{ paddingLeft: '10px', paddingRight: '10px' }}
                >
                  <div className="w-full h-1.5 rounded-full" style={{
                    background: `linear-gradient(to right, #4158F1 0%, #4158F1 ${((photoOpacity * 100 - 10) / 90) * 100}%, rgba(255,255,255,0.1) ${((photoOpacity * 100 - 10) / 90) * 100}%, rgba(255,255,255,0.1) 100%)`
                  }} />
                </div>
                <input
                  type="range"
                  min="10"
                  max="100"
                  value={photoOpacity * 100}
                  onChange={(e) => updatePhotoOpacity(e.target.value / 100)}
                  className="opacity-slider cursor-pointer relative z-10"
                />
              </div>
              <p className="text-white/40 text-xs mt-1">{t('photoClarityDesc')}</p>
            </div>

            {/* Position Control */}
            <div className="mt-4 pt-4 border-t border-white/10">
              <span className="text-white/70 text-sm block mb-3">{t('photoPosition')}</span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => updatePhotoPosition('top')}
                  className={cn(
                    "px-3 py-2 rounded-lg text-xs transition-all",
                    photoPosition === 'top'
                      ? "bg-[#4158F1] text-white"
                      : "bg-white/5 text-white/50 hover:bg-white/10"
                  )}
                >
                  {t('top')}
                </button>
                <button
                  onClick={() => updatePhotoPosition('full')}
                  className={cn(
                    "px-3 py-2 rounded-lg text-xs transition-all",
                    photoPosition === 'full'
                      ? "bg-[#4158F1] text-white"
                      : "bg-white/5 text-white/50 hover:bg-white/10"
                  )}
                >
                  {t('fullScreen')}
                </button>
                <button
                  onClick={() => updatePhotoPosition('bottom')}
                  className={cn(
                    "px-3 py-2 rounded-lg text-xs transition-all",
                    photoPosition === 'bottom'
                      ? "bg-[#4158F1] text-white"
                      : "bg-white/5 text-white/50 hover:bg-white/10"
                  )}
                >
                  {t('bottom')}
                </button>
              </div>
            </div>

            {/* Slide Interval Control */}
            <div className="mt-4 pt-4 border-t border-white/10">
              <div className="flex items-center justify-between mb-3">
                <span className="text-white/70 text-sm">{t('slideSpeed')}</span>
                <span className="text-white text-sm font-medium">{photoSlideInterval}{t('seconds')}</span>
              </div>
              <div className="grid grid-cols-5 gap-2">
                {[2, 3, 4, 5, 6].map(sec => (
                  <button
                    key={sec}
                    onClick={() => updatePhotoSlideInterval(sec)}
                    className={cn(
                      "px-2 py-2 rounded-lg text-xs transition-all",
                      photoSlideInterval === sec
                        ? "bg-[#4158F1] text-white"
                        : "bg-white/5 text-white/50 hover:bg-white/10"
                    )}
                  >
                    {sec}{t('seconds')}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-4 gap-2 mt-2">
                {[7, 8, 9, 10].map(sec => (
                  <button
                    key={sec}
                    onClick={() => updatePhotoSlideInterval(sec)}
                    className={cn(
                      "px-2 py-2 rounded-lg text-xs transition-all",
                      photoSlideInterval === sec
                        ? "bg-[#4158F1] text-white"
                        : "bg-white/5 text-white/50 hover:bg-white/10"
                    )}
                  >
                    {sec}{t('seconds')}
                  </button>
                ))}
              </div>
              <p className="text-white/40 text-xs mt-2">{t('slideSpeedDesc')}</p>
            </div>
            </div>

          <div className="p-4">
            <label
              htmlFor="memory-upload"
              className={cn(
                "block w-full p-4 border-2 border-dashed rounded-xl transition-colors text-center",
                memoryPhotos.length >= 15
                  ? "border-white/5 cursor-not-allowed opacity-50"
                  : "border-white/10 hover:border-[#4158F1]/50 cursor-pointer"
              )}
            >
              {uploadingMemory ? (
                <Loader2 className="w-8 h-8 text-[#4158F1] mx-auto animate-spin mb-2" />
              ) : (
                <Upload className="w-8 h-8 text-white/30 mx-auto mb-2" />
              )}
              <p className="text-white/70 text-sm">{t('addPhoto')}</p>
              <p className="text-white/40 text-xs mt-1">
                {memoryPhotos.length >= 15 
                  ? `최대 15장 (${memoryPhotos.length}/15)`
                  : `${t('addPhotoDesc')} (${memoryPhotos.length}/15)`}
              </p>
            </label>
            <input
              id="memory-upload"
              type="file"
              accept="image/*"
              onChange={handleMemoryUpload}
              disabled={uploadingMemory || memoryPhotos.length >= 15}
              className="hidden"
            />
          </div>

          {memoryPhotos.length > 0 && (
            <div className="p-4 pt-0">
              <div className="grid grid-cols-4 gap-2">
                {memoryPhotos.map(photo => (
                  <div key={photo.id} className="relative aspect-square rounded-lg overflow-hidden group">
                    <img 
                      src={photo.photo_url} 
                      alt="Memory" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button
                        onClick={() => deleteMemory(photo.id)}
                        className="p-1.5 rounded-full bg-red-500/80 hover:bg-red-500 transition-colors"
                      >
                        <Trash2 className="w-3 h-3 text-white" />
                      </button>
                    </div>
                    <div className="absolute bottom-0.5 left-0.5 px-1.5 py-0.5 rounded bg-black/70 text-white text-[9px]">
                      {photo.mood}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </GlassCard>
        {/* Settings */}
        <GlassCard className="overflow-hidden">
          <button
            onClick={() => setShowLanguageSelector(true)}
            className="w-full p-4 flex items-center justify-between hover:bg-white/5 transition-colors border-b border-white/5"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#4158F1]/20 flex items-center justify-center">
                <Globe className="w-5 h-5 text-[#4158F1]" />
              </div>
              <span className="text-white font-medium">{t('language')}</span>
            </div>
            <ChevronRight className="w-5 h-5 text-white/30" />
          </button>
          
          <button
            onClick={handleLogout}
            className="w-full p-4 flex items-center justify-between hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
                <LogOut className="w-5 h-5 text-red-400" />
              </div>
              <span className="text-red-400 font-medium">{t('logout')}</span>
            </div>
            <ChevronRight className="w-5 h-5 text-white/30" />
          </button>
        </GlassCard>

        {/* Blocked Users */}
        <GlassCard className="overflow-hidden">
          <div className="p-4 border-b border-white/10">
            <h2 className="text-white font-medium flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#8B5CF6]" />
              {t('blockedUsersList')}
            </h2>
          </div>
          
          {blockedUsers.length === 0 ? (
            <div className="p-6 text-center">
              <p className="text-white/40 text-sm">{t('noBlockedUsers')}</p>
            </div>
          ) : (
            <div className="divide-y divide-white/5">
              {blockedUsers.map((blocked) => (
                <div 
                  key={blocked.id}
                  className="p-4 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                      <Ban className="w-5 h-5 text-red-400" />
                    </div>
                    <div>
                      <p className="text-white text-sm">{blocked.blocked_email}</p>
                      {blocked.reason && (
                        <p className="text-white/40 text-xs truncate max-w-[150px]">
                          {blocked.reason}
                        </p>
                      )}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setUnblockTarget(blocked);
                      setShowUnblockDialog(true);
                    }}
                    className="text-white/50 hover:text-white hover:bg-white/10"
                  >
                    {t('unblock')}
                  </Button>
                </div>
              ))}
            </div>
          )}
        </GlassCard>

        {/* App Info */}
        <div className="pt-8 pb-4 text-center">
          <EolsuLogo size="sm" />
          <p className="text-white/30 text-xs mt-4">{t('version')} 1.0.0</p>
        </div>
      </div>

      {/* Language Selector */}
      <LanguageSelector 
        open={showLanguageSelector}
        onClose={() => setShowLanguageSelector(false)}
      />

      <UpgradeModal
        open={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        currentPlan={user?.subscription || 'free'}
      />

      {/* Unblock Dialog */}
      <AlertDialog open={showUnblockDialog} onOpenChange={setShowUnblockDialog}>
        <AlertDialogContent className="bg-[#161B22] border-white/10 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>{t('unblock')}</AlertDialogTitle>
            <AlertDialogDescription className="text-white/50">
              {unblockTarget?.blocked_email}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 text-white hover:bg-white/10">
              {t('cancel')}
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => unblockMutation.mutate(unblockTarget?.id)}
              className="bg-[#4158F1] hover:bg-[#4158F1]/80"
            >
              {t('unblock')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}