
import React from 'react';
import BottomNav from '@/components/navigation/BottomNav';
import { Toaster } from "@/components/ui/sonner";
import { LanguageProvider } from '@/components/i18n/LanguageContext';
import CopyrightFooter from '@/components/ui/CopyrightFooter';
import { VideoPlayerProvider } from '@/components/video/GlobalVideoPlayer';

export default function Layout({ children, currentPageName }) {
  // Pages that should not show bottom nav
  const noNavPages = [];
  const showNav = !noNavPages.includes(currentPageName);

  return (
    <LanguageProvider>
    <VideoPlayerProvider>
    <div className="min-h-screen bg-[#0D1117]">
      <style>{`
        :root {
          --background: 222.2 84% 4.9%;
          --foreground: 210 40% 98%;
        }
        
        body {
          background: #0D1117;
          color: white;
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        
        /* Safe area for bottom navigation */
        .pb-safe {
          padding-bottom: env(safe-area-inset-bottom, 0px);
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        
        ::-webkit-scrollbar-track {
          background: transparent;
        }
        
        ::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 3px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }

        /* Smooth transitions */
        * {
          -webkit-tap-highlight-color: transparent;
        }

        /* Input focus styles */
        input:focus, textarea:focus, select:focus {
          outline: none;
        }

        /* Glass effect support */
        @supports (backdrop-filter: blur(20px)) {
          .backdrop-blur-xl {
            backdrop-filter: blur(20px);
          }
        }

        /* Music video animations */
        @keyframes pan-slow {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }

        .animate-pan-slow {
          animation: pan-slow 30s ease-in-out infinite;
        }
      `}</style>
      
      <main className={showNav ? 'pb-20' : ''}>
        {children}
      </main>
      
      {showNav && <BottomNav />}
      {showNav && <CopyrightFooter />}
      
      <Toaster 
        position="top-center" 
        toastOptions={{
          style: {
            background: '#1C2128',
            border: '1px solid rgba(255,255,255,0.1)',
            color: 'white',
          },
        }}
      />
    </div>
    </VideoPlayerProvider>
    </LanguageProvider>
  );
}
