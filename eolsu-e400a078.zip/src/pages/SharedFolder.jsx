import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { 
  Globe, Loader2, Play, User, AlertTriangle, 
  Flag, Ban, ArrowLeft, Copy, FolderPlus 
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import EolsuLogo from '@/components/ui/EolsuLogo';
import GlassCard from '@/components/ui/GlassCard';
import GradientButton from '@/components/ui/GradientButton';
import VideoCard from '@/components/videos/VideoCard';
import VideoPlayer from '@/components/videos/VideoPlayer';
import BlockReportModal from '@/components/profile/BlockReportModal';
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';

export default function SharedFolder() {
  const urlParams = new URLSearchParams(window.location.search);
  const shareCode = urlParams.get('code');

  const [user, setUser] = useState(null);
  const [playingVideo, setPlayingVideo] = useState(null);
  const [showBlockReport, setShowBlockReport] = useState(false);
  const [cloning, setCloning] = useState(false);
  const [savingVideo, setSavingVideo] = useState(null);
  const [showFolderSelector, setShowFolderSelector] = useState(false);
  const [selectedTargetFolder, setSelectedTargetFolder] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  // Track folder view
  useEffect(() => {
    const trackView = async () => {
      if (!user || !folder) return;
      
      try {
        const existingViews = await base44.entities.FolderView.filter({
          folder_id: folder.id,
          viewer_email: user.email
        });
        
        if (existingViews.length > 0) {
          const view = existingViews[0];
          await base44.entities.FolderView.update(view.id, {
            view_count: view.view_count + 1
          });
        } else {
          await base44.entities.FolderView.create({
            folder_id: folder.id,
            viewer_email: user.email,
            viewer_name: user.full_name || user.email.split('@')[0],
            view_count: 1
          });
        }
      } catch (error) {
        console.error('Failed to track view:', error);
      }
    };
    
    trackView();
  }, [user, folder]);

  // Fetch folder by share code
  const { data: folder, isLoading: folderLoading } = useQuery({
    queryKey: ['sharedFolder', shareCode],
    queryFn: async () => {
      const folders = await base44.entities.Folder.filter({ share_code: shareCode });
      return folders[0];
    },
    enabled: !!shareCode,
  });

  // Fetch videos in this folder
  const { data: videos = [], isLoading: videosLoading } = useQuery({
    queryKey: ['sharedFolderVideos', folder?.id],
    queryFn: () => base44.entities.Video.filter({ folder_id: folder.id }),
    enabled: !!folder?.id,
  });

  // Check if blocked
  const { data: blockedUsers = [] } = useQuery({
    queryKey: ['blockedUsers', user?.email],
    queryFn: () => base44.entities.BlockedUser.filter({ blocker_email: user?.email }),
    enabled: !!user?.email,
  });

  // Fetch user's folders for saving videos
  const { data: myFolders = [] } = useQuery({
    queryKey: ['myFolders', user?.email],
    queryFn: () => base44.entities.Folder.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const isBlocked = blockedUsers.some(b => b.blocked_email === folder?.owner_email);

  const handleBlock = async (data) => {
    await base44.entities.BlockedUser.create({
      blocker_email: user.email,
      blocked_email: folder.owner_email,
      reason: data.reason
    });
    toast.success('사용자를 차단했어요');
    setShowBlockReport(false);
  };

  const handleReport = async (data) => {
    await base44.entities.Report.create({
      reporter_email: user.email,
      reported_email: folder.owner_email,
      reported_content_type: 'folder',
      reported_content_id: folder.id,
      reason: data.reason,
      details: data.details
    });
    toast.success('신고가 접수되었어요');
    setShowBlockReport(false);
  };

  const handleCloneFolder = async () => {
    if (!user || !folder) return;
    setCloning(true);

    try {
      // Create new folder
      const newFolder = await base44.entities.Folder.create({
        name: `${folder.name} (복사본)`,
        owner_email: user.email,
        share_code: Math.random().toString(36).substring(2, 10),
        color: folder.color,
        icon: folder.icon,
        is_public: false
      });

      // Clone all videos
      const videoPromises = videos.map(video => 
        base44.entities.Video.create({
          title: video.title,
          url: video.url,
          thumbnail_url: video.thumbnail_url,
          platform: video.platform,
          embed_id: video.embed_id,
          duration: video.duration,
          notes: video.notes,
          folder_id: newFolder.id,
          owner_email: user.email
        })
      );

      await Promise.all(videoPromises);
      toast.success(`"${folder.name}"을(를) 내 폴더로 복사했어요!`);
      
      // Navigate to the new folder
      setTimeout(() => {
        window.location.href = createPageUrl(`FolderDetail?id=${newFolder.id}`);
      }, 1000);
    } catch (error) {
      toast.error('폴더 복사에 실패했어요');
      console.error(error);
    } finally {
      setCloning(false);
    }
  };

  const handleSaveVideo = async (video) => {
    if (!selectedTargetFolder) {
      toast.error('폴더를 선택해주세요');
      return;
    }

    setSavingVideo(video.id);
    try {
      await base44.entities.Video.create({
        title: video.title,
        url: video.url,
        thumbnail_url: video.thumbnail_url,
        platform: video.platform,
        embed_id: video.embed_id,
        duration: video.duration,
        notes: video.notes,
        folder_id: selectedTargetFolder,
        owner_email: user.email
      });

      toast.success('내 폴더에 저장했어요!');
      setShowFolderSelector(false);
      setSelectedTargetFolder(null);
    } catch (error) {
      toast.error('저장에 실패했어요');
      console.error(error);
    } finally {
      setSavingVideo(null);
    }
  };

  if (folderLoading) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  if (!folder || !folder.is_public) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center p-4">
        <GlassCard className="p-8 text-center max-w-sm">
          <AlertTriangle className="w-12 h-12 text-[#FFD60A] mx-auto mb-4" />
          <h2 className="text-white font-semibold text-lg mb-2">폴더를 찾을 수 없어요</h2>
          <p className="text-white/50 text-sm mb-4">
            이 폴더가 삭제되었거나 비공개로 전환되었을 수 있어요.
          </p>
          <Link to={createPageUrl('Folders')}>
            <GradientButton size="sm" icon={ArrowLeft}>
              내 폴더로 돌아가기
            </GradientButton>
          </Link>
        </GlassCard>
      </div>
    );
  }

  if (isBlocked) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center p-4">
        <GlassCard className="p-8 text-center max-w-sm">
          <Ban className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h2 className="text-white font-semibold text-lg mb-2">차단된 사용자</h2>
          <p className="text-white/50 text-sm mb-4">
            이 사용자를 차단했기 때문에 폴더를 볼 수 없어요.
          </p>
          <Link to={createPageUrl('Folders')}>
            <GradientButton size="sm" icon={ArrowLeft}>
              내 폴더로 돌아가기
            </GradientButton>
          </Link>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1117] pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0D1117]/80 backdrop-blur-xl border-b border-white/5">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <div 
                className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ 
                  background: `linear-gradient(135deg, ${folder.color || '#4158F1'}40, ${folder.color || '#4158F1'}20)` 
                }}
              >
                <Globe className="w-6 h-6" style={{ color: folder.color || '#4158F1' }} />
              </div>
              <div className="min-w-0">
                <h1 className="text-white font-semibold text-lg truncate">{folder.name}</h1>
                <p className="text-white/50 text-xs flex items-center gap-1">
                  <User className="w-3 h-3" />
                  {folder.owner_email?.split('@')[0]}
                </p>
              </div>
            </div>

            {user && user.email !== folder.owner_email && (
              <div className="flex gap-2">
                <GradientButton
                  size="sm"
                  onClick={handleCloneFolder}
                  disabled={cloning || videos.length === 0}
                  icon={cloning ? Loader2 : Copy}
                  className={cloning ? '[&_svg]:animate-spin' : ''}
                >
                  폴더 복제
                </GradientButton>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShowBlockReport(true)}
                  className="text-white/50 hover:text-red-400 hover:bg-red-500/10"
                >
                  <Flag className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        {videosLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
          </div>
        ) : videos.length === 0 ? (
          <GlassCard className="p-8 text-center">
            <Play className="w-12 h-12 text-white/20 mx-auto mb-3" />
            <p className="text-white/50">이 폴더에는 아직 영상이 없어요</p>
          </GlassCard>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <AnimatePresence>
              {videos.map((video, index) => (
                <motion.div
                  key={video.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <VideoCard 
                    video={video}
                    onPlay={(v) => setPlayingVideo(v)}
                    onEdit={() => {}}
                    onDelete={() => {}}
                    showSaveButton={user?.email !== folder.owner_email}
                    onSave={(v) => {
                      setSavingVideo(v);
                      setShowFolderSelector(true);
                    }}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Video Player */}
      <VideoPlayer
        video={playingVideo}
        open={!!playingVideo}
        onClose={() => setPlayingVideo(null)}
        playlist={videos}
        onNavigate={(v) => setPlayingVideo(v)}
      />

      {/* Block/Report Modal */}
      {user && (
        <BlockReportModal
          open={showBlockReport}
          onClose={() => setShowBlockReport(false)}
          targetEmail={folder.owner_email}
          targetName={folder.owner_email?.split('@')[0]}
          contentType="folder"
          contentId={folder.id}
          onBlock={handleBlock}
          onReport={handleReport}
        />
      )}

      {/* Folder Selector Modal */}
      {showFolderSelector && savingVideo && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <GlassCard className="w-full max-w-md p-6">
            <h3 className="text-white font-semibold text-lg mb-4">저장할 폴더 선택</h3>
            <p className="text-white/70 text-sm mb-4 line-clamp-2">{savingVideo.title}</p>
            
            {myFolders.length === 0 ? (
              <div className="text-center py-8">
                <FolderPlus className="w-12 h-12 text-white/20 mx-auto mb-3" />
                <p className="text-white/50 text-sm mb-4">폴더가 없어요</p>
                <GradientButton
                  size="sm"
                  onClick={() => window.location.href = createPageUrl('Folders')}
                >
                  폴더 만들러 가기
                </GradientButton>
              </div>
            ) : (
              <>
                <div className="space-y-2 mb-6 max-h-60 overflow-y-auto">
                  {myFolders.map(folder => (
                    <button
                      key={folder.id}
                      onClick={() => setSelectedTargetFolder(folder.id)}
                      className={`w-full p-3 rounded-xl text-left transition-all flex items-center gap-3 ${
                        selectedTargetFolder === folder.id
                          ? "bg-gradient-to-r from-[#4158F1] to-[#8B5CF6] text-white"
                          : "bg-white/5 text-white hover:bg-white/10"
                      }`}
                    >
                      <div 
                        className="w-8 h-8 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: selectedTargetFolder === folder.id ? 'rgba(255,255,255,0.2)' : `${folder.color}30` }}
                      >
                        <Globe className="w-4 h-4" style={{ color: selectedTargetFolder === folder.id ? 'white' : folder.color }} />
                      </div>
                      <span>{folder.name}</span>
                    </button>
                  ))}
                </div>

                <div className="flex gap-3">
                  <GradientButton
                    variant="ghost"
                    fullWidth
                    onClick={() => {
                      setShowFolderSelector(false);
                      setSavingVideo(null);
                      setSelectedTargetFolder(null);
                    }}
                  >
                    취소
                  </GradientButton>
                  <GradientButton
                    fullWidth
                    onClick={() => handleSaveVideo(savingVideo)}
                    disabled={!selectedTargetFolder}
                  >
                    저장
                  </GradientButton>
                </div>
              </>
            )}
          </GlassCard>
        </div>
      )}
    </div>
  );
}