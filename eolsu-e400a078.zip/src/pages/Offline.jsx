import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Download, Trash2, Wifi, WifiOff, HardDrive, Loader2, Play, CheckSquare, Square, Repeat, Shuffle } from 'lucide-react';
import { DragDropContext, Droppable } from '@hello-pangea/dnd';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import EolsuLogo from '@/components/ui/EolsuLogo';
import GlassCard from '@/components/ui/GlassCard';
import GradientButton from '@/components/ui/GradientButton';
import DraggableVideoCard from '@/components/videos/DraggableVideoCard';
import { offlineManager } from '@/components/offline/OfflineManager';
import { useLanguage } from '@/components/i18n/LanguageContext';
import { useVideoPlayer } from '@/components/video/GlobalVideoPlayer';

export default function Offline() {
  const { t } = useLanguage();
  const { playVideo, playPlaylist, repeatMode, setRepeatMode } = useVideoPlayer();
  const [user, setUser] = useState(null);
  const [offlineVideos, setOfflineVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalSize, setTotalSize] = useState(0);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [selectedVideos, setSelectedVideos] = useState([]);
  const [shuffleMode, setShuffleMode] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  useEffect(() => {
    loadOfflineContent();

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const loadOfflineContent = async () => {
    try {
      setLoading(true);
      const videos = await offlineManager.getOfflineVideos();
      setOfflineVideos(videos);
      const size = await offlineManager.getTotalSize();
      setTotalSize(size);
    } catch (error) {
      console.error('Failed to load offline content:', error);
      toast.error(String(t('loadingFailed')));
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (videoId) => {
    try {
      await offlineManager.deleteOfflineVideo(videoId);
      toast.success(String(t('fileDeleted')));
      loadOfflineContent();
    } catch (error) {
      toast.error(String(t('deleteFailed')));
    }
  };

  const handlePlay = async (video) => {
    try {
      const offlineData = await offlineManager.getOfflineVideo(video.id);
      if (offlineData && offlineData.blob) {
        const url = URL.createObjectURL(offlineData.blob);
        playVideo({
          ...video,
          audio_url: video.platform === 'audio' ? url : null,
          video_file_urls: video.platform === 'uploaded_video' ? [url] : null
        });
      }
    } catch (error) {
      toast.error(String(t('playbackFailed')));
    }
  };

  const handleToggleSelect = (videoId) => {
    setSelectedVideos(prev => 
      prev.includes(videoId) 
        ? prev.filter(id => id !== videoId)
        : [...prev, videoId]
    );
  };

  const handleSelectAll = () => {
    if (selectedVideos.length === offlineVideos.length) {
      setSelectedVideos([]);
    } else {
      setSelectedVideos(offlineVideos.map(v => v.id));
    }
  };

  const handlePlaySelected = async () => {
    if (selectedVideos.length === 0) {
      toast.error(String(t('selectItemsToPlay')));
      return;
    }

    try {
      const videosToPlay = offlineVideos.filter(v => selectedVideos.includes(v.id));
      let orderedVideos = videosToPlay;
      
      if (shuffleMode) {
        orderedVideos = [...videosToPlay].sort(() => Math.random() - 0.5);
      }

      const playlistWithBlobs = await Promise.all(
        orderedVideos.map(async (video) => {
          try {
            const offlineData = await offlineManager.getOfflineVideo(video.id);
            if (offlineData && offlineData.blob) {
              const url = URL.createObjectURL(offlineData.blob);
              return {
                ...video,
                audio_url: video.platform === 'audio' ? url : null,
                video_file_urls: video.platform === 'uploaded_video' ? [url] : null
              };
            }
            return null;
          } catch (err) {
            console.error('Failed to load offline video:', video.id, err);
            return null;
          }
        })
      );

      const validPlaylist = playlistWithBlobs.filter(v => v !== null);
      if (validPlaylist.length > 0) {
        playVideo(validPlaylist[0], validPlaylist, repeatMode);
        toast.success(String(t('playbackStarted')).replace('{count}', String(validPlaylist.length)));
      } else {
        toast.error(String(t('noPlayableFiles')));
      }
    } catch (error) {
      console.error('Playback error:', error);
      toast.error(String(t('playbackFailed')));
    }
  };

  const handlePlayAll = async () => {
    if (offlineVideos.length === 0) return;

    try {
      let orderedVideos = offlineVideos;
      
      if (shuffleMode) {
        orderedVideos = [...offlineVideos].sort(() => Math.random() - 0.5);
      }

      const playlistWithBlobs = await Promise.all(
        orderedVideos.map(async (video) => {
          try {
            const offlineData = await offlineManager.getOfflineVideo(video.id);
            if (offlineData && offlineData.blob) {
              const url = URL.createObjectURL(offlineData.blob);
              return {
                ...video,
                audio_url: video.platform === 'audio' ? url : null,
                video_file_urls: video.platform === 'uploaded_video' ? [url] : null
              };
            }
            return null;
          } catch (err) {
            console.error('Failed to load offline video:', video.id, err);
            return null;
          }
        })
      );

      const validPlaylist = playlistWithBlobs.filter(v => v !== null);
      if (validPlaylist.length > 0) {
        playVideo(validPlaylist[0], validPlaylist, repeatMode);
        toast.success(String(t('playbackStarted')).replace('{count}', String(validPlaylist.length)));
      } else {
        toast.error(String(t('noPlayableFiles')));
      }
    } catch (error) {
      console.error('Playback error:', error);
      toast.error(String(t('playbackFailed')));
    }
  };

  const selectAll = () => {
    setSelectedVideos(offlineVideos.map(v => v.id));
  };

  const clearSelection = () => {
    setSelectedVideos([]);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1117] pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0D1117]/80 backdrop-blur-xl border-b border-white/5">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#4158F1] to-[#8B5CF6] flex items-center justify-center">
                <Download className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-white font-semibold text-lg">
                  {String(t('offlineContent'))}
                </h1>
                <p className="text-white/50 text-xs">
                  {String(offlineVideos.length)}{String(t('filesCount'))} • {offlineManager.formatSize(totalSize)}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {isOnline ? (
                <Wifi className="w-5 h-5 text-green-400" />
              ) : (
                <WifiOff className="w-5 h-5 text-red-400" />
              )}
            </div>
          </div>

          {/* Filters & Controls */}
          {offlineVideos.length > 0 && (
            <div className="flex gap-2 flex-wrap">
              <div className="flex-1" />

              {selectedVideos.length > 0 && (
                <>
                  <GradientButton 
                    size="sm" 
                    variant="accent"
                    onClick={handlePlaySelected}
                    icon={Play}
                  >
                    {String(t('selectPlayback'))} ({String(selectedVideos.length)})
                  </GradientButton>
                  <GradientButton 
                    size="sm" 
                    variant="ghost"
                    onClick={clearSelection}
                  >
                    {String(t('clearSelection'))}
                  </GradientButton>
                </>
              )}

              {selectedVideos.length === 0 && (
                <GradientButton 
                  size="sm" 
                  variant="ghost"
                  onClick={selectAll}
                  disabled={offlineVideos.length === 0}
                >
                  {String(t('selectAll'))}
                </GradientButton>
              )}

              <GradientButton 
                size="sm" 
                variant={repeatMode ? "accent" : "ghost"}
                onClick={() => setRepeatMode(!repeatMode)}
                icon={Repeat}
              >
                {String(t('repeat'))}
              </GradientButton>

              <GradientButton 
                size="sm" 
                variant={shuffleMode ? "accent" : "ghost"}
                onClick={() => setShuffleMode(!shuffleMode)}
                disabled={offlineVideos.length === 0}
                icon={Shuffle}
              >
                {String(t('shuffle'))}
              </GradientButton>

              <GradientButton 
                size="sm"
                onClick={handlePlayAll}
                disabled={offlineVideos.length === 0}
                icon={Play}
              >
                {String(t('playAll'))}
              </GradientButton>
            </div>
          )}
        </div>
      </div>



      {/* Content */}
      <div className="px-4 py-2">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
          </div>
        ) : offlineVideos.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <GlassCard className="inline-block p-8">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#4158F1]/20 to-[#8B5CF6]/20 flex items-center justify-center mx-auto mb-4">
                <Download className="w-8 h-8 text-[#8B5CF6]" />
              </div>
              <h3 className="text-white font-medium mb-2">
                {String(t('noOfflineContent'))}
              </h3>
              <p className="text-white/50 text-sm mb-4">
                {String(t('downloadInstruction'))}
              </p>
            </GlassCard>
          </motion.div>
        ) : (
          <DragDropContext onDragEnd={() => {}}>
            <Droppable droppableId="offline-videos">
              {(provided) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className="space-y-3"
                >
                  {offlineVideos.map((video, index) => (
                    <DraggableVideoCard
                      key={video.id}
                      video={video}
                      index={index}
                      onPlay={handlePlay}
                      isSelected={selectedVideos.includes(video.id)}
                      onToggleSelect={handleToggleSelect}
                      onDelete={handleDelete}
                    />
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}
      </div>
    </div>
  );
}