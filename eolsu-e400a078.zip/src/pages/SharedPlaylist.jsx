import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Play, Loader2, Lock } from 'lucide-react';
import GlassCard from '@/components/ui/GlassCard';
import GradientButton from '@/components/ui/GradientButton';
import VideoCard from '@/components/videos/VideoCard';
import { useVideoPlayer } from '@/components/video/GlobalVideoPlayer';

export default function SharedPlaylist() {
  const urlParams = new URLSearchParams(window.location.search);
  const shareCode = urlParams.get('code');
  
  const [user, setUser] = useState(null);
  const { playVideo } = useVideoPlayer();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  // Fetch playlist by share code
  const { data: playlists = [], isLoading } = useQuery({
    queryKey: ['sharedPlaylist', shareCode],
    queryFn: async () => {
      if (!shareCode) return [];
      return base44.entities.SavedPlaylist.filter({ share_code: shareCode, is_public: true });
    },
    enabled: !!shareCode,
  });

  const playlist = playlists[0];

  // Fetch videos
  const { data: allVideos = [] } = useQuery({
    queryKey: ['allVideos'],
    queryFn: () => base44.entities.Video.list(),
    enabled: !!playlist,
  });

  // Get videos in this playlist
  const playlistVideos = playlist?.video_ids
    ? allVideos.filter(v => playlist.video_ids.includes(v.id))
    : [];

  const handlePlayAll = () => {
    if (playlistVideos.length > 0) {
      playVideo(playlistVideos[0], playlistVideos);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  if (!playlist) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center p-4">
        <GlassCard className="p-8 text-center max-w-md">
          <Lock className="w-12 h-12 text-white/20 mx-auto mb-4" />
          <h2 className="text-white font-semibold text-lg mb-2">재생목록을 찾을 수 없어요</h2>
          <p className="text-white/50 text-sm mb-4">
            공유 링크가 올바르지 않거나 재생목록이 삭제되었어요
          </p>
          <Link to={createPageUrl('Home')}>
            <GradientButton size="sm">홈으로 가기</GradientButton>
          </Link>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1117] pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0D1117]/80 backdrop-blur-xl border-b border-white/5">
        <div className="px-4 py-4">
          <Link to={createPageUrl('Home')} className="inline-flex items-center gap-2 text-white/70 hover:text-white mb-3">
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">홈으로</span>
          </Link>

          <div className="mb-3">
            <h1 className="text-white font-semibold text-xl mb-1">{playlist.name}</h1>
            {playlist.description && (
              <p className="text-white/50 text-sm">{playlist.description}</p>
            )}
            <p className="text-white/40 text-xs mt-1">{playlistVideos.length}개 영상</p>
          </div>

          <GradientButton
            size="sm"
            onClick={handlePlayAll}
            disabled={playlistVideos.length === 0}
            icon={Play}
          >
            전체 재생
          </GradientButton>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        {playlistVideos.length === 0 ? (
          <GlassCard className="p-8 text-center">
            <p className="text-white/50">이 재생목록에는 영상이 없어요</p>
          </GlassCard>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {playlistVideos.map((video) => (
              <VideoCard
                key={video.id}
                video={video}
                onPlay={(v) => playVideo(v, playlistVideos)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}