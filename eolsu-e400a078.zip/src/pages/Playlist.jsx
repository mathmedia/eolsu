import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { DragDropContext, Droppable } from '@hello-pangea/dnd';
import { PlaySquare, Loader2, Shuffle, Play, Repeat, Plus, Save, List, Share2 } from 'lucide-react';
import { motion } from 'framer-motion';
import GlassCard from '@/components/ui/GlassCard';
import GradientButton from '@/components/ui/GradientButton';
import DraggableVideoCard from '@/components/videos/DraggableVideoCard';
import { useVideoPlayer } from '@/components/video/GlobalVideoPlayer';
import MultiFolderSelector from '@/components/playlist/MultiFolderSelector';
import SavePlaylistModal from '@/components/playlist/SavePlaylistModal';
import SharePlaylistModal from '@/components/playlist/SharePlaylistModal';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';
import { useLanguage } from '@/components/i18n/LanguageContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Playlist() {
  const { t } = useLanguage();
  const [user, setUser] = useState(null);
  const [selectedFolders, setSelectedFolders] = useState([]);
  const [selectedVideos, setSelectedVideos] = useState([]);
  const [shuffleMode, setShuffleMode] = useState(false);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showMyPlaylists, setShowMyPlaylists] = useState(false);
  const [selectedPlaylist, setSelectedPlaylist] = useState(null);
  const [showShareModal, setShowShareModal] = useState(false);
  const { playVideo, repeatMode, setRepeatMode } = useVideoPlayer();
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  // Fetch all videos
  const { data: allVideos = [], isLoading: videosLoading } = useQuery({
    queryKey: ['allVideos', user?.email],
    queryFn: async () => {
      try {
        return await base44.entities.Video.filter({ owner_email: user?.email });
      } catch (error) {
        console.error('Failed to fetch videos:', error);
        return [];
      }
    },
    enabled: !!user?.email,
  });

  // Fetch all folders
  const { data: folders = [] } = useQuery({
    queryKey: ['folders', user?.email],
    queryFn: () => base44.entities.Folder.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  // Fetch saved playlists
  const { data: savedPlaylists = [] } = useQuery({
    queryKey: ['savedPlaylists', user?.email],
    queryFn: () => base44.entities.SavedPlaylist.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  // Fetch shared users for selected playlist
  const { data: sharedUsers = [] } = useQuery({
    queryKey: ['sharedPlaylistUsers', selectedPlaylist?.id],
    queryFn: () => base44.entities.SharedPlaylist.filter({ playlist_id: selectedPlaylist?.id }),
    enabled: !!selectedPlaylist?.id,
  });

  // Update video order mutation
  const updateOrderMutation = useMutation({
    mutationFn: async ({ id, order }) => {
      return base44.entities.Video.update(id, { order });
    },
  });

  // Save playlist mutation
  const savePlaylistMutation = useMutation({
    mutationFn: async (data) => {
      const videosToSave = selectedVideos.length > 0
        ? filteredVideos.filter(v => selectedVideos.includes(v.id))
        : filteredVideos;
      
      return base44.entities.SavedPlaylist.create({
        ...data,
        owner_email: user?.email,
        share_code: Math.random().toString(36).substring(2, 10),
        video_ids: videosToSave.map(v => v.id),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['savedPlaylists'] });
      setShowSaveModal(false);
      toast.success(String(t('playlistSaved')));
    },
  });

  // Share by email mutation
  const shareByEmailMutation = useMutation({
    mutationFn: async (email) => {
      return base44.entities.SharedPlaylist.create({
        playlist_id: selectedPlaylist.id,
        owner_email: user?.email,
        shared_with_email: email,
        permission: 'read',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sharedPlaylistUsers'] });
      toast.success(String(t('playlistShared')));
    },
  });

  // Remove share mutation
  const removeShareMutation = useMutation({
    mutationFn: (shareId) => base44.entities.SharedPlaylist.delete(shareId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sharedPlaylistUsers'] });
      toast.success(String(t('shareRemoved2')));
    },
  });

  // Delete playlist mutation
  const deletePlaylistMutation = useMutation({
    mutationFn: (id) => base44.entities.SavedPlaylist.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['savedPlaylists'] });
      setShowMyPlaylists(false);
      toast.success(String(t('playlistDeleted')));
    },
  });

  // Filter and sort videos by order
  const filteredVideos = allVideos
    .filter(video => {
      // If no folders selected, show all videos
      if (selectedFolders.length === 0) return true;
      // Show videos from selected folders
      return selectedFolders.includes(video.folder_id);
    })
    .sort((a, b) => (a.order || 0) - (b.order || 0));

  const handleDragEnd = async (result) => {
    if (!result.destination) return;
    
    const sourceIndex = result.source.index;
    const destIndex = result.destination.index;
    
    if (sourceIndex === destIndex) return;

    // Reorder locally first for instant feedback
    const reordered = Array.from(filteredVideos);
    const [removed] = reordered.splice(sourceIndex, 1);
    reordered.splice(destIndex, 0, removed);

    // Update order values
    const updates = reordered.map((video, index) => ({
      id: video.id,
      order: index
    }));

    // Optimistically update cache
    queryClient.setQueryData(['allVideos', user?.email], (old) => {
      if (!old) return old;
      const newVideos = [...old];
      updates.forEach(({ id, order }) => {
        const videoIndex = newVideos.findIndex(v => v.id === id);
        if (videoIndex !== -1) {
          newVideos[videoIndex] = { ...newVideos[videoIndex], order };
        }
      });
      return newVideos;
    });

    // Save to database
    try {
      await Promise.all(
        updates.map(({ id, order }) => 
          updateOrderMutation.mutateAsync({ id, order })
        )
      );
      toast.success(String(t('orderSaved')));
    } catch (error) {
      queryClient.invalidateQueries({ queryKey: ['allVideos'] });
      toast.error(String(t('orderSaveFailed')));
    }
  };

  const playAll = () => {
    if (filteredVideos.length > 0) {
      if (shuffleMode) {
        // Shuffle the array
        const shuffled = [...filteredVideos].sort(() => Math.random() - 0.5);
        playVideo(shuffled[0], shuffled, repeatMode);
      } else {
        playVideo(filteredVideos[0], filteredVideos, repeatMode);
      }
    }
  };

  const playSelected = () => {
    const selected = filteredVideos.filter(v => selectedVideos.includes(v.id));
    if (selected.length > 0) {
      if (shuffleMode) {
        // Shuffle the selected videos
        const shuffled = [...selected].sort(() => Math.random() - 0.5);
        playVideo(shuffled[0], shuffled, repeatMode);
      } else {
        playVideo(selected[0], selected, repeatMode);
      }
    }
  };

  const toggleSelectVideo = (videoId) => {
    setSelectedVideos(prev => 
      prev.includes(videoId) 
        ? prev.filter(id => id !== videoId)
        : [...prev, videoId]
    );
  };

  const selectAll = () => {
    setSelectedVideos(filteredVideos.map(v => v.id));
  };

  const clearSelection = () => {
    setSelectedVideos([]);
  };

  const getFolderName = (folderId) => {
    const folder = folders.find(f => f.id === folderId);
    const name = folder?.name;
    // Ensure we always return a string or null, never an object
    if (!name) return null;
    if (typeof name === 'string') return name;
    return String(name);
  };

  const handleSavePlaylist = (data) => {
    if (filteredVideos.length === 0) {
      toast.error(String(t('noVideosToSave')));
      return;
    }
    savePlaylistMutation.mutate(data);
  };

  const handleLoadPlaylist = (playlist) => {
    setSelectedFolders([]);
    setSelectedVideos([]);
    setShowMyPlaylists(false);
    // Filter videos by the playlist's video_ids
    // The UI will automatically update via filteredVideos
  };

  const handleSharePlaylist = (playlist) => {
    setSelectedPlaylist(playlist);
    setShowShareModal(true);
  };

  if (!user || videosLoading) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1117] pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0D1117]/80 backdrop-blur-xl border-b border-white/5">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#4158F1] to-[#8B5CF6] flex items-center justify-center">
                <PlaySquare className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-white font-semibold text-lg">
                  {String(t('playlistPage'))}
                </h1>
                <p className="text-white/50 text-xs">
                  {String(allVideos.length)}{String(t('numVideosWithDrag'))}
                </p>
              </div>
            </div>
          </div>

          {/* Filters & Controls */}
          <div className="flex gap-2 flex-wrap">
            <MultiFolderSelector
              folders={folders}
              selectedFolders={selectedFolders}
              onSelectionChange={setSelectedFolders}
            />

            <div className="flex-1" />

            {selectedVideos.length > 0 && (
              <>
                <GradientButton 
                  size="sm" 
                  variant="accent"
                  onClick={playSelected}
                  icon={Play}
                >
                  {String(t('selectPlayback'))} ({String(selectedVideos.length)})
                </GradientButton>
                <GradientButton 
                  size="sm" 
                  variant="ghost"
                  onClick={clearSelection}
                >
                  {String(t('clearSelection'))}
                </GradientButton>
              </>
            )}

            {selectedVideos.length === 0 && (
              <GradientButton 
                size="sm" 
                variant="ghost"
                onClick={selectAll}
                disabled={filteredVideos.length === 0}
              >
                {String(t('selectAll'))}
              </GradientButton>
            )}

            <GradientButton 
              size="sm" 
              variant={repeatMode ? "accent" : "ghost"}
              onClick={() => setRepeatMode(!repeatMode)}
              icon={Repeat}
            >
              {String(t('repeat'))}
            </GradientButton>

            <GradientButton 
              size="sm" 
              variant={shuffleMode ? "accent" : "ghost"}
              onClick={() => setShuffleMode(!shuffleMode)}
              disabled={filteredVideos.length === 0}
              icon={Shuffle}
            >
              {String(t('shuffle'))}
            </GradientButton>

            <GradientButton 
              size="sm"
              onClick={playAll}
              disabled={filteredVideos.length === 0}
              icon={Play}
            >
              {String(t('playAll'))}
            </GradientButton>

            <DropdownMenu modal={false}>
              <DropdownMenuTrigger asChild>
                <button className="px-5 py-2.5 text-base rounded-xl font-medium transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed active:scale-95 bg-white/5 text-white border border-white/10 hover:bg-white/10">
                  <List className="w-5 h-5" />
                  {String(t('menuList'))}
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent 
                align="end" 
                className="bg-[#1C2128] border-white/10 text-white z-[9999]"
                sideOffset={5}
              >
                <DropdownMenuItem 
                  onClick={(e) => {
                    e.preventDefault();
                    setShowSaveModal(true);
                  }}
                  disabled={filteredVideos.length === 0}
                  className="hover:bg-white/10 cursor-pointer"
                >
                  <Save className="w-4 h-4 mr-2" /> {String(t('savePlaylist'))}
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={(e) => {
                    e.preventDefault();
                    setShowMyPlaylists(!showMyPlaylists);
                  }}
                  className="hover:bg-white/10 cursor-pointer"
                >
                  <List className="w-4 h-4 mr-2" /> {String(t('savedPlaylists'))} ({String(savedPlaylists.length)})
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Saved Playlists */}
      {showMyPlaylists && (
        <div className="px-4 py-4 border-b border-white/5">
          <h2 className="text-white font-medium mb-3">{String(t('savedPlaylists'))}</h2>
          {savedPlaylists.length === 0 ? (
            <p className="text-white/50 text-sm">{String(t('noSavedPlaylists'))}</p>
          ) : (
            <div className="space-y-2">
              {savedPlaylists.map((playlist) => (
                <GlassCard key={playlist.id} className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <h3 className="text-white font-medium text-sm truncate">
                        {String(playlist.name || '')}
                      </h3>
                      {playlist.description && (
                        <p className="text-white/50 text-xs truncate">
                          {String(playlist.description)}
                        </p>
                      )}
                      <p className="text-white/40 text-xs mt-1">
                        {String(playlist.video_ids?.length || 0)}{String(t('numVideosInPlaylist'))}
                        {playlist.is_public && ` • ${String(t('isPublic'))}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 ml-2">
                      <GradientButton
                        size="sm"
                        variant="ghost"
                        onClick={() => handleSharePlaylist(playlist)}
                        icon={Share2}
                      />
                      <GradientButton
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          if (window.confirm(String(t('deletePlaylistConfirm')))) {
                            deletePlaylistMutation.mutate(playlist.id);
                          }
                        }}
                        className="text-red-400 hover:bg-red-500/20"
                      >
                        {String(t('delete'))}
                      </GradientButton>
                    </div>
                  </div>
                </GlassCard>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Content */}
      <div className="px-4 py-6">
        {videosLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
          </div>
        ) : filteredVideos.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <GlassCard className="inline-block p-8">
              <PlaySquare className="w-16 h-16 text-white/20 mx-auto mb-4" />
              <h3 className="text-white font-medium mb-2">
                {String(t('noVideosInPlaylist'))}
              </h3>
              <p className="text-white/50 text-sm mb-4">
                {String(t('addVideosToFolder'))}
              </p>
              {selectedFolders.length === 1 && (
                <a
                  href={createPageUrl(`FolderDetail?id=${selectedFolders[0]}`)}
                  className="inline-block"
                >
                  <GradientButton size="sm" icon={Plus}>
                    {String(t('addVideoMusic'))}
                  </GradientButton>
                </a>
              )}
            </GlassCard>
          </motion.div>
        ) : (
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="playlist">
              {(provided) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className="space-y-3"
                >
                  {filteredVideos.map((video, index) => (
                    <DraggableVideoCard
                      key={video.id}
                      video={video}
                      index={index}
                      onPlay={(v) => playVideo(v, filteredVideos)}
                      folderName={getFolderName(video.folder_id)}
                      isSelected={selectedVideos.includes(video.id)}
                      onToggleSelect={toggleSelectVideo}
                    />
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}
      </div>

      {/* Modals */}
      <SavePlaylistModal
        open={showSaveModal}
        onClose={() => setShowSaveModal(false)}
        onSave={handleSavePlaylist}
        loading={savePlaylistMutation.isPending}
      />

      <SharePlaylistModal
        open={showShareModal}
        onClose={() => {
          setShowShareModal(false);
          setSelectedPlaylist(null);
        }}
        playlist={selectedPlaylist}
        sharedUsers={sharedUsers}
        onShareByEmail={(email) => shareByEmailMutation.mutate(email)}
        onRemoveShare={(id) => removeShareMutation.mutate(id)}
        loading={shareByEmailMutation.isPending}
      />
    </div>
  );
}