import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Folder as FolderIcon, Search, Loader2 } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from 'framer-motion';
import EolsuLogo from '@/components/ui/EolsuLogo';
import GlassCard from '@/components/ui/GlassCard';
import GradientButton from '@/components/ui/GradientButton';
import FolderCard from '@/components/folders/FolderCard';
import CreateFolderModal from '@/components/folders/CreateFolderModal';
import { useLanguage } from '@/components/i18n/LanguageContext';

export default function Folders() {
  const { t } = useLanguage();
  const [user, setUser] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(async (u) => {
      setUser(u);
      // Create Music Video folder if it doesn't exist
      const musicVideoFolder = await base44.entities.Folder.filter({
        owner_email: u.email,
        name: '뮤직비디오',
        parent_id: null
      });
      
      if (!musicVideoFolder?.length) {
        await base44.entities.Folder.create({
          name: '뮤직비디오',
          owner_email: u.email,
          color: '#8B5CF6',
          icon: 'sparkles',
          share_code: Math.random().toString(36).substring(2, 10)
        });
        queryClient.invalidateQueries({ queryKey: ['folders'] });
      }
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  // Fetch root folders (no parent_id)
  const { data: folders = [], isLoading: foldersLoading } = useQuery({
    queryKey: ['folders', user?.email],
    queryFn: () => base44.entities.Folder.filter({ 
      owner_email: user?.email,
      parent_id: null 
    }),
    enabled: !!user?.email,
  });

  // Fetch all videos to count per folder
  const { data: allVideos = [] } = useQuery({
    queryKey: ['videos', user?.email],
    queryFn: () => base44.entities.Video.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  // Fetch all folders to count subfolders
  const { data: allFolders = [] } = useQuery({
    queryKey: ['allFolders', user?.email],
    queryFn: () => base44.entities.Folder.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const createFolderMutation = useMutation({
    mutationFn: (data) => base44.entities.Folder.create({
      ...data,
      owner_email: user?.email,
      share_code: Math.random().toString(36).substring(2, 10)
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['folders'] });
      queryClient.invalidateQueries({ queryKey: ['allFolders'] });
      setShowCreateModal(false);
    }
  });

  const getVideoCount = (folderId) => {
    return allVideos.filter(v => v.folder_id === folderId).length;
  };

  const getSubfolderCount = (folderId) => {
    return allFolders.filter(f => f.parent_id === folderId).length;
  };

  const filteredFolders = folders.filter(folder => 
    folder.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0D1117] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1117] pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0D1117]/80 backdrop-blur-xl border-b border-white/5">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <EolsuLogo size="sm" />
            <GradientButton 
              size="sm" 
              onClick={() => setShowCreateModal(true)}
              icon={Plus}
            >
              {t('newFolder')}
            </GradientButton>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('searchFolders')}
              className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-[#4158F1]"
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        {foldersLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
          </div>
        ) : filteredFolders.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <GlassCard className="inline-block p-8">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#4158F1]/20 to-[#8B5CF6]/20 flex items-center justify-center mx-auto mb-4">
                <FolderIcon className="w-8 h-8 text-[#8B5CF6]" />
              </div>
              <h3 className="text-white font-medium mb-2">
                {searchQuery ? t('noSearchResults') : t('noFolders')}
              </h3>
              <p className="text-white/50 text-sm mb-4">
                {searchQuery ? t('tryDifferentKeyword') : t('createFirstFolder')}
              </p>
              {!searchQuery && (
                <GradientButton 
                  size="sm"
                  onClick={() => setShowCreateModal(true)}
                  icon={Plus}
                >
                  {t('createFolder')}
                </GradientButton>
              )}
            </GlassCard>
          </motion.div>
        ) : (
          <div className="space-y-3">
            <AnimatePresence>
              {filteredFolders.map((folder, index) => (
                <motion.div
                  key={folder.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <FolderCard 
                    folder={folder}
                    videoCount={getVideoCount(folder.id)}
                    subfolderCount={getSubfolderCount(folder.id)}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Create Folder Modal */}
      <CreateFolderModal
        open={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSubmit={(data) => createFolderMutation.mutate(data)}
        loading={createFolderMutation.isPending}
      />
    </div>
  );
}